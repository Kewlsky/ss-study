(function () {
  'use strict';
  var ONLY_EXAM = !!window.HUB_EXAM_ONLY;   // the stand-alone exam page: no Study tab, and progress saved apart from the study app's
  var WRITTEN = !!window.HUB_WRITTEN;       // the written-questions page: Learn + Test me tabs, its own catalog and saved progress
  var CAT = WRITTEN ? [] : window.CATALOG || [];   // the study lectures
  var WCAT = window.WCATALOG || [];                // the written questions' lectures (the Written tab, or the whole written page)
  var OCAT = WRITTEN ? [] : window.OCATALOG || [];   // the OSPE tab: picture spotting + the prelabs (same lectures as in Study)
  var BOTH = CAT.concat(WCAT, OCAT);
  var KEY = WRITTEN ? 'ss-written-v1' : ONLY_EXAM ? 'ss-ebe-exam-v1' : 'ss-study-hub-v1';
  var store = { done: {}, last: null };
  try {
    var raw = localStorage.getItem(KEY);
    if (!raw && window.SSApp && SSApp.kept) raw = SSApp.kept() || null;   // the app keeps a copy: progress survives opening a downloaded update
    var saved = JSON.parse(raw || 'null');
    if (saved && saved.done) { store = saved; if (!localStorage.getItem(KEY)) localStorage.setItem(KEY, raw); }
  } catch (e) {}
  var keepT = 0;
  function keepCopy() { try { if (window.SSApp && SSApp.keep) SSApp.keep(JSON.stringify(store)); } catch (e) {} }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {}
    if (window.SSApp && SSApp.keep) { clearTimeout(keepT); keepT = setTimeout(keepCopy, 1000); }
  }
  keepCopy();
  var RN = window.RENAMED || {}, moved = 0;   // cards whose titles changed keep their ticks
  for (var old in RN) if (store.done[old]) { store.done[RN[old]] = store.done[old]; delete store.done[old]; moved++; }
  if (moved) save();
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var view = $('view');

  /* ---------- catalog helpers ---------- */
  function inW() { return WRITTEN || tab === 'written'; }   // is the open tab showing the written questions?
  function C() { return tab === 'ospe' ? OCAT : inW() ? WCAT : CAT; }
  function lastKey() { return tab === 'written' ? 'lastw' : tab === 'ospe' ? 'lasto' : 'last'; }   // each tab has its own "Continue" lecture
  function subject(sid, cat) { cat = cat || C(); for (var i = 0; i < cat.length; i++) if (cat[i].id === sid) return cat[i]; return null; }
  function findLec(lid) {
    for (var i = 0; i < BOTH.length; i++) for (var j = 0; j < BOTH[i].lectures.length; j++)
      if (BOTH[i].lectures[j].id === lid) return { s: BOTH[i], l: BOTH[i].lectures[j], n: j + 1 };
    return null;
  }
  function doneIn(lid) { var p = lid + ':', n = 0; for (var k in store.done) if (k.indexOf(p) === 0) n++; return n; }
  function pct(a, b) { return b ? Math.min(100, Math.round(100 * a / b)) : 0; }
  function subjStats(s) {
    var d = 0, c = 0; s.lectures.forEach(function (l) { d += Math.min(doneIn(l.id), l.cards); c += l.cards; });
    return { done: d, cards: c };
  }
  var BADGE = { Parasitology: 'Ps', Pharmacology: 'Rx', 'Mix-ups': 'Mx' };   // names whose first two letters clash with another subject
  function badge(name) { return BADGE[name] || name.slice(0, 2); }

  /* ---------- navigation: three tabs (Study, EBE exam, Written), each with its own screen stack ---------- */
  var stacks = { study: [{ t: 'home' }], exam: [WRITTEN ? { t: 'wtest', v: 'intro' } : ONLY_EXAM ? { t: 'exam', v: 'intro' } : { t: 'exams' }], written: [{ t: 'home' }], ospe: [{ t: 'home' }], qbank: [{ t: 'qhome' }] };
  var tab = ONLY_EXAM || location.hash === '#exam' ? 'exam' : location.hash === '#written' && !WRITTEN && (window.WTEST || []).length ? 'written'
    : location.hash === '#ospe' && OCAT.length ? 'ospe' : location.hash === '#qbank' && !WRITTEN ? 'qbank' : 'study', stack = stacks[tab];
  function top() { return stack[stack.length - 1]; }
  function go(entry) { top().y = window.scrollY; stack.push(entry); render(true); }
  function switchTab(name) {
    if (name === tab) { if (stack.length > 1) { stack.length = 1; render(true); } return; }   // tapping the open tab goes to its first screen
    top().y = window.scrollY; tab = name; stack = stacks[name]; render(false);
  }
  function back() {
    if (document.querySelector('.sheet-wrap')) { closeSheet(); return true; }
    if (!$('lightbox').hidden) { closeLb(); return true; }
    if (focusing) { exitFocus(); return true; }
    if (stack.length > 1) { stack.pop(); render(false); return true; }
    if (tab !== 'study' && !ONLY_EXAM) { switchTab('study'); return true; }
    return false;
  }
  window.hubBack = function () { return back() ? 'handled' : 'exit'; };
  $('back').addEventListener('click', back);
  // Website only: one spare history entry, so the browser / phone back button steps back inside the app instead of leaving it.
  var WEB = !!window.HUB_WEB, guard = false;
  function canBack() { return !$('lightbox').hidden || focusing || stack.length > 1 || (tab !== 'study' && !ONLY_EXAM); }
  function guardBack() { if (WEB && !guard && canBack()) { try { history.pushState({ hub: 1 }, ''); guard = true; } catch (e) {} } }
  window.addEventListener('popstate', function () { if (!guard) return; guard = false; back(); guardBack(); });

  function setBar(title, small, inLecture) {
    $('back').hidden = stack.length < 2;
    $('bar-title').innerHTML = title ? (small ? '<small>' + esc(small) + '</small>' : '') + esc(title) : '<span class="brand">SS <span>' + (WRITTEN ? 'Written' : 'Study') + '</span></span>';
    $('bar-tools').hidden = !inLecture;
    $('track').hidden = !inLecture;
    $('tabs').hidden = ONLY_EXAM || stack.length > 1;   // tabs show on each tab's first screen; deeper screens use the back arrow
    Array.prototype.forEach.call(document.querySelectorAll('[data-tab]'), function (b) {
      var on = b.getAttribute('data-tab') === tab; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on));
    });
    var run = WRITTEN ? store.wt : store.exam;
    $('tab-dot').hidden = !((run && !run.done) || (!WRITTEN && store.oex && !store.oex.done));
    if ($('wtab-dot')) $('wtab-dot').hidden = !(store.wt && !store.wt.done);
  }

  function render(fresh) {
    exitFocus(true);
    var e = top();
    if (e.t === 'home') renderHome();
    else if (e.t === 'subject') renderSubject(e.sid);
    else if (e.t === 'exam') renderExam();
    else if (e.t === 'wtest') renderTest();
    else if (e.t === 'updates') renderUpdates();
    else if (e.t === 'remind') renderRemind();
    else if (e.t === 'creator') renderCreator();
    else if (e.t === 'qhome') renderQHome();
    else if (e.t === 'qsub') renderQSub(e);
    else if (e.t === 'qplay') renderQPlay();
    else if (e.t === 'qdone') renderQDone();
    else if (e.t === 'exams') renderExams();
    else if (e.t === 'oexam') renderOExam();
    else renderLecture(e.lid);
    window.scrollTo(0, fresh ? 0 : (e.y || 0));
    guardBack();
  }

  /* ---------- screens ---------- */
  function renderHome() {
    setBar(null);
    var W = inW(), O = tab === 'ospe', h = O ? '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · OSPE</span><h1>OSPE</h1><p>Learn to spot the pictures and what the arrows point at, then go over the prelabs and the other lectures the OSPE tests. They are the same lectures as in Study, so your ticks count in both.</p></div>'
      : !W ? '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · EBE revision</span><h1>Welcome' + (ME ? ', ' + CREATOR : '') + '!</h1><p>Please choose the subject you want to study.</p></div>'
      : WRITTEN ? '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · written questions</span><h1>Welcome!</h1><p>Pick a subject. Each question is split into small cards with a memory hook. When you finish a lecture, tap <b>Test me</b>.</p></div>'
      : '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · ' + WT.length + ' written questions</span><h1>Written questions</h1><p>Learn each question in small cards with a memory hook. Then tap <b>Test me</b> and answer from memory.</p></div>';
    var last = store[lastKey()] && findLec(store[lastKey()]), i = 0;
    if (!W) h += examBanner();
    if (!W && !O) h += '<div class="finder"><input id="find" type="search" placeholder="Search every card (e.g. glaucoma, Loa loa)" aria-label="Search every card" autocomplete="off" value="' + esc(query) + '"><div id="hits" aria-live="polite"></div></div>';
    h += '<ul class="list" id="tiles">';
    if (last) {
      var dl = doneIn(last.l.id);
      h += '<li style="--i:' + (i++) + '"><button class="tile cont" type="button" data-lec="' + esc(last.l.id) + '" style="--sc:var(--s-' + last.s.id + ')">' +
        '<span class="badge">▶</span><span class="t"><b>Continue: ' + esc(last.l.title) + '</b><span>' + esc(last.s.name) + ' · ' + dl + ' of ' + last.l.cards + ' cards done</span></span><span class="go">›</span></button></li>';
    }
    if (tab === 'written') {   // the written page has Test me as a tab; here it is the first tile
      var wt = store.wt, going = wt && !wt.done && wt.qs.length;
      h += '<li style="--i:' + (i++) + '"><button class="tile" type="button" data-wopen="' + (going ? 'q' : 'intro') + '" style="--sc:var(--eosin)">' +
        '<span class="badge">✎</span><span class="t"><b>' + (going ? 'Resume test: ' + esc(wtName(wt.scope)) : 'Test me') + '</b><span>' +
        (going ? wtShown(wt) + ' of ' + wt.qs.length + ' done' : 'Answer from memory, then tick what you remembered') + '</span></span><span class="go">›</span></button></li>';
    }
    C().forEach(function (s) {
      var st = subjStats(s), ready = s.lectures.length > 0, p = pct(st.done, st.cards);
      h += '<li style="--i:' + (i++) + '"><button class="tile" type="button" data-sub="' + s.id + '" style="--sc:var(--s-' + s.id + ')"' + (ready ? '' : ' disabled') + '>' +
        '<span class="badge">' + esc(badge(s.name)) + '</span><span class="t"><b>' + esc(s.name) + '</b><span>' +
        (ready ? s.lectures.length + (s.lectures.length === 1 ? ' lecture' : ' lectures') + ' · ' + (W ? s.lectures.reduce(function (n, l) { return n + l.qs; }, 0) + ' questions' : st.cards + ' cards') : 'Coming soon') + '</span>' +
        (ready ? '<span class="meter"><i style="width:' + p + '%"></i></span>' : '') + '</span>' +
        (ready ? '<span class="pct">' + p + '%</span>' : '<span></span>') + '</button></li>';
    });
    view.innerHTML = h + '</ul>' + (!W && !O && ME ? '<button class="built mine" type="button" data-creator="1"><b>Messages &amp; ringtone</b><span class="mono">Creator · only you see this</span></button>' : '') +
      (!W && !O && APPV ? '<button class="built" type="button" data-updates="1"><b>v' + esc(APPV) + ' · Updates</b>' +
      (window.BUILT ? '<span class="mono">Content updated ' + when(new Date(window.BUILT)) + '</span>' : '') + '</button>' : '') + '</section>';
    if (!W && query) find(query);
  }

  /* ---------- updates: "What's new" once per version, and the Updates page (log + check now) ---------- */
  var UPD = window.UPDATES || [], APPV = UPD.length ? UPD[0].version : '';
  function when(d) { return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ', ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }); }
  function notes(u) {   // the creator also sees their own notes (u.mine), never shown to anyone else
    var mine = ME ? mineNotes(u) : [];
    return '<ul>' + u.notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') +
      mine.map(function (n) { return '<li class="mine"><span class="mono">Only you</span> ' + esc(n) + '</li>'; }).join('') + '</ul>';
  }
  function sheet(eyebrow, title, body, buttons) {   // a card that slides up over the app; buttons: [[label, attribute]]
    var el = document.createElement('div');
    el.className = 'sheet-wrap';
    el.innerHTML = '<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="sh-t"><span class="mono eyebrow">' + esc(eyebrow) + '</span>' +
      '<h2 id="sh-t">' + esc(title) + '</h2>' + body + (buttons || [['Got it', 'data-wnok']]).map(function (b, i) {
        return '<button class="btn big' + (i ? ' ghost' : '') + '" type="button" ' + b[1] + '="1">' + esc(b[0]) + '</button>';
      }).join('') + '</div>';
    document.body.appendChild(el);
    el.addEventListener('click', function (e) {
      e.stopPropagation();
      var t = e.target.closest ? e.target : null;
      if (t && t.closest('[data-uinstall]') && window.SSApp) { closeSheet(); window.SSApp.install(); return; }
      if (e.target === el || (t && t.closest('[data-wnok]'))) { closeSheet(); setTimeout(nextSheet, 350); }
    });
    try { el.querySelector('.sheet .btn').focus({ preventScroll: true }); } catch (e) {}
  }
  var sheets = [];   // cards waiting for the one on screen to close
  function nextSheet() { if (!document.querySelector('.sheet-wrap') && sheets.length) sheets.shift()(); }
  function queueSheet(show) { sheets.push(show); nextSheet(); }
  function whatsNew() {   // after an update, its notes show once; the Updates page keeps them all
    if (!APPV || store.seenVer === APPV) return;
    var from = store.seenVer, at = -1;   // everything since the version you last saw (v2.6 → v2.7 … the latest), in one log
    for (var i = 0; i < UPD.length; i++) if (UPD[i].version === from) at = i;
    var missed = at > 0 ? UPD.slice(0, at) : [UPD[0]];   // a first visit (or a version not in the log): just the latest
    store.seenVer = APPV; save();
    queueSheet(function () {
      var body = missed.length === 1 ? notes(missed[0]) : missed.map(function (u) { return '<h3 class="wn-v mono">v' + esc(u.version) + '</h3>' + notes(u); }).join('');
      sheet(missed.length === 1 ? 'Updated' : 'Updated · ' + missed.length + ' updates in one', missed.length === 1 ? 'What\'s new in v' + APPV : 'What\'s new since v' + from,
        body + '<p class="xhint">You can read this again any time: Study home → Updates.</p>');
    });
  }
  function closeSheet() { var s = document.querySelector('.sheet-wrap'); if (s) s.parentNode.removeChild(s); }

  /* ---------- messages to everyone: messages.json beside the updates, each message shown once ---------- */
  var MSG_URL = 'https://kewlsky.github.io/ss-study/messages.json';
  var NATIVE_MSGS = !!(window.SSApp && window.SSApp.nativeMessages);   // the app (v2.4+) shows them as phone notifications itself
  function checkMessages() {
    if (ONLY_EXAM || WRITTEN || !window.fetch || NATIVE_MSGS) return;
    fetch(MSG_URL + '?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : []; }).then(function (list) {
      var seen = store.msgSeen || (store.msgSeen = []);
      (list || []).forEach(function (m) {
        if (!m || !m.id || seen.indexOf(m.id) >= 0 || (m.until && daysTo(m.until) != null && daysTo(m.until) < 0)) return;
        seen.push(m.id); save();
        queueSheet(function () {
          sheet('Message' + (m.date ? ' · ' + m.date : ''), m.title || 'SS Study', '<p class="msg">' + esc(m.text || '').replace(/\n/g, '<br>') + '</p>');
        });
      });
      // the app (v2.3+) also checks while closed and rings; tell it which ones were already shown here
      if (window.SSApp && window.SSApp.seenMessages) window.SSApp.seenMessages(JSON.stringify(seen));
    }).catch(function () {});
  }
  setInterval(function () { if (!document.hidden) checkMessages(); }, 60000);   // the website and older apps: every minute while open
  var awayAt = 0;   // coming back to the app after a while: look for messages and updates without restarting
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { awayAt = Date.now(); return; }
    checkIn();   // at most once a day; also counts a phone that only ever resumes the app instead of restarting it
    if (!awayAt || Date.now() - awayAt < 10 * 60000) return;
    awayAt = 0;
    checkMessages(); keyNag();
    if (window.SSApp && window.SSApp.check) window.SSApp.check();
  });
  /* ---------- creator mode (phone app only): the creator's file → "Welcome, Zero", Messages and Your song ----------
     The creator chooses their file once (window.SSApp.pickCreatorFile: tap "You have v…" on the Updates page 5 times);
     the app keeps a private copy and reads it at every launch (SSApp.creatorFile). The SHA-256 of the file's secret
     must match CREATOR_HASH. The secret itself is only in that file, never in the app or online. */
  var REPO = 'Kewlsky/ss-study', CREATOR = 'Zero', CREATOR_HASH = '902569c7a91316fbc163bb318533911573a977dfb678d0f9920e28ee32e5223c';
  var ME = false, GH = '';   // GH: a GitHub key the creator pasted, so this phone can publish messages
  function rr(x, n) { return (x >>> n) | (x << (32 - n)); }
  function sha256(str) {   // hex SHA-256 of a UTF-8 string; plain JS so it works offline in the app's file:// page
    var s = unescape(encodeURIComponent(str)), K = [], H = [], w = [], words = [], p, i, j, n = 0, bits = s.length * 8;
    for (p = 2; n < 64; p++) {
      for (j = 2; j * j <= p && p % j; j++);
      if (j * j > p) { if (n < 8) H[n] = (Math.pow(p, 1 / 2) % 1) * 4294967296 | 0; K[n++] = (Math.pow(p, 1 / 3) % 1) * 4294967296 | 0; }
    }
    s += '\x80';
    while (s.length % 64 !== 56) s += '\x00';
    for (j = 0; j < s.length; j++) words[j >> 2] |= s.charCodeAt(j) << (3 - (j & 3)) * 8;
    words.push((bits / 4294967296) | 0, bits | 0);
    for (j = 0; j < words.length; j += 16) {
      var a = H.slice(0);
      for (i = 0; i < 64; i++) {
        if (i < 16) w[i] = words[j + i] | 0;
        else w[i] = (w[i - 16] + (rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3)) + w[i - 7] + (rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10))) | 0;
        var e = a[4], t1 = (a[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & a[5]) ^ (~e & a[6])) + K[i] + w[i]) | 0,
          t2 = ((rr(a[0], 2) ^ rr(a[0], 13) ^ rr(a[0], 22)) + ((a[0] & a[1]) ^ (a[0] & a[2]) ^ (a[1] & a[2]))) | 0;
        a = [(t1 + t2) | 0].concat(a); a[4] = (a[4] + t1) | 0; a.length = 8;
      }
      for (i = 0; i < 8; i++) H[i] = (H[i] + a[i]) | 0;
    }
    return H.map(function (x) { return ('0000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }
  function readCreator() {
    var txt = window.SSApp && window.SSApp.creatorFile ? String(window.SSApp.creatorFile() || '')
      : store.creatorKey ? 'creator: ' + store.creatorKey : '';   // the website: the secret this browser kept from the file
    var m = /creator:\s*(\S+)/.exec(txt);
    ME = !!(m && sha256(m[1]) === CREATOR_HASH);
    GH = ME ? store.gh || '' : '';
    return ME;
  }
  readCreator();
  function mineNotes(u) { try { return u && u.mine ? JSON.parse(decodeURIComponent(escape(atob(u.mine)))) : []; } catch (e) { return []; } }
  function welcome() {   // once, the first time this phone opens as the creator's
    if (!ME || store.creatorHi) return;
    store.creatorHi = 1; save();
    queueSheet(function () {
      sheet('Creator mode', 'Welcome, ' + CREATOR + '!', '<p>Your creator file checks out, so this ' + (window.SSApp ? 'phone' : 'browser') + ' is yours. The Study home now has <b>Messages &amp; ringtone</b>, and the update log shows your own notes. Nobody else sees them.</p>');
    });
  }
  var DAY = 86400000;
  function dayStr(t) { return new Date(t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function keyLeft() { return Math.ceil((store.ghExp - Date.now()) / DAY); }
  if (store.gh && !store.ghSaved) { store.ghSaved = Date.now(); store.ghExp = Date.now() + 90 * DAY; save(); }   // a key saved before this: 90 days, made 15 Nov 2026
  function keyNag() {   // creator only: once a month after the GitHub key was saved, the days it has left; once more when it runs out
    if (!ME || !GH || !store.ghExp || !store.ghSaved) return;
    var left = keyLeft(), mark = left <= 0 ? 'out' : Math.floor((Date.now() - store.ghSaved) / (30 * DAY));
    if (!mark || store.ghNag === mark) return;   // month 0: it was just saved
    store.ghNag = mark; save();
    queueSheet(function () {
      sheet('Creator · GitHub key', left <= 0 ? 'Your GitHub key has expired' : 'Your GitHub key expires in ' + left + (left === 1 ? ' day' : ' days'),
        (left <= 0 ? '<p>Sending messages from here stopped on ' + dayStr(store.ghExp) + '.</p>' : '<p>It stops working on <b>' + dayStr(store.ghExp) + '</b>. Sending messages from here stops then.</p>') +
        '<p>Make a new key the same way (github.com → Settings → Developer settings → Fine-grained tokens: ss-study only, Contents read and write), then paste it in <b>Messages</b> → Turn on sending.' + (left > 0 ? ' Next reminder in a month.' : '') + '</p>');
    });
  }
  window.onCreatorFile = function (ok, bad) {   // the app copied the file the creator chose (or the website read it)
    if (!ok) { if (bad) queueSheet(function () { sheet('Creator file', 'That\'s not the creator file', '<p>Choose SS-Study-creator.txt.</p>'); }); return; }
    var was = ME;
    readCreator();
    if (!ME) { queueSheet(function () { sheet('Creator file', 'That\'s not the creator file', '<p>Choose SS-Study-creator.txt.</p>'); }); return; }
    if (!was) { delete store.creatorHi; welcome(); render(); }
  };

  function pickCreator() {   // the phone app has its own picker; a browser reads the file here and keeps only the secret
    if (window.SSApp && window.SSApp.pickCreatorFile) { window.SSApp.pickCreatorFile(); return; }
    var input = document.createElement('input');
    input.type = 'file'; input.accept = '.txt,text/plain'; input.style.display = 'none';
    input.addEventListener('change', function () {
      var f = input.files && input.files[0];
      if (input.parentNode) input.parentNode.removeChild(input);
      if (!f || f.size > 4096) { if (f) window.onCreatorFile(false, true); return; }
      var r = new FileReader();
      r.onload = function () {
        var m = /creator:\s*(\S+)/.exec(String(r.result || ''));
        if (m && sha256(m[1]) === CREATOR_HASH) { store.creatorKey = m[1]; save(); }
        window.onCreatorFile(true);
      };
      r.readAsText(f);
    });
    document.body.appendChild(input);
    input.click();
  }
  var ctrlM = 0;   // the website: hold Ctrl, press M then C (key positions, so any keyboard layout works)
  document.addEventListener('keydown', function (e) {
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    if (e.code === 'KeyM') { ctrlM = Date.now(); e.preventDefault(); return; }
    if (e.code === 'KeyC' && Date.now() - ctrlM < 2000) { ctrlM = 0; e.preventDefault(); e.stopPropagation(); pickCreator(); }
  }, true);

  /* ---------- how many use the app: each phone/browser gets a random id (nothing personal) and checks in once a day
     to the Firebase Realtime Database; only the creator page shows the numbers. */
  var COUNT_DB = 'https://ss-study-f66f5-default-rtdb.firebaseio.com/phones';
  function isApp() { return !!window.SSApp || /; wv\)/.test(navigator.userAgent); }
  function checkIn(force, done) {   // force: count again now (the creator page's button); done(ok, why)
    if (ONLY_EXAM || WRITTEN || !window.fetch || !window.crypto || !crypto.getRandomValues) { if (done) done(false, 'this browser can\'t'); return; }
    if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) { if (done) done(false, 'pages on this computer (localhost) aren\'t counted'); return; }   // previews and the PC copy
    var day = today();
    if (store.pingDay === day && !force) return;
    if (!store.pid) {
      var a = new Uint8Array(20), abc = 'abcdefghijklmnopqrstuvwxyz0123456789';
      crypto.getRandomValues(a);
      store.pid = Array.prototype.map.call(a, function (x) { return abc[x % 36]; }).join('');
      store.pidFirst = Date.now(); save();
    }
    fetch(COUNT_DB + '/' + store.pid + '.json', { method: 'PUT', body: JSON.stringify({ first: store.pidFirst, last: Date.now(), app: isApp(), v: APPV }) })
      .then(function (r) {
        if (r.ok) { store.pingDay = day; store.pingOk = Date.now(); delete store.pingErr; }
        else store.pingErr = 'the database answered ' + r.status;
        save(); if (done) done(r.ok, store.pingErr);
      }).catch(function (e) { store.pingErr = String(e && e.message || e); save(); if (done) done(false, store.pingErr); });
  }
  function thisDevice() {
    return 'This device: ' + (isApp() ? 'the phone app' : 'a browser') + (store.pid ? ' (' + esc(store.pid.slice(0, 4)) + '…)' : '') + ', ' +
      (store.pingErr ? 'not counted: ' + esc(store.pingErr) : store.pingOk ? 'counted ' + when(new Date(store.pingOk)) : 'not counted yet') + '.';
  }
  setTimeout(checkIn, 4000);   // a few seconds after the page opens, whether or not the opening animation ran
  function loadCount() {
    var box = $('cm-count');
    if (!box) return;
    Promise.all([
      fetch(COUNT_DB + '.json?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : Promise.reject(new Error('the counter answered ' + r.status)); }),
      fetch('https://api.github.com/repos/' + REPO + '/releases?per_page=100', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; })
    ]).then(function (res) {
      var now = Date.now(), app = { all: 0, week: 0, day: 0 }, web = { all: 0, week: 0 }, dl = 0, rel = 0;
      Object.keys(res[0] || {}).forEach(function (k) {
        var x = res[0][k] || {}, t = x.app ? app : web;
        t.all++;
        if (now - x.last < 7 * DAY) t.week++;
        if (x.app && now - x.last < DAY) app.day++;
      });
      (res[1] || []).forEach(function (r) { rel++; (r.assets || []).forEach(function (a) { if (/\.apk$/i.test(a.name)) dl += a.download_count || 0; }); });
      box.innerHTML = '<p class="cm-count"><b>' + app.all + '</b><span>phones have the app</span></p>' +
        '<p class="cm-count"><b>' + app.week + '</b><span>opened it this week</span></p>' +
        '<p class="cm-count"><b>' + app.day + '</b><span>today</span></p>' +
        '<p class="xhint">Website: ' + web.all + ' browsers, ' + web.week + ' this week. ' +
        (rel ? 'APK downloads from your release link: <b>' + dl + '</b>.' : 'No GitHub release yet, so no download count.') +
        ' A phone counts once it opens an app version from today on; one that deleted the app stays in the total, so "this week" is the real number.</p>' +
        '<p class="xhint" id="cm-me">' + thisDevice() + ' <button class="linkish" type="button" data-cping="1">Count this device now</button></p>';
    }, function (e) { box.innerHTML = '<p class="xhint">Couldn\'t count: ' + esc(e.message) + '</p>'; });
  }

  var PAGES_MSGS = 'https://kewlsky.github.io/ss-study/messages.json';
  function gh(path, opt) {
    opt = opt || {};
    return fetch('https://api.github.com/repos/' + REPO + path, { method: opt.method || 'GET', cache: 'no-store',
      headers: { Authorization: 'Bearer ' + GH, Accept: 'application/vnd.github+json' }, body: opt.body ? JSON.stringify(opt.body) : undefined })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (r.ok) { if (j && typeof j === 'object') j._exp = r.headers.get('github-authentication-token-expiration'); return j; }
          var e = new Error(j.message || 'GitHub answered ' + r.status); e.status = r.status; throw e;
        });
      });
  }
  var sent = null;   // the messages: {sha (when read through GitHub), list}
  function b64e(s) { return btoa(unescape(encodeURIComponent(s))); }
  function readSent() {
    if (!GH) return fetch(PAGES_MSGS + '?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : []; }).then(function (l) { return (sent = { sha: null, list: l || [] }); });
    return gh('/contents/messages.json?ref=main&t=' + Date.now()).then(function (f) {
      return (sent = { sha: f.sha, list: JSON.parse(decodeURIComponent(escape(atob(String(f.content).replace(/\s/g, ''))))) || [] });
    }, function (e) { if (e.status === 404) return (sent = { sha: null, list: [] }); throw e; });
  }
  function writeSent(list, why) {
    var body = { message: why, content: b64e(JSON.stringify(list, null, 2) + '\n'), branch: 'main' };
    if (sent.sha) body.sha = sent.sha;
    return gh('/contents/messages.json', { method: 'PUT', body: body }).then(function (r) { sent = { sha: r.content.sha, list: list }; });
  }
  function drawSent() {
    var box = $('cm-list');
    if (!box || !sent) return;
    box.innerHTML = sent.list.length ? sent.list.slice().reverse().map(function (m) {
      return '<article class="ulog"><div class="ulog-top"><b>' + esc(m.title || '') + '</b><span class="mono">' + esc(m.date || '') + '</span></div><p>' + esc(m.text || '').replace(/\n/g, '<br>') + '</p>' +
        (m.until ? '<p class="xhint">Hidden after ' + esc(m.until) + '</p>' : '') + (GH ? '<button class="btn ghost" type="button" data-cdel="' + esc(m.id) + '">Delete</button>' : '') + '</article>';
    }).join('') : '<p class="xhint">No messages yet.</p>';
  }
  function cmState(html) { var s = $('cm-state'); if (s) s.innerHTML = html; }
  function renderCreator() {
    setBar('Messages & ringtone', 'Creator · only you see this');
    view.innerHTML = '<section class="screen"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">Creator mode · only you see this</span><h1>Hi, ' + CREATOR + '</h1>' +
      '<p>Send a message to everyone who has the app, and choose the ringtone their phones play.</p></div>' +
      '<h3 class="wpick">New message</h3><div class="compose">' +
      '<input id="cm-title" type="text" maxlength="80" placeholder="Title" aria-label="Message title">' +
      '<textarea id="cm-text" class="wtype" rows="4" maxlength="800" placeholder="What do you want to tell everyone?" aria-label="Message"></textarea>' +
      '<label class="cm-until"><span>Hide it after (optional)</span><input id="cm-until" type="date"></label></div>' +
      '<div class="xacts"><button class="btn big" type="button" data-csend="1">Send to everyone</button></div>' +
      '<p class="xhint" id="cm-state" aria-live="polite">It reaches phones in about half a minute, even with the app closed and the phone asleep, and rings on the alarm volume, so silent mode doesn\'t stop it. Messages are public on the update site: never send anything private.</p>' +
      (GH ? '<p class="xhint">Sending from this ' + (window.SSApp ? 'phone' : 'browser') + ' is on. <button class="linkish" type="button" data-cgh="off">Turn it off</button></p>' +
          '<p class="cm-exp' + (keyLeft() <= 14 ? ' soon' : '') + '"><span>' + (keyLeft() > 0 ? 'GitHub key: <b>' + keyLeft() + (keyLeft() === 1 ? ' day' : ' days') + ' left</b>' : '<b>GitHub key expired</b>') +
          '</span><label>Expires <input type="date" id="cm-ghexp" value="' + new Date(store.ghExp).toISOString().slice(0, 10) + '" aria-label="GitHub key expires on"></label></p>'
        : '<details class="cm-gh" id="cm-gh"><summary>Turn on sending from this ' + (window.SSApp ? 'phone' : 'browser') + ' (once)</summary>' +
          '<p>Messages live on your GitHub update site, so GitHub has to let this phone change it. Make a key that can only do that:</p>' +
          '<ol><li>github.com → your picture → <b>Settings</b> → <b>Developer settings</b> → <b>Personal access tokens</b> → <b>Fine-grained tokens</b> → <b>Generate new token</b>.</li>' +
          '<li>Repository access: <b>Only select repositories</b> → <b>ss-study</b>. Permissions: <b>Contents</b> → <b>Read and write</b>.</li>' +
          '<li>Generate, copy it, paste it here. It stays on this ' + (window.SSApp ? 'phone' : 'browser') + '.</li></ol>' +
          '<input id="cm-ghkey" type="password" autocomplete="off" placeholder="github_pat_…" aria-label="GitHub key">' +
          '<label class="cm-until"><span>It expires on</span><input type="date" id="cm-ghexp0" value="' + new Date(Date.now() + 90 * DAY).toISOString().slice(0, 10) + '"></label><div class="xacts"><button class="btn" type="button" data-cgh="save">Save</button></div></details>') +
      '<h3 class="wpick">Who has the app</h3><div id="cm-count"><p class="xhint">Counting…</p></div>' +
      '<h3 class="wpick">Sent</h3><div id="cm-list"><p class="xhint">Loading…</p></div>' +
      '<h3 class="wpick">Ringtone · everyone hears it</h3><p class="xhint">Every phone with the app plays it for your messages and for its reminders, for as long as you set below, even on silent. ' +
      'Phones download a new one in about a minute. It is kept on your public update site, so anyone could download it.</p>' +
      '<p class="cm-song"><span class="mono">Now</span><b id="cm-ring">…</b></p>' +
      '<label class="cm-until"><span>Rings for (seconds)</span><span class="cm-secs"><input id="cm-ringsecs" type="number" min="1" step="1" value="' + ringSecs + '" inputmode="numeric">' +
      '<button class="btn" type="button" data-cring="secs">Save</button></span></label>' +
      '<label class="cm-until"><span>Start the clip at (seconds into the song)</span><input id="cm-ringstart" type="number" min="0" step="1" value="0" inputmode="numeric"></label>' +
      '<div class="xacts"><button class="btn big" type="button" data-cring="pick">Choose a song</button><button class="btn ghost" type="button" data-cring="off">Use the alarm tone</button>' +
      (window.SSApp && window.SSApp.testReminder ? '<button class="btn ghost" type="button" data-csong="test">Play a test reminder</button>' : '') +
      '</div><p class="xhint" id="cm-songstate" aria-live="polite"></p>' +
      '<h3 class="wpick">This ' + (window.SSApp ? 'phone' : 'browser') + '</h3><p class="xhint">Creator mode comes from your creator file. To make this ' + (window.SSApp ? 'phone' : 'browser') + ' normal again, turn it off here.</p>' +
      '<div class="xacts"><button class="btn ghost" type="button" data-cforget="1">Turn off creator mode here</button></div></section>';
    if (sent) drawSent();
    loadRing();
    loadCount();
    readSent().then(drawSent, function (e) { var b = $('cm-list'); if (b) b.innerHTML = '<p class="xhint">Couldn\'t load them: ' + esc(e.message) + '</p>'; });
  }
  /* the ringtone everyone hears: ring.json + ring/ring-<v>.mp3 on the update site; the app downloads it (Sound.refresh) */
  function songState(html) { var s = $('cm-songstate'); if (s) s.innerHTML = html; }
  var ringSecs = 25, MAX_SECS = 55;   // how long phones ring (ring.json "secs"); the shared clip is always MAX_SECS long,
  // so this can change any time. Android stops a background app's work after about a minute, hence the 55 s ceiling.
  function secsWanted() { var n = Math.round(parseFloat(($('cm-ringsecs') || {}).value)); return n >= 1 ? Math.min(n, MAX_SECS) : 0; }
  function secsTyped() { return Math.round(parseFloat(($('cm-ringsecs') || {}).value)) || 0; }
  function loadRing() {
    fetch('https://kewlsky.github.io/ss-study/ring.json?t=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : {}; })
      .then(function (r) {
        var b = $('cm-ring'); if (b) b.textContent = r.file ? r.name || 'your song' : 'The phone\'s alarm tone';
        if (r.secs) { ringSecs = r.secs; var i = $('cm-ringsecs'); if (i && document.activeElement !== i) i.value = r.secs; }
      }, function () { var b = $('cm-ring'); if (b) b.textContent = '?'; });
  }
  function bytesB64(b) { var s = ''; for (var i = 0; i < b.length; i += 32768) s += String.fromCharCode.apply(null, b.subarray(i, i + 32768)); return btoa(s); }
  function b64Bytes(t) { var bin = atob(t), b = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i); return b; }
  function mp3Clip(b, start, len) {   // the MP3 frames from `start` seconds for `len` seconds (no re-encoding), or null if it isn't an MP3
    var i = 0, t = 0, from = -1, to = -1, frames = 0;
    if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) i = 10 + ((b[6] & 127) << 21 | (b[7] & 127) << 14 | (b[8] & 127) << 7 | (b[9] & 127));   // skip the ID3 tag
    var V1 = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320], V2 = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160];
    var SR = { 3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000] };
    while (i + 4 <= b.length) {
      if (b[i] !== 0xFF || (b[i + 1] & 0xE0) !== 0xE0) { i++; continue; }
      var ver = (b[i + 1] >> 3) & 3, layer = (b[i + 1] >> 1) & 3, bri = b[i + 2] >> 4, sri = (b[i + 2] >> 2) & 3, pad = (b[i + 2] >> 1) & 1;
      if (ver === 1 || layer !== 1 || bri === 0 || bri === 15 || sri === 3) { i++; continue; }
      var sr = SR[ver][sri], size = Math.floor((ver === 3 ? 144000 : 72000) * (ver === 3 ? V1 : V2)[bri] / sr) + pad;
      if (size < 24) { i++; continue; }
      var head = String.fromCharCode.apply(null, b.subarray(i + 4, i + 40));
      if (frames === 0 && /Xing|Info|VBRI/.test(head)) { i += size; frames++; continue; }   // a header frame, not sound
      frames++;
      if (from < 0 && t >= start) from = i;
      t += (ver === 3 ? 1152 : 576) / sr;
      i += size;
      if (from >= 0 && t >= start + len) { to = i; break; }
    }
    return frames > 20 && from >= 0 ? b.slice(from, to < 0 ? Math.min(i, b.length) : to) : null;
  }
  function ghJson(path) {   // a JSON file in the repo with its sha, or null when it isn't there
    return gh('/contents/' + path + '?ref=main&t=' + Date.now()).then(function (f) {
      return { sha: f.sha, data: JSON.parse(decodeURIComponent(escape(atob(String(f.content).replace(/\s/g, ''))))) };
    }, function (e) { if (e.status === 404) return null; throw e; });
  }
  function setRing(info, why) {   // writes ring.json, then deletes the song file it replaced
    return ghJson('ring.json').then(function (old) {
      var body = { message: why, content: b64e(JSON.stringify(info) + '\n'), branch: 'main' };
      if (old) body.sha = old.sha;
      return gh('/contents/ring.json', { method: 'PUT', body: body }).then(function () {
        var was = old && old.data && old.data.file;
        if (!was || was === info.file) return;
        return gh('/contents/' + was + '?ref=main').then(function (f) {
          return gh('/contents/' + was, { method: 'DELETE', body: { message: 'Remove the old ringtone', sha: f.sha, branch: 'main' } });
        }).catch(function () {});
      });
    });
  }
  function shareRing(bytes, name) {
    var start = Math.max(0, parseFloat(($('cm-ringstart') || {}).value) || 0), clip = mp3Clip(bytes, start, MAX_SECS), secs = secsWanted() || ringSecs;
    if (!clip) {
      if (bytes.length > 1.5 * 1048576) { songState('That one can\'t be trimmed and is too big to share. Pick an MP3.'); return; }
      clip = bytes;
    }
    var v = Math.floor(Date.now() / 1000), path = 'ring/ring-' + v + '.mp3';
    songState('Sharing ' + esc(name) + ' (' + Math.max(1, Math.round(clip.length / 1024)) + ' KB)…');
    gh('/contents/' + path, { method: 'PUT', body: { message: 'Ringtone: ' + name, content: bytesB64(clip), branch: 'main' } })
      .then(function () { return setRing({ v: v, file: path, name: name, secs: secs }, 'Ringtone: ' + name); })
      .then(function () {
        ringSecs = secs; songState('<b>Shared.</b> Phones download it in about a minute. It rings for ' + secs + ' seconds.');
        var b = $('cm-ring'); if (b) b.textContent = name;
        if (window.SSApp && window.SSApp.refreshRing) setTimeout(window.SSApp.refreshRing, 90000);   // this phone: the trimmed copy
      }, function (e) { songState('Not shared: ' + esc(e.message)); });
  }
  var ringPending = false;
  window.onSong = function (name) {   // the app copied the song the creator picked
    if (top().t !== 'creator') return;
    if (!name) { ringPending = false; songState('No song was chosen.'); return; }
    if (ringPending && window.SSApp.songBase64) { ringPending = false; shareRing(b64Bytes(window.SSApp.songBase64()), name); }
    else songState('Saved on this phone. Install the newest app version to share it with everyone.');
  };
  function pickRing() {
    if (!GH) { songState('Turn on sending first (under New message): sharing a ringtone needs the same GitHub key.'); var d = $('cm-gh'); if (d) d.open = true; return; }
    if (window.SSApp && window.SSApp.pickSong) { ringPending = true; window.SSApp.pickSong(); return; }
    var input = document.createElement('input');
    input.type = 'file'; input.accept = 'audio/*,.mp3'; input.style.display = 'none';
    input.addEventListener('change', function () {
      var f = input.files && input.files[0];
      if (input.parentNode) input.parentNode.removeChild(input);
      if (!f) return;
      if (f.size > 15 * 1048576) { songState('That file is over 15 MB. Pick a smaller MP3.'); return; }
      var r = new FileReader();
      r.onload = function () { shareRing(new Uint8Array(r.result), f.name.replace(/\.[a-z0-9]+$/i, '')); };
      r.readAsArrayBuffer(f);
    });
    document.body.appendChild(input);
    input.click();
  }
  var sending = false;
  function creatorClick(t) {
    var el;
    if (t.closest('[data-creator]')) { go({ t: 'creator' }); return true; }
    if (t.closest('[data-csend]')) {
      if (sending) return true;
      var title = $('cm-title').value.trim(), text = $('cm-text').value.trim(), until = $('cm-until').value;
      if (!title || !text) { cmState('Write a title and a message first.'); return true; }
      if (!GH) { cmState('Turn on sending from this phone first (just below), or ask Claude to send it.'); var d = $('cm-gh'); if (d) d.open = true; return true; }
      var now = new Date(), msg = { id: 'm' + Math.floor(now / 1000), date: now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }), title: title, text: text };
      if (until) msg.until = until;
      sending = true; cmState('Sending…');
      readSent().then(function () { return writeSent(sent.list.concat([msg]).slice(-20), 'Message: ' + title); }).then(function () {
        sending = false;
        store.msgSeen = (store.msgSeen || []).concat([msg.id]); save();   // you wrote it: this phone doesn't need to ring
        if (window.SSApp.seenMessages) window.SSApp.seenMessages(JSON.stringify(store.msgSeen));
        $('cm-title').value = ''; $('cm-text').value = ''; $('cm-until').value = '';
        cmState('<b>Sent.</b> Phones get it in about half a minute.');
        drawSent();
      }, function (e) {
        sending = false;
        cmState('Not sent: ' + esc(e.message) + (e.status === 401 || e.status === 403 ? '. Check the GitHub key: ss-study only, Contents: Read and write.' : ''));
      });
      return true;
    }
    if ((el = t.closest('[data-cgh]'))) {
      if (el.getAttribute('data-cgh') === 'off') { delete store.gh; delete store.ghExp; delete store.ghSaved; delete store.ghNag; save(); GH = ''; render(); return true; }
      var key = $('cm-ghkey').value.trim();
      if (!key) return true;
      GH = key; cmState('Checking the key with GitHub…');
      gh('').then(function (repo) {
        if (!(repo.permissions && repo.permissions.push)) throw new Error('that key can\'t change ' + REPO);
        var exp = repo._exp && Date.parse(repo._exp.replace(' UTC', 'Z').replace(' ', 'T')), typed = $('cm-ghexp0') && $('cm-ghexp0').value;
        store.gh = key; store.ghSaved = Date.now(); store.ghNag = 0;
        store.ghExp = exp || (typed ? Date.parse(typed + 'T12:00:00') : Date.now() + 90 * DAY);
        save(); render(); cmState('<b>Sending is on.</b> Write your message above.');
      }).catch(function (e) { GH = ''; cmState('That key didn\'t work: ' + esc(e.message)); });
      return true;
    }
    if ((el = t.closest('[data-cdel]'))) {
      var id = el.getAttribute('data-cdel');
      el.disabled = true; cmState('Deleting…');
      readSent().then(function () { return writeSent(sent.list.filter(function (m) { return m.id !== id; }), 'Delete a message'); })
        .then(function () { cmState('Deleted. Phones that already showed it keep the notification.'); drawSent(); }, function (e) { el.disabled = false; cmState('Not deleted: ' + esc(e.message)); });
      return true;
    }
    if (t.closest('[data-cping]')) {
      var me = $('cm-me'); if (me) me.textContent = 'Counting this device…';
      checkIn(true, function () { loadCount(); });
      return true;
    }
    if ((el = t.closest('[data-cring]'))) {
      if (el.getAttribute('data-cring') === 'pick') { pickRing(); return true; }
      if (!GH) { songState('Turn on sending first (under New message).'); return true; }
      if (el.getAttribute('data-cring') === 'secs') {
        var n = secsWanted();
        if (!n) { songState('Type how many seconds, for example 10.'); return true; }
        var capped = secsTyped() > MAX_SECS;
        if (capped) $('cm-ringsecs').value = n;
        songState('Saving…');
        ghJson('ring.json').then(function (old) {
          var d = old && old.data || { file: '', name: '' };
          return setRing({ v: Math.floor(Date.now() / 1000), file: d.file || '', name: d.name || '', secs: n }, 'Ring for ' + n + ' seconds');
        }).then(function () {
          ringSecs = n;
          songState('<b>Saved.</b> Phones ring for ' + n + ' seconds from about a minute from now.' +
            (capped ? ' (55 is the longest: Android stops an app\'s background work after about a minute.)' : ''));
        },
          function (e) { songState('Not saved: ' + esc(e.message)); });
        return true;
      }
      songState('Switching everyone to the alarm tone…');
      setRing({ v: Math.floor(Date.now() / 1000), file: '', name: '', secs: secsWanted() || ringSecs }, 'Ringtone: the alarm tone').then(function () {
        if (window.SSApp && window.SSApp.clearSong) window.SSApp.clearSong();
        var b = $('cm-ring'); if (b) b.textContent = 'The phone\'s alarm tone';
        songState('<b>Done.</b> Phones switch back to their alarm tone when the app opens or within half an hour.');
      }, function (e) { songState('Not changed: ' + esc(e.message)); });
      return true;
    }
    if (t.closest('[data-csong]')) {
      pushReminders(); window.SSApp.testReminder(); songState('Playing… open the app or swipe the notification away to stop it.');
      return true;
    }
    if (t.closest('[data-cforget]')) {
      if (window.SSApp && window.SSApp.forgetCreator) window.SSApp.forgetCreator();
      delete store.creatorKey; delete store.gh; delete store.creatorHi; save();
      readCreator(); stack.length = 1; render(true);
      if (ME) queueSheet(function () { sheet('Creator mode', 'Still on', '<p>Your creator file is also in Android/data/com.study.cnshub/files. Delete creator.txt there too.</p>'); });
      return true;
    }
    return false;
  }
  document.addEventListener('change', function (e) {
    if (!e.target || e.target.id !== 'cm-ghexp' || !e.target.value) return;
    store.ghExp = Date.parse(e.target.value + 'T12:00:00'); store.ghNag = 0; save(); render();
  });
  var vtaps = 0, vtapAt = 0;   // the Updates page: tap "You have v…" 5 times to choose the creator file (phone or browser)
  function versionTap() {
    var now = Date.now();
    vtaps = now - vtapAt < 1500 ? vtaps + 1 : 1; vtapAt = now;
    if (vtaps >= 5) { vtaps = 0; pickCreator(); }
  }
  function renderUpdates() {
    setBar('Updates', 'SS Study · v' + APPV);
    var h = '<section class="screen"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow" data-vtap="1">You have v' + esc(APPV) +
      (window.BUILT ? ' · content of ' + new Date(window.BUILT).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) : '') +
      (!WEB && location.protocol === 'file:' ? (location.href.indexOf('/android_asset/') >= 0 ? ' · built into the app' : ' · downloaded update') : '') + '</span><h1>Updates</h1><p>' +
      (WEB ? 'The website always opens the newest version.' : 'The app checks by itself every time it opens with internet. You can also check now, without closing the app.') + '</p></div>';
    if (!WEB) h += '<div class="xacts"><button class="btn big" type="button" data-ucheck="1">Check for updates</button></div><div class="ustate" id="ustate" aria-live="polite"></div>';
    h += '<h3 class="wpick">Update log</h3>';
    UPD.forEach(function (u, i) {
      h += '<article class="ulog' + (i ? '' : ' now') + '"><div class="ulog-top"><b>v' + esc(u.version) + (i ? '' : ' · current') + '</b><span class="mono">' + esc(u.date) + '</span></div>' + notes(u) + '</article>';
    });
    view.innerHTML = h + '</section>';
  }
  window.onUpdateCheck = function (r) {   // the app's answer to SSApp.check(): {status: latest | available | apk | offline | error, name, size}
    var st = $('ustate');
    if (!st) {   // a quiet check (coming back to the app): only speak up when there is something new
      if (r.status === 'available') queueSheet(function () {
        sheet('Update ready', 'v' + (r.name || 'new') + ' is ready', '<p>' + (r.size ? (r.size / 1048576).toFixed(1) + ' MB. ' : '') + 'It takes a few seconds and keeps your progress.</p>',
          [['Update now', 'data-uinstall'], ['Later', 'data-wnok']]);
      });
      return;
    }
    st.innerHTML = r.status === 'latest' ? '<p>You have the newest version.</p>'
      : r.status === 'available' ? '<p><b>v' + esc(r.name || 'new') + ' is ready</b>' + (r.size ? ' (' + (r.size / 1048576).toFixed(1) + ' MB)' : '') + '.</p><button class="btn big" type="button" data-uinstall="1">Download and install</button>'
      : r.status === 'apk' ? '<p><b>A new app version is ready.</b> It needs a quick install.</p><button class="btn big" type="button" data-uapk="1">Download the app</button>'
      : r.status === 'offline' ? '<p>No internet right now. Try again when you are online.</p>'
      : '<p>Could not reach the update server. Try again in a bit.</p>';
  };
  function updatesClick(t) {
    if (t.closest('[data-updates]')) { go({ t: 'updates' }); return true; }
    if (t.closest('[data-vtap]')) { versionTap(); return true; }
    if (t.closest('[data-ucheck]')) {
      var st = $('ustate');
      if (window.SSApp) { st.innerHTML = '<p>Checking…</p>'; window.SSApp.check(); }
      else st.innerHTML = '<p>This button needs the newest app. <a href="https://kewlsky.github.io/ss-study/get.html">Download it</a>, then install it over this one.</p>';
      return true;
    }
    if (t.closest('[data-uinstall]') && window.SSApp) { window.SSApp.install(); return true; }
    if (t.closest('[data-uapk]') && window.SSApp) { window.SSApp.openApk(); return true; }
    return false;
  }

  /* ---------- exams and reminders: a countdown on the Study home and, in the app, notifications that nag ---------- */
  var EXAMS0 = window.EXAMS || [{ name: 'OSPE', date: '' }, { name: 'EBE', date: '' }];   // content/exams.json
  if (!store.exams) store.exams = EXAMS0.map(function (x) { return { name: x.name, date: x.date || '' }; });
  EXAMS0.forEach(function (d) {   // a date added to the app later fills in an exam you left empty
    store.exams.forEach(function (x) { if (x.name === d.name && !x.date && d.date) x.date = d.date; });
  });
  if (!store.remind) store.remind = { on: false, loud: true, times: ['20:00'] };
  function daysTo(date) {   // whole days from today to YYYY-MM-DD; null when there is no valid date
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date || '');
    if (!m) return null;
    var now = new Date();
    return Math.round((new Date(+m[1], +m[2] - 1, +m[3]) - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 864e5);
  }
  function comingExams() {   // exams still ahead, soonest first: {name, d (days), needs}
    var out = [];
    store.exams.forEach(function (x) { var d = daysTo(x.date); if (x.name && d != null && d >= 0) out.push({ name: x.name, d: d, needs: needsOf(x.name) }); });
    return out.sort(function (a, b) { return a.d - b.d; });
  }
  function nextExam() { return comingExams()[0] || null; }
  function needsOf(name) {   // what an exam tests (content/exams.json): {subjects: [...], idHas: 'prelab', label}; none = every lecture
    for (var i = 0; i < EXAMS0.length; i++) if (EXAMS0[i].name === name && EXAMS0[i].needs) return EXAMS0[i].needs;
    return null;
  }
  function lecLeft(needs) {   // lectures with cards still unticked, among the ones this exam needs (Mix-ups is extra, never counted)
    var n = 0, total = 0, seen = {};   // an exam with needs (the OSPE) also counts the OSPE tab's picture-spotting lectures
    (needs ? CAT.concat(OCAT.filter(function (s) { return s.id !== 'prelab'; })) : CAT).forEach(function (s) {
      if (s.id === 'mix') return;
      s.lectures.forEach(function (l) {
        if (needs && needs.subjects.indexOf(s.id) < 0 && !(needs.idHas && l.id.indexOf(needs.idHas) >= 0) && (needs.lectures || []).indexOf(l.id) < 0) return;
        if (seen[l.id]) return;   // the OSPE tab shows some Study lectures again: count them once
        seen[l.id] = 1;
        if (!needs && l.id.indexOf('prelab') >= 0) return;   // the EBE doesn't test the prelabs (they are OSPE)
        total++; if (doneIn(l.id) < l.cards) n++;
      });
    });
    return { n: n, total: total };
  }
  function inDays(d) { return d === 0 ? 'is TODAY' : d === 1 ? 'is TOMORROW' : 'is in ' + d + ' days'; }
  function lecs(n) { return n + (n === 1 ? ' lecture' : ' lectures'); }
  var canNag = !!(window.SSApp && window.SSApp.setReminders), sentNag = '';
  function pushReminders() {   // the app keeps a copy of the soonest exam and what it still needs, so it can nag while closed
    if (!canNag) return;
    var r = store.remind, x = nextExam(), left = lecLeft(x && x.needs);
    var json = JSON.stringify({ on: !!r.on, loud: !!r.loud, times: r.times, left: left.n, total: left.total,
      exams: store.exams.filter(function (e) { return x && e.name === x.name; }) });
    if (json !== sentNag) { sentNag = json; window.SSApp.setReminders(json); }
  }
  function examBanner() {
    var xs = comingExams().slice(0, 2);
    if (!xs.length) return '<button class="countdown none" type="button" data-remind="1"><b>When are your exams?</b><span>Set the dates for a countdown and reminders</span></button>';
    return xs.map(function (x, i) {
      var left = lecLeft(x.needs), what = x.needs ? ' (' + x.needs.label + ')' : '';
      return '<button class="countdown' + (x.d <= 3 ? ' soon' : '') + (i ? ' later' : '') + '" type="button" data-remind="1"><b>The ' + esc(x.name) + ' ' + inDays(x.d) + '</b><span>' +
        (left.n ? 'and you still have ' + left.n + ' of ' + lecs(left.total) + esc(what) + ' to finish' : 'All ' + lecs(left.total) + esc(what) + ' finished. Keep it warm with a mock exam') + '</span></button>';
    }).join('');
  }
  function renderRemind() {
    setBar('Exams & reminders', 'SS Study');
    var r = store.remind, x = nextExam(), left = lecLeft(x && x.needs);
    var h = '<section class="screen"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">' + (x ? 'The ' + esc(x.name) + ' ' + inDays(x.d) : 'No exam date yet') + '</span><h1>Exams &amp; reminders</h1>' +
      '<p>Set your exam dates. The Study home counts down, and the app can nag you while lectures are still unfinished.</p></div><h3 class="wpick">Exam dates</h3><div class="exlist">';
    store.exams.forEach(function (e, i) {
      h += '<div class="exrow"><input type="text" data-exname="' + i + '" value="' + esc(e.name) + '" placeholder="Exam name" aria-label="Exam name">' +
        '<input type="date" data-exdate="' + i + '" value="' + esc(e.date) + '" aria-label="Date of ' + esc(e.name || 'the exam') + '">' +
        '<button type="button" class="btn ghost" data-exdel="' + i + '" aria-label="Remove ' + esc(e.name || 'this exam') + '">✕</button></div>' +
        (needsOf(e.name) ? '<p class="exneeds">Counts ' + esc(needsOf(e.name).label) + ' (' + lecs(lecLeft(needsOf(e.name)).total) + ')</p>' : '');
    });
    h += '</div><button class="btn ghost" type="button" data-exadd="1">+ Add an exam</button><h3 class="wpick">Reminders</h3>';
    if (!canNag) h += '<p class="xhint">' + (WEB ? 'Reminders and sounds work in the phone app. Here you still get the countdown.' : 'Reminders need the newest app. Install the new version when the app offers it.') + '</p>';
    else {
      h += '<label class="switch"><input type="checkbox" data-rem="on"' + (r.on ? ' checked' : '') + '><span><b>Remind me</b><span>A notification at the times below while an exam is coming</span></span></label>' +
        '<label class="switch"><input type="checkbox" data-rem="loud"' + (r.loud ? ' checked' : '') + '><span><b>Ring even when my phone is on silent</b><span>Plays through the alarm volume, like an alarm clock</span></span></label><div class="exlist">';
      r.times.forEach(function (t, i) {
        h += '<div class="exrow time"><span>Remind me at</span><input type="time" data-remtime="' + i + '" value="' + esc(t) + '" aria-label="Reminder time ' + (i + 1) + '">' +
          (r.times.length > 1 ? '<button type="button" class="btn ghost" data-remdel="' + i + '" aria-label="Remove this time">✕</button>' : '<span></span>') + '</div>';
      });
      h += '</div>' + (r.times.length < 4 ? '<button class="btn ghost" type="button" data-remadd="1">+ Add another time</button>' : '') +
        '<div class="xacts"><button class="btn big" type="button" data-remtest="1">Send a test reminder now</button></div><p class="xhint" id="remstate" aria-live="polite">' +
        (x ? 'It will say something like: "The ' + esc(x.name) + ' ' + inDays(x.d) + (left.n ? ' and you STILL haven\'t finished ' + lecs(left.n) + '."' : '. All lectures done."')
          : 'Add an exam date first: reminders only go out while an exam is coming.') + '</p>';
    }
    view.innerHTML = h + '</section>';
  }
  function remindClick(t) {
    var el, r = store.remind;
    if (t.closest('[data-remind]')) { go({ t: 'remind' }); return true; }
    if (top().t !== 'remind') return false;
    if (t.closest('[data-exadd]')) store.exams.push({ name: '', date: '' });
    else if ((el = t.closest('[data-exdel]'))) store.exams.splice(+el.getAttribute('data-exdel'), 1);
    else if (t.closest('[data-remadd]')) r.times.push('08:00');
    else if ((el = t.closest('[data-remdel]'))) r.times.splice(+el.getAttribute('data-remdel'), 1);
    else if (t.closest('[data-remtest]')) {
      pushReminders(); window.SSApp.testReminder();
      $('remstate').textContent = 'Sent. If nothing shows up, allow notifications for SS Study in your phone settings.';
      return true;
    } else return false;
    save(); pushReminders(); renderRemind();
    return true;
  }
  function remindInput(e) {   // typing a name, picking a date or time, flipping a switch: saved at once, no redraw (keeps the keyboard open)
    var t = e.target, a = function (n) { return t.getAttribute && t.getAttribute(n); }, r = store.remind;
    if (a('data-exname') != null) store.exams[+a('data-exname')].name = t.value.trim();
    else if (a('data-exdate') != null) store.exams[+a('data-exdate')].date = t.value;
    else if (a('data-remtime') != null) { if (t.value) r.times[+a('data-remtime')] = t.value; }
    else if (a('data-rem')) r[a('data-rem')] = t.checked;
    else return;
    save(); pushReminders();
  }
  document.addEventListener('input', remindInput);
  document.addEventListener('change', remindInput);

  /* ---------- search every card (Study tab) ---------- */
  var query = '';
  function find(qs) {
    var hits = $('hits'), tiles = $('tiles');
    query = qs;
    if (!hits) return;
    var words = qs.toLowerCase().split(/\s+/).filter(function (w) { return w.length > 1; });
    tiles.hidden = !!words.length;
    if (!words.length) { hits.innerHTML = ''; return; }
    if (!window.SEARCH) {   // the index loads the first time you search
      hits.innerHTML = '<p class="loading">Loading the search…</p>';
      if (!find.loading) {
        find.loading = true;
        var sc = document.createElement('script');
        sc.src = 'assets/search.js';
        sc.onload = function () { if (query) find(query); };
        sc.onerror = function () { find.loading = false; hits.innerHTML = '<p class="loading">Search could not be loaded.</p>'; };
        document.body.appendChild(sc);
      }
      return;
    }
    var found = window.SEARCH.filter(function (c) {
      var t = (c[2] + ' ' + c[3]).toLowerCase();
      return words.every(function (w) { return t.indexOf(w) >= 0; });
    });
    found.sort(function (a, b) {   // cards whose title has the word come first
      var at = a[2].toLowerCase().indexOf(words[0]) >= 0, bt = b[2].toLowerCase().indexOf(words[0]) >= 0;
      return at === bt ? 0 : at ? -1 : 1;
    });
    var re = new RegExp('(' + words.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')', 'gi');
    var mark = function (s) { return esc(s).replace(re, '<mark>$1</mark>'); };
    var h = '<p class="mono hitcount">' + (found.length ? found.length + (found.length === 1 ? ' card' : ' cards') + (found.length > 40 ? ', showing the first 40' : '') : 'No card mentions that. Try another word.') + '</p><ul class="hitlist">';
    found.slice(0, 40).forEach(function (c) {
      var f = findLec(c[0]); if (!f) return;
      var t = c[3], at = t.toLowerCase().indexOf(words[0]), from = Math.max(0, at - 50);
      var snip = (from ? '…' : '') + t.slice(from, from + 150) + (from + 150 < t.length ? '…' : '');
      h += '<li><button type="button" class="hit" data-hit="' + esc(c[0] + '|' + c[1]) + '" style="--sc:var(--s-' + f.s.id + ')"><b>' + mark(c[2]) + '</b>' +
        '<span class="mono">' + esc(f.s.name) + ' · ' + esc(f.l.title) + '</span><span class="snip">' + mark(snip) + '</span></button></li>';
    });
    hits.innerHTML = h + '</ul>';
  }
  function openHit(lid, cid) {   // a search result opens its lecture at that card; back returns to the results
    var f = findLec(lid);
    if (!f) return;
    top().y = window.scrollY;
    stack.push({ t: 'subject', sid: f.s.id }, { t: 'lecture', lid: lid, card: cid });
    store[lastKey()] = lid; save(); render(true);
  }

  /* ---------- Question bank tab: each subject's questions as endless banks (Bank 1, 2, 3…), each with three levels
     (easy, medium, hard) of 10 questions. Pick, check, see why, next. Pass a level (7 of 10) for its star; three stars
     complete the bank and open the next one. Wrong answers come back in later banks until you get them right.
     Two sides: EBE (window.EXAM, text MCQs) and OSPE (window.OSPE: pictures with my arrows; answer by choices or typing). */
  var QB_N = 10, QB_PASS = 0.7, QB_LV = ['Level 1 · easy', 'Level 2 · medium', 'Level 3 · hard'], ABC = 'abcde';
  var QBM = 'ebe';   // which side is showing: 'ebe' or 'ospe'
  function qb() { return store.qb || (store.qb = { best: {}, miss: {} }); }
  function qbSrc(m) { return (m || QBM) === 'ospe' ? window.OSPE : window.EXAM; }
  function qbS(sid) { var a = qbSrc() || []; for (var i = 0; i < a.length; i++) if (a[i].id === sid) return a[i]; return { id: sid, name: sid, qs: [] }; }
  function qbK(sid) { return (QBM === 'ospe' ? 'o:' : '') + sid; }   // where progress is kept (EBE keys stay as before)
  function needJs(name, m, done) {   // exam.js / ospe.js load the first time they are needed
    if (qbSrc(m)) return true;
    view.innerHTML = '<p class="loading">Opening the questions…</p>';
    var sc = document.createElement('script');
    sc.src = 'assets/' + name;
    sc.onload = done;
    sc.onerror = function () { view.innerHTML = '<p class="loading">The questions could not be loaded. Go back and try again.</p>'; };
    document.body.appendChild(sc);
    return false;
  }
  function qbReady() { return needJs(QBM === 'ospe' ? 'ospe.js' : 'exam.js', QBM, function () { if (tab === 'qbank') render(false); }); }
  function seeded(seed) {   // a repeatable random sequence, so Bank 3 is the same Bank 3 every time
    var h = 2166136261;
    for (var i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619); }
    return function () { h += 0x6D2B79F5; var t = h; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  function qbDeck(s, t, cyc) {   // the questions of difficulty t, in this cycle's order (a new order each time round)
    var key = qbK(s.id) + ':' + t + ':' + cyc, d = qbDeck.c[key];
    if (d) return d;
    d = []; s.qs.forEach(function (q, i) { if ((q.lv || 1) === t) d.push(i); });
    var r = seeded(key);
    for (var i = d.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), x = d[i]; d[i] = d[j]; d[j] = x; }
    return (qbDeck.c[key] = d);
  }
  qbDeck.c = {};
  function qbBase(s, bank, lv) {   // bank b, level lv: 10 questions, its own difficulty first, then the nearest ones
    var n = Math.min(QB_N, s.qs.length), out = [];
    [[1, 2, 3], [2, 1, 3], [3, 2, 1]][lv - 1].forEach(function (t) {
      var m = qbDeck(s, t, 0).length, k = Math.min(n - out.length, m);
      for (var x = bank * k, got = 0, guard = 0; got < k && guard < 3 * m; x++, guard++) {
        var qi = qbDeck(s, t, Math.floor(x / m))[x % m];
        if (out.indexOf(qi) < 0) { out.push(qi); got++; }
      }
    });
    return out;
  }
  function qbMiss(sid) { var m = qb().miss || (qb().miss = {}); return m[qbK(sid)] || (m[qbK(sid)] = []); }
  function qbBanks(sid) { return qb().best[qbK(sid)] || (qb().best[qbK(sid)] = []); }   // per bank: [best %, best %, best %]
  function qbPassed(p) { return p != null && p >= QB_PASS * 100; }
  function qbStars(sid, b) { var r = qbBanks(sid)[b] || []; return [0, 1, 2].filter(function (k) { return qbPassed(r[k]); }).length; }
  function qbCurrent(sid) { var b = 0; while (qbStars(sid, b) === 3) b++; return b; }   // the first bank not completed
  function qbOpen(sid, b, lv) { return b <= qbCurrent(sid) && (lv === 1 || qbPassed((qbBanks(sid)[b] || [])[lv - 2])); }
  function starsHtml(n) { return '<span class="qstars" aria-label="' + n + ' of 3 stars">' + [0, 1, 2].map(function (k) { return '<i' + (k < n ? ' class="on"' : '') + '>★</i>'; }).join('') + '</span>'; }
  function qbWhere(q) {   // where a question is taught: {lid, cid, label: 'Anatomy lec 1 · Slide 8', title}
    var lk = q.lk || [], f = lk[0] && findLec(lk[0]);
    if (!f) return null;
    return { lid: lk[0], cid: lk[1] || '', label: f.s.name + ' lec ' + f.n + ' · ' + (lk[1] ? lk[2] || 'the card' : 'all'), title: f.l.title };
  }
  function qbRow(lid, cid, label, sub) {
    return '<li><span class="t"><b>' + esc(label) + '</b><span>' + esc(sub) + '</span></span><button class="btn" type="button" data-qcard="' + esc(lid + '|' + cid) + '">Go</button></li>';
  }
  function qbSpots(sid, list, title, intro) {   // wrong questions grouped by the card that teaches them; 3+ in one lecture: the whole lecture too
    var s = qbS(sid), cards = {}, lecs = {}, order = [], rows = '';
    list.forEach(function (qi) {
      var w = s.qs[qi] && qbWhere(s.qs[qi]);
      if (!w) return;
      var k = w.lid + '|' + w.cid;
      if (!cards[k]) { cards[k] = { w: w, n: 0 }; order.push(k); }
      cards[k].n++;
      (lecs[w.lid] = lecs[w.lid] || { n: 0, w: w }).n++;
    });
    if (!order.length) return '';
    Object.keys(lecs).forEach(function (lid) {
      var x = lecs[lid];
      if (x.n >= 3) rows += qbRow(lid, '', x.w.label.replace(/ · .*$/, ' · all'), x.w.title + ' · ' + x.n + ' wrong here: go over the whole lecture');
    });
    order.sort(function (a, b) { return cards[b].n - cards[a].n; }).forEach(function (k) {
      var c = cards[k];
      rows += qbRow(c.w.lid, c.w.cid, c.w.label, c.w.title + ' · ' + c.n + ' wrong');
    });
    return '<h3 class="wpick">' + title + '</h3>' + (intro ? '<p class="xhint">' + intro + '</p>' : '') + '<ul class="qspots">' + rows + '</ul>';
  }

  /* ---------- OSPE pictures: the picture as it is in the lecture, without its labels, and my own yellow arrows ---------- */
  var picQ = null;   // the question whose picture is on screen (tap it to zoom, arrows included)
  function arrowsSvg(q) {
    if (!q.ar || !q.ar.length) return '';
    var W = q.iw, H = q.ih, sw = Math.max(3, Math.round(Math.min(W, H) / 70)), s = '<svg class="oar" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" aria-hidden="true">';
    q.ar.forEach(function (a) {
      var tx = a[0] * W, ty = a[1] * H, sx = a[2] * W, sy = a[3] * H, dx = tx - sx, dy = ty - sy, L = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / L, uy = dy / L;
      var hl = sw * 4.2, hw = sw * 2.6, bx = tx - ux * hl, by = ty - uy * hl;
      var head = [tx, ty, bx - uy * hw, by + ux * hw, bx + uy * hw, by - ux * hw].map(function (v) { return v.toFixed(1); }).join(' ');
      var line = 'M' + sx.toFixed(1) + ' ' + sy.toFixed(1) + 'L' + bx.toFixed(1) + ' ' + by.toFixed(1);
      s += '<path d="' + line + '" stroke="#000" stroke-width="' + (sw + 4) + '" stroke-linecap="round" fill="none"/><polygon points="' + head + '" fill="#000" stroke="#000" stroke-width="4" stroke-linejoin="round"/>' +
        '<path d="' + line + '" stroke="#ffd400" stroke-width="' + sw + '" stroke-linecap="round" fill="none"/><polygon points="' + head + '" fill="#ffd400"/>';
      if (a[4]) s += '<circle cx="' + sx.toFixed(1) + '" cy="' + sy.toFixed(1) + '" r="' + (sw * 3.2) + '" fill="#ffd400" stroke="#000" stroke-width="3"/>' +
        '<text x="' + sx.toFixed(1) + '" y="' + sy.toFixed(1) + '" dy=".36em" text-anchor="middle" font-size="' + (sw * 3.8) + '" font-weight="700" font-family="sans-serif" fill="#000">' + esc(a[4]) + '</text>';
    });
    return s + '</svg>';
  }
  function picHtml(q) {
    if (!q.img) return '';
    picQ = q;
    return '<button class="opic" type="button" data-opic="1" style="--ar:' + (q.iw / q.ih).toFixed(3) + '" aria-label="Zoom the picture">' +
      '<img src="img/o/' + esc(q.img) + '" alt="OSPE picture" width="' + q.iw + '" height="' + q.ih + '" draggable="false">' + arrowsSvg(q) + '<span class="zoomhint">Tap to zoom</span></button>';
  }
  function onorm(t) {
    return String(t || '').toLowerCase().replace(/α/g, ' alpha ').replace(/β/g, ' beta ').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ')
      .replace(/\b(the|a|an|of|in|on|at|is|its|it)\b/g, ' ').replace(/(\w{3,})s\b/g, '$1').replace(/\s+/g, ' ').trim();
  }
  function lev(a, b) {
    var p = [], i, j;
    for (j = 0; j <= b.length; j++) p[j] = j;
    for (i = 1; i <= a.length; i++) {
      var prev = p[0]; p[0] = i;
      for (j = 1; j <= b.length; j++) { var t = p[j]; p[j] = Math.min(p[j] + 1, p[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = t; }
    }
    return p[b.length];
  }
  function onums(t) { return (String(t || '').replace(/(\d),(?=\d{3}(?!\d))/g, '$1').match(/\d+(?:\.\d+)?/g) || []).map(Number); }   // '1,000 or 22.8' -> [1000, 22.8]
  function oscore(t, tn, a) {   // how well a typed answer (normalised t, its numbers tn) matches one answer form: 0 = not at all
    var n = onorm(a), an = onums(a);
    if (!n) return 0;
    if (an.length && (an.length !== tn.length || an.some(function (v, i) { return Math.abs(v - tn[i]) > Math.abs(v) * 0.015 + 1e-9; }))) return 0;   // the numbers must be right
    if (t === n) return 1000;
    if (an.length) {   // a number answer (the number, rounded or not, and at most its unit)
      var words = function (x) { return x.split(' ').filter(function (w) { return !/^\d+$/.test(w); }); }, nn = words(n), tt = words(t);
      if (nn.length <= 2 && tt.every(function (w) { return nn.indexOf(w) >= 0; })) return 950;
    }
    if (lev(t, n) <= Math.max(1, Math.floor(n.length * 0.2))) return 900;
    var tw = t.split(' '), nw = n.split(' ');
    return tw.length <= nw.length + 2 && nw.every(function (w) { return tw.some(function (x) { return x === w || (w.length > 4 && lev(x, w) <= 1); }); }) ? nw.length : 0;
  }
  function typedOk(typed, acc, wrong) {   // a typed answer counts if it matches an accepted answer (small slips allowed) better than any wrong one
    var t = onorm(typed), tn = onums(typed);
    if (!t) return false;
    var best = function (list) { return (list || []).reduce(function (m, a) { return Math.max(m, oscore(t, tn, a)); }, 0); }, b = best(acc);
    return b > 0 && b > best(wrong);
  }
  function owrong(q) { return (q.o || []).concat(q.x || []); }   // the wrong choices, and other ways of writing them
  function ochoices(q, sid) { return [q.a[0]].concat(q.o.slice(0, sid === 'anat' ? 3 : 4)); }   // anatomy MCQs have 4 options, the rest 5

  /* ---------- Calculation and rule questions (?calc lines in content/ospe-q): each time, one of the slot's types is picked
     and new numbers drawn, from a seed, so the same question comes back in its review. All of it is from the prelab slides. ---------- */
  function oq(q, seed) {
    if (!q || !q.gen) return q;
    var r = seeded(String(seed)), g = OGEN[q.gen[Math.floor(r() * q.gen.length)]], x = g ? g(r) : {}, out = {}, k;
    for (k in q) out[k] = q[k];
    for (k in x) out[k] = x[k];
    return out;
  }
  function cpick(r, a) { return a[Math.floor(r() * a.length)]; }
  function cmix(r, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function cnum(x) { return String(Math.round(x * 100) / 100); }
  function cbig(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }   // 1000000 -> 1,000,000
  function ccm(x) { return cnum(x) + ' cm'; }
  function cdb(x) { return x + ' dB'; }
  function ccap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function cwrong(r, ans, first, more) {   // 4 different wrong choices: the likeliest mistakes first, then others
    var out = [], seen = {};
    seen[String(ans).toLowerCase()] = 1;
    function add(x) { var k = String(x).toLowerCase(); if (x && out.length < 4 && !seen[k] && !/^-|^0 cm$|NaN|Infinity/.test(k)) { seen[k] = 1; out.push(String(x)); } }
    first.forEach(add); cmix(r, more || []).forEach(add);
    return out;
  }
  var LENS = (function () {   // whole-number object distance, focal length and image distance (cm) with 1/o + 1/i = 1/f
    var a = [];
    for (var o = 10; o <= 120; o++) for (var f = 4; f < o; f++) { var i = o * f / (o - f); if (i % 1 === 0 && i <= 240 && i !== o) a.push([o, f, i]); }
    return a;
  })();
  function lensSized(r) {   // a lens set-up and an object height whose image height comes out in tenths
    for (var k = 0; k < 80; k++) {
      var t = cpick(r, LENS), h = cpick(r, [2, 3, 4, 5, 6, 8, 10, 12]), H = h * t[2] / t[0];
      if (Math.abs(H * 10 - Math.round(H * 10)) < 1e-9 && H !== h) return { o: t[0], f: t[1], i: t[2], h: h, H: Math.round(H * 10) / 10 };
    }
    return { o: 30, f: 20, i: 60, h: 4, H: 8 };
  }
  var SNELLEN = [60, 36, 24, 18, 12, 9];
  var ISH = { 1: ['12', '12', '12'], 2: ['29', '70', 'X'], 3: ['5', '2', 'X'], 4: ['6', 'X', 'X'], 5: ['7', 'X', 'X'], 6: ['X', '5', 'X'] };   // normal, red-green, total
  var ISH_X = ['x', 'cannot read it', 'cannot read', 'can not read it', 'cant read it', 'nothing', 'unreadable', 'not readable'];
  function ishRead(v) { return v === 'X' ? 'Cannot read it (X)' : v; }
  function ishRd(v) { return v === 'X' ? 'cannot read it' : 'reads ' + v; }
  function ishSay(p, v) { return v === 'X' ? 'cannot read plate ' + p : 'reads plate ' + p + ' as ' + v; }
  function ishWhy(p) { return 'Plate ' + p + ': a normal person ' + ishRd(ISH[p][0]) + ', red-green deficiency ' + ishRd(ISH[p][1]) + ', total colour blindness ' + ishRd(ISH[p][2]) + '.'; }
  var DB = [[0, '0.0002', 'the absolute threshold of hearing', 'The absolute threshold', ['threshold', 'absolute threshold', 'threshold of hearing']],
    [20, '0.002', 'a faint whisper', 'A faint whisper', ['whisper', 'faint whisper']],
    [40, '0.02', 'a quiet office', 'A quiet office', ['quiet office', 'office']],
    [60, '0.2', 'ordinary conversation', 'Conversation', ['conversation', 'normal conversation', 'talking']],
    [80, '2', 'a city bus', 'A city bus', ['city bus', 'bus']],
    [100, '20', 'a subway train', 'A subway train', ['subway train', 'subway', 'train']],
    [120, '200', 'loud thunder', 'Loud thunder', ['thunder', 'loud thunder']],
    [140, '2,000', 'the level that causes pain and damage', 'Pain and damage', ['pain', 'pain and damage', 'damage', 'pain threshold']]];
  function dbWrong(r, L) { return cwrong(r, cdb(L), [cdb(L / 2), cdb(L + 20), cdb(L - 20)], [0, 20, 40, 60, 80, 100, 120, 140].map(cdb)); }
  function forkFacts(E, O, cond) {   // [what is true, what is false] for deafness of ear E: each [shown text, typed forms]
    var weber = function (s) { return ['Weber\'s test lateralises to the ' + s + ' ear', ['weber ' + s, 'weber to ' + s, 'weber to ' + s + ' ear', 'weber lateralises to ' + s, 'weber lateralises to ' + s + ' ear', 'weber louder in ' + s + ' ear', s + ' weber']]; };
    var equal = ['Weber\'s test is heard equally on both sides', ['weber equal', 'weber central', 'weber midline', 'weber in middle', 'weber heard equally', 'weber centre', 'weber center', 'weber not lateralised']];
    var rneg = ['Rinne\'s test is negative in the ' + E + ' ear (BC > AC)', ['rinne negative', 'negative rinne', 'rinne negative in ' + E + ' ear', 'rinne ' + E + ' negative', 'bc > ac', 'bc more than ac', 'bone better than air', 'bone more than air']];
    var rpos = ['Rinne\'s test is positive in the ' + E + ' ear (AC > BC)', ['rinne positive', 'positive rinne', 'rinne positive in ' + E + ' ear', 'rinne ' + E + ' positive', 'ac > bc', 'ac more than bc', 'air better than bone', 'air more than bone']];
    var slong = ['Schwabach\'s test is lengthened', ['schwabach lengthened', 'lengthened schwabach', 'schwabach prolonged', 'schwabach longer', 'schwabach increased', 'long schwabach']];
    var sshort = ['Schwabach\'s test is shortened', ['schwabach shortened', 'shortened schwabach', 'schwabach reduced', 'schwabach shorter', 'schwabach decreased', 'short schwabach']];
    return cond ? [[weber(E), rneg, slong], [weber(O), equal, rpos, sshort]] : [[weber(O), rpos, sshort], [weber(E), equal, rneg, slong]];
  }
  var OGEN = {
    'lens-i': function (r) {
      var t = cpick(r, LENS), o = t[0], f = t[1], i = t[2];
      return { q: 'An object is ' + o + ' cm from a convex lens with a focal length of ' + f + ' cm. How far from the lens is its image?',
        a: [i + ' cm', String(i)], o: cwrong(r, i + ' cm', [ccm(o * f / (o + f)), ccm(o - f)], [o + f, f, o, 2 * f, 2 * i, i / 2].map(ccm)),
        w: '1/o + 1/i = 1/f, all in cm: 1/i = 1/' + f + ' − 1/' + o + ' = 1/' + i + ', so the image is ' + i + ' cm from the lens.' };
    },
    'lens-o': function (r) {
      var t = cpick(r, LENS), o = t[0], f = t[1], i = t[2];
      return { q: 'A convex lens with a focal length of ' + f + ' cm forms an image ' + i + ' cm from the lens. How far from the lens is the object?',
        a: [o + ' cm', String(o)], o: cwrong(r, o + ' cm', [ccm(f * i / (f + i)), ccm(i - f)], [i + f, f, i, 2 * f, 2 * o].map(ccm)),
        w: '1/o + 1/i = 1/f, so 1/o = 1/' + f + ' − 1/' + i + ' = 1/' + o + ': the object is ' + o + ' cm from the lens.' };
    },
    'lens-f': function (r) {
      var t = cpick(r, LENS), o = t[0], f = t[1], i = t[2];
      return { q: 'An object ' + o + ' cm from a convex lens forms its image ' + i + ' cm from the lens. What is the focal length of the lens?',
        a: [f + ' cm', String(f)], o: cwrong(r, f + ' cm', [ccm(o + i), ccm(Math.abs(o - i))], [(o + i) / 2, o * i / Math.abs(o - i), o, i].map(ccm)),
        w: '1/f = 1/o + 1/i = 1/' + o + ' + 1/' + i + ' = 1/' + f + ', so the focal length is ' + f + ' cm.' };
    },
    'lens-size': function (r) {
      var s = lensSized(r), why = 'Size of object ÷ size of image = object distance ÷ image distance: ';
      if (r() < 0.5) return { q: 'An object ' + s.h + ' cm tall is ' + s.o + ' cm from a lens, and its image forms ' + s.i + ' cm from the lens. How tall is the image?',
        a: [ccm(s.H), cnum(s.H)], o: cwrong(r, ccm(s.H), [ccm(s.h * s.o / s.i), ccm(s.h)], [s.H * 2, s.H / 2, s.H + 1, s.i, s.o].map(ccm)),
        w: why + s.h + ' ÷ image = ' + s.o + ' ÷ ' + s.i + ', so the image is ' + s.h + ' × ' + s.i + ' ÷ ' + s.o + ' = ' + cnum(s.H) + ' cm tall.' };
      return { q: 'An object is ' + s.o + ' cm from a lens. Its image forms ' + s.i + ' cm from the lens and is ' + cnum(s.H) + ' cm tall. How tall is the object?',
        a: [ccm(s.h), String(s.h)], o: cwrong(r, ccm(s.h), [ccm(s.H * s.i / s.o), ccm(s.H)], [s.h * 2, s.h / 2, s.h + 1, s.o].map(ccm)),
        w: why + 'object ÷ ' + cnum(s.H) + ' = ' + s.o + ' ÷ ' + s.i + ', so the object is ' + cnum(s.H) + ' × ' + s.o + ' ÷ ' + s.i + ' = ' + s.h + ' cm tall.' };
    },
    'lens-worked': function (r) {
      var s = lensSized(r);
      return { q: 'A bulb ' + s.h + ' cm tall is ' + s.o + ' cm from a double convex lens with a focal length of ' + s.f + ' cm. How tall is its image?',
        a: [ccm(s.H), cnum(s.H)], o: cwrong(r, ccm(s.H), [ccm(s.h * s.o / s.i), ccm(s.i)], [s.h * s.f / s.o, s.h, s.H * 2, s.H / 2].map(ccm)),
        w: 'First the image distance: 1/i = 1/' + s.f + ' − 1/' + s.o + ' = 1/' + s.i + ', so i = ' + s.i + ' cm. Then the size: ' + s.h + ' ÷ image = ' + s.o + ' ÷ ' + s.i + ', so the image is ' + cnum(s.H) + ' cm tall.' };
    },
    'va-calc': function (r) {
      var D = cpick(r, SNELLEN), ans = '6/' + D;
      return { q: 'From 6 m, a patient can read Snellen\'s chart only down to the line that a normal eye reads at ' + D + ' m. What is the visual acuity?',
        a: [ans].concat([60, 24, 12].indexOf(D) >= 0 ? [String(6 / D)] : []), o: cwrong(r, ans, [D + '/6', '6/6'], SNELLEN.map(function (x) { return '6/' + x; })),
        w: 'VA = d/D: d = 6 m, where the patient reads the line; D = ' + D + ' m, where a normal eye reads it. So VA = 6/' + D + '.' };
    },
    'va-d': function (r) {
      var D = cpick(r, SNELLEN), m = function (x) { return x + ' m'; };
      return { q: 'A patient\'s visual acuity is 6/' + D + '. At what distance would a normal eye read the letters that this patient reads at 6 m?',
        a: [m(D), String(D), D + ' metres', D + ' meters'], o: cwrong(r, m(D), [m(6), m(cnum(D / 6))], [6 * D].concat(SNELLEN).map(m)),
        w: 'VA = d/D: d = 6 m is where the patient reads the letters; D = ' + D + ' m is where a normal eye reads them.' };
    },
    'va-walk': function (r) {
      var x = cpick(r, [1, 2, 3, 4, 5]), ans = x + '/60';
      return { q: 'A patient cannot read the top letter of Snellen\'s chart (the 60 m line) from 6 m, so walks towards the chart and first reads it at ' + x + ' m. What is the visual acuity?',
        a: [ans], o: cwrong(r, ans, ['6/60', '60/' + x], [x + '/6', x + '/36', '1/60', '2/60', '3/60', '4/60', '5/60']),
        w: 'Below 6/60 the subject walks towards the chart until the top letter is read: VA = d/D = ' + x + '/60 (read at ' + x + ' m; a normal eye reads it at 60 m).' };
    },
    'va-low': function (r) {
      var L = [[', but can count the fingers you hold up', 'Counting fingers (CF)', ['counting fingers', 'cf', 'count fingers', 'finger counting']],
        [' and cannot count fingers, but can see your hand moving', 'Hand movements (HM)', ['hand movements', 'hm', 'hand movement', 'hand motion']],
        [' and cannot see a hand move, but can tell when a light shines into the eye', 'Perception of light (PL)', ['perception of light', 'pl', 'light perception', 'perceives light']],
        [' and cannot even tell when a light shines into the eye', 'No perception of light (no PL)', ['no perception of light', 'no pl', 'no light perception', 'npl', 'nlp']]];
      var k = Math.floor(r() * 4), c = L[k], x = ['1/60'], o = ['1/60'];
      L.forEach(function (e, j) { if (j !== k) { x = x.concat(e[2]); o.push(e[1]); } });
      return { q: 'A patient cannot read the top letter of Snellen\'s chart even at 1 m' + c[0] + '. How is the visual acuity recorded?',
        a: [c[1]].concat(c[2]), o: cwrong(r, c[1], [], o), x: x,
        w: 'Below 1/60, acuity is recorded as counting fingers (CF), hand movements (HM), perception of light (PL) or no perception of light (no PL).' };
    },
    'colour-name': function (r) {
      var all = [];
      [['Prot', 'red'], ['Deuter', 'green'], ['Trit', 'blue']].forEach(function (p) {
        [['anomaly', 'weakness', 'weak '], ['anopia', 'blindness', 'blind to ']].forEach(function (s) {
          all.push({ term: p[0] + s[0], mean: p[1] + ' colour ' + s[1], forms: [p[1] + ' colour ' + s[1], p[1] + ' color ' + s[1], p[1] + ' ' + s[1], s[2] + p[1]] });
        });
      });
      var k = Math.floor(r() * 6), c = all[k], others = all.filter(function (e, j) { return j !== k; });
      var w = 'Prot- = red, deuter- = green, trit- = blue; -anomaly = colour weakness, -anopia = colour blindness. So ' + c.term.toLowerCase() + ' = ' + c.mean + '.';
      if (r() < 0.5) return { q: 'What does ' + c.term.toLowerCase() + ' mean?', a: [ccap(c.mean)].concat(c.forms),
        o: cwrong(r, ccap(c.mean), [], others.map(function (e) { return ccap(e.mean); })), x: [].concat.apply([], others.map(function (e) { return e.forms; })), w: w };
      return { q: 'What is the name for ' + c.mean + '?', a: [c.term], o: cwrong(r, c.term, [], others.map(function (e) { return e.term; })), w: w };
    },
    'ishihara': function (r) {
      var p = cpick(r, [1, 2, 2, 3, 3, 4, 5, 6, 6]), who = Math.floor(r() * 3), v = ISH[p][who], ans = ishRead(v);
      var person = ['a person with normal colour vision', 'a person with red-green deficiency', 'a person with total colour blindness'][who];
      return { q: 'On Ishihara plate ' + p + (who ? ' (a normal person ' + ishRd(ISH[p][0]) + ')' : '') + ', what does ' + person + ' read?',
        a: v === 'X' ? [ans].concat(ISH_X) : [v], o: cwrong(r, ans, ISH[p].map(ishRead), ['12', '29', '70', '5', '2', '6', '7', 'X'].map(ishRead)), x: v === 'X' ? [] : ISH_X,
        w: ishWhy(p) };
    },
    'ishihara-dx': function (r) {
      var who = Math.floor(r() * 3), plates = [2, 6];
      var unique = function (ps) { return [0, 1, 2].every(function (o) { return o === who || ps.some(function (p) { return ISH[p][o] !== ISH[p][who]; }); }); };
      for (var k = 0; k < 40; k++) { var ps = cmix(r, [2, 3, 4, 5, 6]).slice(0, 2).sort(); if (unique(ps)) { plates = ps; break; } }
      var N = [['Normal colour vision', 'normal', 'normal colour vision', 'normal color vision', 'normal vision'],
        ['Red-green colour deficiency', 'red green deficiency', 'red green', 'red green colour blindness', 'red green color blindness', 'red green defect', 'red green colour deficiency'],
        ['Total colour blindness', 'total colour blindness', 'total color blindness', 'totally colour blind', 'total']], x = ['tritanopia', 'blue colour blindness'], o = [];
      N.forEach(function (n, j) { if (j !== who) { x = x.concat(n); o.push(n[0]); } });
      return { q: 'On Ishihara\'s plates, a subject ' + ishSay(plates[0], ISH[plates[0]][who]) + ' and ' + ishSay(plates[1], ISH[plates[1]][who]) + '. What is their colour vision?',
        a: N[who], o: cwrong(r, N[who][0], o.concat(['Blue colour blindness (tritanopia)']), []), x: x, w: plates.map(ishWhy).join(' ') };
    },
    'db-fold': function (r) {
      var k = 1 + Math.floor(r() * 6), N = cbig(Math.pow(10, k)), L = 20 * k;
      return { q: 'One sound has ' + N + ' times the sound pressure of another. How many decibels louder is it?',
        a: [cdb(L), String(L), L + ' decibels'], o: dbWrong(r, L),
        w: 'dB = 20 log (P/Pref) = 20 log ' + N + ' = 20 × ' + k + ' = ' + L + ' dB. Every 10-fold rise in pressure adds 20 dB.' };
    },
    'db-back': function (r) {
      var k = 1 + Math.floor(r() * 6), L = 20 * k, N = Math.pow(10, k), times = function (n) { return n >= 2 ? cbig(n) + ' times' : ''; };
      return { q: 'Two sounds differ by ' + L + ' dB. How many times greater is the sound pressure of the louder one?',
        a: [times(N), cbig(N), String(N), N + ' times', '10^' + k, '10 to the power ' + k],
        o: cwrong(r, times(N), [times(Math.pow(10, 2 * k)), times(L)], [k, 10 * N, N / 10, 10, 100, 1000, 10000, 100000, 1000000].map(times)),
        w: L + ' dB = 20 log (P/Pref), so log (P/Pref) = ' + L + ' ÷ 20 = ' + k + ', and the pressure is 10^' + k + ' = ' + cbig(N) + ' times greater.' };
    },
    'db-level': function (r) {
      var k, d, L;
      if (r() < 0.5) {
        k = Math.floor(r() * 8); d = DB[k]; L = d[0];
        return { q: 'A sound has a pressure of ' + d[1] + ' dynes/cm². What is its level in dB? (0 dB = 0.0002 dyne/cm², the threshold at 1,000 Hz.)',
          a: [cdb(L), String(L), L + ' decibels'], o: dbWrong(r, L),
          w: 'dB = 20 log (P/Pref) = 20 log (' + d[1] + ' ÷ 0.0002) = 20 log ' + cbig(Math.pow(10, k)) + ' = ' + L + ' dB: about ' + d[2] + '.' };
      }
      k = 1 + Math.floor(r() * 7); d = DB[k]; L = d[0];
      var P = function (x) { return x + ' dynes/cm²'; };
      return { q: 'A sound is at ' + L + ' dB. What is its pressure in dynes/cm²? (0 dB = 0.0002 dyne/cm², the threshold at 1,000 Hz.)',
        a: [P(d[1]), d[1], d[1] + ' dynes/cm2', d[1] + ' dyne/cm2', d[1] + ' dynes'],
        o: cwrong(r, P(d[1]), [P(DB[k - 1][1]), P((DB[k + 1] || DB[k - 2])[1])], DB.map(function (e) { return P(e[1]); })),
        w: L + ' dB = 20 log (P ÷ 0.0002), so P = 0.0002 × 10^' + k + ' = ' + d[1] + ' dynes/cm²: about ' + d[2] + '.' };
    },
    'db-table': function (r) {
      var k = Math.floor(r() * 8), d = DB[k], x = [];
      DB.forEach(function (e, j) { if (j !== k) x = x.concat(e[4]); });
      var w = 'The decibel table: 0 dB threshold, 20 faint whisper, 40 quiet office, 60 conversation, 80 city bus, 100 subway train, 120 loud thunder, 140 pain and damage. Each +20 dB is 10 times the pressure.';
      if (r() < 0.5) return { q: 'About what sound level, in dB, is ' + d[2] + '?', a: [cdb(d[0]), String(d[0])],
        o: cwrong(r, cdb(d[0]), [cdb(d[0] + 20), cdb(d[0] - 20)], DB.map(function (e) { return cdb(e[0]); })), w: w };
      return { q: 'On the decibel table, what is heard at about ' + d[0] + ' dB?', a: [d[3]].concat(d[4]), o: cwrong(r, d[3], [], DB.map(function (e) { return e[3]; })), x: x, w: w };
    },
    'wavelength': function (r) {
      var F = [250, 500, 1000, 2000, 4000, 8000], f = cpick(r, F), A = f === 1000 ? [2000, 17] : f === 2000 ? [1000, 34] : cpick(r, [[1000, 34], [2000, 17]]);
      var lam = 34000 / f, given = 'In air, a ' + cbig(A[0]) + ' Hz tone has a wavelength of about ' + A[1] + ' cm. ', hz = function (g) { return cbig(g) + ' Hz'; };
      var w = 'Wavelength is inversely related to frequency (1,000 Hz ≈ 34 cm, 2,000 Hz ≈ 17 cm in air): double the frequency, half the wavelength. So ' + cbig(f) + ' Hz ≈ ' + cnum(lam) + ' cm.';
      if (r() < 0.5) return { q: given + 'About what is the wavelength of ' + (f === 8000 ? 'an ' : 'a ') + cbig(f) + ' Hz tone?', a: [ccm(lam), cnum(lam)],
        o: cwrong(r, ccm(lam), [ccm(A[1] * f / A[0]), ccm(A[1])], F.map(function (g) { return ccm(34000 / g); })), w: w };
      return { q: given + 'Which frequency has a wavelength of about ' + cnum(lam) + ' cm?', a: [hz(f), String(f), f + ' hz'].concat(f >= 1000 ? [f / 1000 + ' khz'] : []),
        o: cwrong(r, hz(f), [hz(A[0] * lam / A[1])], F.map(hz)), w: w };
    },
    'hl-grade': function (r) {
      var G = [['Normal hearing', [-10, -5, 0, 5, 10, 15, 20, 25], ['normal', 'normal hearing']],
        ['Mild hearing loss', [30, 35, 40], ['mild', 'mild loss', 'mild deafness']],
        ['Moderate hearing loss', [45, 50, 55], ['moderate', 'moderate loss', 'moderate deafness']],
        ['Moderately severe hearing loss', [60, 65, 70], ['moderately severe', 'moderately severe loss', 'moderately severe deafness']],
        ['Severe hearing loss', [75, 80, 85, 90], ['severe', 'severe loss', 'severe deafness']],
        ['Profound hearing loss', [95, 100, 105, 110], ['profound', 'profound loss', 'profound deafness']]];
      var k = Math.floor(r() * 6), v = cpick(r, G[k][1]), x = [];
      G.forEach(function (g, j) { if (j !== k) x = x.concat(g[2]); });
      return { q: 'On an audiogram, a patient\'s hearing threshold is ' + String(v).replace('-', '−') + ' dB HL. How is the hearing graded?', a: [G[k][0]].concat(G[k][2]),
        o: cwrong(r, G[k][0], [(G[k + 1] || G[k - 2])[0], (G[k - 1] || G[k + 2])[0]], G.map(function (g) { return g[0]; })), x: x,
        w: '−10 to 25 dB HL normal, 26–40 mild, 41–55 moderate, 56–70 moderately severe, 71–90 severe, > 90 profound. So ' + String(v).replace('-', '−') + ' dB HL is ' + G[k][0].toLowerCase() + '.' };
    },
    'fork-result': function (r) {
      var E = r() < 0.5 ? 'right' : 'left', O = E === 'right' ? 'left' : 'right', cond = r() < 0.5, F = forkFacts(E, O, cond), t = cpick(r, F[0]), a = [t[0]], x = [];
      F[0].forEach(function (f) { a = a.concat([f[0]], f[1]); });
      F[1].forEach(function (f) { x = x.concat(f[1]); });
      return { q: 'A patient has ' + (cond ? 'conductive' : 'partial sensorineural') + ' deafness of the ' + E + ' ear. Which tuning-fork result do you expect?',
        a: a, o: cwrong(r, t[0], [], F[1].map(function (f) { return f[0]; })), x: x,
        w: cond ? 'Conductive deafness: everything points to the sick ear. Weber lateralises to the ' + E + ' ear, Rinne is negative there (BC > AC) and Schwabach is lengthened.'
          : 'Sensorineural deafness: the healthy ear wins. Weber lateralises to the ' + O + ' ear, Rinne stays positive (AC > BC) while the deafness is partial, and Schwabach is shortened.' };
    },
    'fork-dx': function (r) {
      var D = [['right', 1], ['left', 1], ['right', 0], ['left', 0]], all = [], x = [], o = [];
      D.forEach(function (d) {
        var t = d[1] ? 'conductive' : 'sensorineural', s = d[0];
        all.push([ccap(s) + ' ' + t + ' deafness', s + ' ' + t + ' deafness', s + ' ' + t, s + ' ' + t + ' hearing loss', t + ' deafness ' + s + ' ear', s + ' ear ' + t].concat(d[1] ? [] : [s + ' nerve deafness', s + ' perceptive deafness']));
      });
      all.push(['Normal hearing', 'normal', 'normal hearing']);
      var k = r() < 0.12 ? 4 : Math.floor(r() * 4), clue;
      if (k === 4) clue = 'Weber\'s test is heard equally on both sides and Rinne\'s test is positive in both ears';
      else {
        var E = D[k][0], O = E === 'right' ? 'left' : 'right';
        clue = D[k][1] ? cpick(r, ['Weber\'s test lateralises to the ' + E + ' ear and Rinne\'s test is negative in the ' + E + ' ear', 'Weber\'s test lateralises to the ' + E + ' ear and Schwabach\'s test is lengthened', 'Rinne\'s test is negative in the ' + E + ' ear and Schwabach\'s test is lengthened'])
          : cpick(r, ['Weber\'s test lateralises to the ' + O + ' ear and Rinne\'s test is positive in both ears', 'Weber\'s test lateralises to the ' + O + ' ear and Schwabach\'s test is shortened']);
      }
      all.forEach(function (e, j) { if (j !== k) { x = x.concat(e.slice(1)); o.push(e[0]); } });
      return { q: 'Tuning-fork tests: ' + clue + '. What is the diagnosis?', a: all[k], o: cwrong(r, all[k][0], [], o), x: x,
        w: 'Conductive deafness: Weber lateralises to the sick ear, Rinne is negative (BC > AC), Schwabach is lengthened. Sensorineural: Weber goes to the healthy ear, Rinne stays positive, Schwabach is shortened. Normal: Weber heard equally, Rinne positive.' };
    }
  };

  function renderQHome() {
    setBar(null);
    QBM = qb().mode || 'ebe';
    if (!qbReady()) return;
    var src = qbSrc(), h = '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · question bank</span><h1>Question bank</h1>' +
      '<p>' + (QBM === 'ospe' ? 'OSPE pictures with my arrows, the prelabs and drugs affecting the eye. Answer with choices or by typing.' : 'Practise each subject level by level: pick an answer, check it, see why.') +
      ' Pass a level for its star; three stars complete a bank and open the next one. The banks never run out.</p></div>' +
      '<div class="qmode" role="group" aria-label="Exam"><button type="button" data-qmode="ebe"' + (QBM === 'ebe' ? ' class="on" aria-pressed="true"' : '') + '>EBE</button>' +
      '<button type="button" data-qmode="ospe"' + (QBM === 'ospe' ? ' class="on" aria-pressed="true"' : '') + '>OSPE</button></div><ul class="list">';
    var order = CAT.map(function (c) { return c.id; });   // the same order as the Study tab
    src.slice().sort(function (x, y) { return (order.indexOf(x.id) + 99) % 99 - (order.indexOf(y.id) + 99) % 99; }).forEach(function (s, i) {
      var b = qbCurrent(s.id);
      h += '<li style="--i:' + i + '"><button class="tile" type="button" data-qsub="' + s.id + '" style="--sc:var(--s-' + s.id + ')">' +
        '<span class="badge">' + esc(badge(s.name)) + '</span><span class="t"><b>' + esc(s.name) + '</b><span>Bank ' + (b + 1) +
        (b ? ' · ' + b + (b === 1 ? ' bank' : ' banks') + ' completed' : '') + ' · ' + s.qs.length + ' questions</span></span>' + starsHtml(qbStars(s.id, b)) + '</button></li>';
    });
    view.innerHTML = h + '</ul></section>';
  }
  function renderQSub(e) {
    QBM = e.m || QBM;
    if (!qbReady()) return;
    var s = qbS(e.sid);
    setBar(s.name, QBM === 'ospe' ? 'OSPE question bank' : 'Question bank');
    var cur = qbCurrent(e.sid), b = e.bank == null || e.bank > cur ? cur : e.bank, st = qbStars(e.sid, b), res = qbBanks(e.sid)[b] || [], run = qb().run;
    var h = '<section class="screen" style="--sc:var(--s-' + e.sid + ')"><div class="subhead"><span class="mono eyebrow">' + (QBM === 'ospe' ? 'OSPE' : 'EBE') + ' question bank · ' + esc(s.name) + '</span>' +
      '<h1>Bank ' + (b + 1) + ' ' + starsHtml(st) + '</h1><p>' + (st === 3 ? '<b class="qdone">Completed.</b> Replay a level, or go on to Bank ' + (cur + 1) + '.'
        : 'Get ' + Math.ceil(QB_PASS * QB_N) + ' of ' + QB_N + ' right to pass a level and earn its star. Three stars complete the bank and open Bank ' + (b + 2) + '.') + '</p></div>';
    if (run && run.sid === e.sid && (run.m || 'ebe') === QBM) {
      h += '<button class="tile cont" type="button" data-qresume="1"><span class="num">▶</span><span class="t"><b>Continue Bank ' + (run.bank + 1) + ' · Level ' + run.lv + '</b><span>Question ' + (run.cur + 1) + ' of ' + run.ids.length + '</span></span><span class="go">›</span></button>';
    }
    h += '<ul class="list">';
    [1, 2, 3].forEach(function (lv) {
      var open = qbOpen(e.sid, b, lv), best = res[lv - 1], ok = qbPassed(best);
      h += '<li style="--i:' + (lv - 1) + '"><button class="tile' + (open ? '' : ' locked') + '" type="button"' + (open ? ' data-qlv="' + e.sid + '|' + b + '|' + lv + '"' : ' disabled') + '>' +
        '<span class="num">' + (ok ? '★' : lv) + '</span><span class="t"><b>' + QB_LV[lv - 1] + '</b><span>' + Math.min(QB_N, s.qs.length) + ' questions' +
        (best != null ? ' · best ' + best + '%' : '') + (open ? '' : ' · pass level ' + (lv - 1) + ' first') + '</span></span><span class="pct">' + (ok ? '★' : open ? '›' : '🔒') + '</span></button></li>';
    });
    h += '</ul>';
    if (cur > 0) {   // every bank so far: replay a completed one
      h += '<h3 class="wpick">Banks</h3><div class="qbanks">';
      for (var k = 0; k <= cur; k++) h += '<button type="button" class="' + (k === b ? 'on' : '') + '" data-qbank="' + k + '">Bank ' + (k + 1) + ' ' + starsHtml(qbStars(e.sid, k)) + '</button>';
      h += '</div>';
    }
    h += qbSpots(e.sid, qbMiss(e.sid), 'Study more', 'Questions you got wrong and haven\'t got right since, by the slide that teaches them.');
    view.innerHTML = h + '</section>';
  }
  function qbStart(sid, b, lv) {
    var s = qbS(sid), ids = qbBase(s, b, lv), miss = qbMiss(sid).filter(function (qi) { return s.qs[qi] && ids.indexOf(qi) < 0 && (s.qs[qi].lv || 1) === lv; });
    for (var k = 0; k < 3 && k < miss.length && ids.length > 3; k++) ids[ids.length - 1 - k] = miss[miss.length - 1 - k];   // your recent mistakes come back
    shuffle(ids);
    var seed = Date.now().toString(36);   // calculation questions draw their numbers from it
    qb().run = { m: QBM, sid: sid, bank: b, lv: lv, ids: ids, cur: 0, pick: -1, typed: '', checked: false, got: [], picks: [], typeds: [], seed: seed,
      perm: ids.map(function (qi, k) {   // the order the choices are shown in (OSPE: 0 is the answer)
        var q = oq(s.qs[qi], seed + ':' + k), p = (QBM === 'ospe' ? ochoices(q, sid) : q.o).map(function (o, j) { return j; });
        return q.f ? p : shuffle(p);
      }) };
    save();
    while (stack.length > 1 && top().t !== 'qsub') stack.pop();
    if (top().t === 'qsub') { top().sid = sid; top().bank = b; top().m = QBM; } else stack.push({ t: 'qsub', sid: sid, bank: b, m: QBM });
    go({ t: 'qplay' });
  }
  function qbTyping() { return QBM === 'ospe' && qb().otype === 'typed'; }
  function qbSeed(r, k, typed) { return r.seed + ':' + k + (typed ? ':t' : ''); }   // typing gets its own numbers, not the ones shown with choices
  function qbPerm(s, r, k) { return shuffle(ochoices(oq(s.qs[r.ids[k]], qbSeed(r, k)), r.sid).map(function (o, j) { return j; })); }
  function qbSwap(r) {   // switching to typing after seeing the choices: a different question (a calculation just gets new numbers)
    var s = qbS(r.sid), cur = r.ids[r.cur], peek = r.peek || (r.peek = []);
    if (!s.qs[cur] || s.qs[cur].gen) return;
    if (peek.indexOf(cur) < 0) peek.push(cur);   // seen with its choices: not brought back in this run
    var pool = [];
    s.qs.forEach(function (x, i) { if (r.ids.indexOf(i) < 0 && peek.indexOf(i) < 0) pool.push(i); });
    var same = pool.filter(function (i) { return (s.qs[i].lv || 1) === r.lv; }), pick = same.length ? same : pool;
    if (pick.length) { r.ids[r.cur] = pick[Math.floor(Math.random() * pick.length)]; r.perm[r.cur] = qbPerm(s, r, r.cur); return; }
    for (var k = r.cur + 1; k < r.ids.length; k++) if (peek.indexOf(r.ids[k]) < 0) {   // a small bank: bring a later one forward
      r.ids[r.cur] = r.ids[k]; r.ids[k] = cur; r.perm[r.cur] = qbPerm(s, r, r.cur); r.perm[k] = qbPerm(s, r, k); return;
    }
  }
  function qbRight(r, q) {   // is the current answer right?
    if (r.m !== 'ospe') return r.perm[r.cur][r.pick] === q.a;
    return r.kind === 'typed' ? !!r.ov || typedOk(r.typed, q.a, owrong(q)) : r.perm[r.cur][r.pick] === 0;
  }
  function renderQPlay() {
    var r = qb().run;
    if (!r) { stack.pop(); render(false); return; }
    QBM = r.m || 'ebe';
    if (!qbReady()) return;
    if (!r.checked) r.kind = qbTyping() ? 'typed' : 'mcq';
    var s = qbS(r.sid), q = oq(s.qs[r.ids[r.cur]], qbSeed(r, r.cur, r.kind === 'typed')), perm = r.perm[r.cur], last = r.cur + 1 === r.ids.length, O = QBM === 'ospe';
    var typing = O && r.kind === 'typed', opts = O ? ochoices(q, r.sid) : q.o, ok = r.checked && qbRight(r, q);
    if (perm.length !== opts.length) perm = r.perm[r.cur] = shuffle(opts.map(function (o, j) { return j; }));   // a run saved before the bank changed
    setBar(s.name, (O ? 'OSPE · ' : '') + 'Bank ' + (r.bank + 1) + ' · Level ' + r.lv);
    var h = '<section class="screen exam qplay" style="--sc:var(--s-' + r.sid + ')"><div class="xhead"><span class="mono">Question ' + (r.cur + 1) + ' of ' + r.ids.length + '</span>' +
      '<span class="xsub">' + r.got.filter(Boolean).length + ' right</span></div><div class="xbar"><i style="width:' + pct(r.cur + (r.checked ? 1 : 0), r.ids.length) + '%"></i></div>' +
      (O ? '<div class="otype" role="group" aria-label="Answer by"><span>Answer by</span><button type="button" data-otype="mcq"' + (!typing ? ' class="on"' : '') + (r.checked ? ' disabled' : '') + '>Choices</button>' +
        '<button type="button" data-otype="typed"' + (typing ? ' class="on"' : '') + (r.checked ? ' disabled' : '') + '>Typing</button></div>' + picHtml(q) : '') +
      '<h2 class="xq">' + esc(q.q) + '</h2>';
    if (typing) {
      h += '<input class="otyped' + (r.checked ? (ok ? ' right' : ' wrong') : '') + '" id="otyped" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type your answer, then Enter" value="' + esc(r.typed) + '"' + (r.checked ? ' disabled' : '') + '>';
    } else {
      h += '<div class="xopts" role="radiogroup" aria-label="Answers">';
      perm.forEach(function (k, j) {
        var right = O ? k === 0 : k === q.a;
        var cls = r.checked ? (right ? ' right' : j === r.pick ? ' wrong' : ' dim') : (j === r.pick ? ' on' : '');
        h += '<button class="xopt' + cls + '" type="button" role="radio" aria-checked="' + (j === r.pick) + '" data-qpick="' + j + '"' + (r.checked ? ' disabled' : '') + '>' +
          '<span class="k">' + ABC[j] + '</span><span>' + esc(opts[k]) + '</span></button>';
      });
      h += '</div>';
    }
    if (r.checked) {
      var w = qbWhere(q), ans = O ? q.a[0] : '';
      h += '<div class="qfeed ' + (ok ? 'ok' : 'no') + '" role="status"><b>' + (ok ? '✓ Right!' : O ? '✗ The answer is: ' + esc(ans) : '✗ Not quite: the answer is ' + ABC[perm.indexOf(q.a)] + '.') + '</b>' +
        (typing && ok && onorm(r.typed) !== onorm(ans) ? '<p class="mono">Full answer: ' + esc(ans) + '</p>' : '') + '<p>' + esc(q.w) + '</p>' +
        (typing && !ok ? '<button class="linkish" type="button" data-qov="1">My answer means the same: count it right</button><br>' : '') +
        (w ? '<button class="linkish" type="button" data-qcard="' + esc(w.lid + '|' + w.cid) + '">Read it: ' + esc(w.label) + '</button>' : '') + '</div>';
    }
    h += '<div class="xnav"><button class="btn big" type="button" data-qgo="1"' + (!r.checked && !typing && r.pick < 0 ? ' disabled' : '') + '>' + (!r.checked ? 'Check' : last ? 'See my result' : 'Next question →') + '</button></div>' +
      '<p class="xhint qkeys">' + (typing ? 'Type, then Enter to check; Enter again for the next question.' : 'Keys: 1–' + perm.length + ' or a–' + ABC[perm.length - 1] + ' to pick, Enter to check, Enter again for the next question.') + '</p></section>';
    view.innerHTML = h;
    var inp = $('otyped');
    if (inp && !r.checked) { inp.addEventListener('input', function () { r.typed = inp.value; }); try { inp.focus({ preventScroll: true }); } catch (e) {} }
  }
  function qbGo() {   // Check, then Next, then the result
    var r = qb().run;
    if (!r) return;
    QBM = r.m || 'ebe';
    var s = qbS(r.sid), qi = r.ids[r.cur], q = oq(s.qs[qi], qbSeed(r, r.cur, r.kind === 'typed')), inp = $('otyped');
    if (!r.checked) {
      if (inp) r.typed = inp.value;
      if (r.kind === 'typed' ? !r.typed.trim() : r.pick < 0) return;
      r.checked = true; r.picks[r.cur] = r.pick; r.typeds[r.cur] = r.kind === 'typed' ? r.typed : null;
      qbMark(r, qi, qbRight(r, q));
      save(); render(false); return;
    }
    if (r.cur + 1 < r.ids.length) { r.cur++; r.pick = -1; r.typed = ''; r.ov = false; r.checked = false; save(); render(true); return; }
    var n = r.ids.length, got = r.got.filter(Boolean).length, p = Math.round(got / n * 100), banks = qbBanks(r.sid), res = banks[r.bank] || (banks[r.bank] = [null, null, null]);
    if (res[r.lv - 1] == null || p > res[r.lv - 1]) res[r.lv - 1] = p;
    qb().last = { m: r.m, sid: r.sid, bank: r.bank, lv: r.lv, p: p, got: got, n: n, ids: r.ids, perm: r.perm, picks: r.picks, typeds: r.typeds, res: r.got, seed: r.seed };
    delete qb().run; save();
    stack[stack.length - 1] = { t: 'qdone' }; render(true);
  }
  function qbMark(r, qi, ok) {   // right: off the mistakes list; wrong: it comes back in later banks until you get it right
    var m = qbMiss(r.sid), at = m.indexOf(qi);
    r.got[r.cur] = ok ? 1 : 0;
    if (at >= 0) m.splice(at, 1);
    if (!ok) m.push(qi);
  }
  function renderQDone() {
    var L = qb().last;
    if (!L) { stack.pop(); render(false); return; }
    QBM = L.m || 'ebe';
    if (!qbReady()) return;
    var s = qbS(L.sid), pass = qbPassed(L.p), st = qbStars(L.sid, L.bank), done = st === 3, O = QBM === 'ospe', wrong = L.ids.filter(function (qi, i) { return !L.res[i]; });
    setBar(s.name, (O ? 'OSPE · ' : '') + 'Bank ' + (L.bank + 1) + ' · Level ' + L.lv);
    var h = '<section class="screen" style="--sc:var(--s-' + L.sid + ')"><div class="qresult ' + (pass ? 'pass' : 'fail') + '"><span class="mono eyebrow">Bank ' + (L.bank + 1) + ' · ' + QB_LV[L.lv - 1] + '</span>' +
      '<b class="big">' + L.got + ' / ' + L.n + '</b><p>' + (done ? '<b class="qdone">Bank ' + (L.bank + 1) + ' completed!</b> ' + starsHtml(3) + '<br>Bank ' + (L.bank + 2) + ' is open.'
        : pass ? '★ Level passed! ' + starsHtml(st) : 'Not passed yet: you need ' + Math.ceil(QB_PASS * L.n) + ' of ' + L.n + '.') + '</p></div>';
    h += wrong.length ? qbSpots(L.sid, wrong, 'Study more', 'Go to the slide that teaches each one you got wrong.') : '<p class="xhint">All right. Nothing to review.</p>';
    if (wrong.length) {
      h += '<details class="qmist"><summary>Your mistakes (' + wrong.length + ')</summary>';
      L.ids.forEach(function (qi, i) {
        if (L.res[i]) return;
        var q = oq(s.qs[qi], L.seed + ':' + i + (L.typeds[i] != null ? ':t' : '')), yours = O ? (L.typeds[i] != null ? L.typeds[i] : ochoices(q, L.sid)[L.perm[i][L.picks[i]]]) : q.o[L.perm[i][L.picks[i]]];
        h += '<div class="qm"><p><b>' + esc(q.q) + '</b></p><p class="no">You: ' + esc(yours || '(nothing)') + '</p><p class="ok">Answer: ' + esc(O ? q.a[0] : q.o[q.a]) + '</p></div>';
      });
      h += '</details>';
    }
    var next = done ? [L.bank + 1, 1] : pass && L.lv < 3 ? [L.bank, L.lv + 1] : null;
    h += '<div class="xacts">' + (next ? '<button class="btn big" type="button" data-qlv="' + L.sid + '|' + next[0] + '|' + next[1] + '">' + (next[1] === 1 ? 'Start Bank ' + (next[0] + 1) : 'Next: Level ' + next[1]) + '</button>' : '') +
      '<button class="btn' + (next ? ' ghost' : ' big') + '" type="button" data-qlv="' + L.sid + '|' + L.bank + '|' + L.lv + '">Try this level again</button>' +
      '<button class="btn ghost" type="button" data-qback="1">Back to the levels</button></div></section>';
    view.innerHTML = h;
  }
  function qbClick(t) {
    var el, r = store.qb && store.qb.run;
    if (t.closest('[data-opic]') && picQ) { openLb('img/o/' + picQ.img, picQ.iw, picQ.ih, arrowsSvg(picQ)); return true; }
    if ((el = t.closest('[data-qmode]'))) { qb().mode = QBM = el.getAttribute('data-qmode'); save(); render(false); return true; }
    if ((el = t.closest('[data-qsub]'))) { go({ t: 'qsub', sid: el.getAttribute('data-qsub'), m: QBM }); return true; }
    if ((el = t.closest('[data-qlv]'))) { var p = el.getAttribute('data-qlv').split('|'); qbStart(p[0], +p[1], +p[2]); return true; }
    if ((el = t.closest('[data-qbank]'))) { top().bank = +el.getAttribute('data-qbank'); render(false); return true; }
    if (t.closest('[data-qresume]')) { go({ t: 'qplay' }); return true; }
    if ((el = t.closest('[data-otype]'))) {
      if (r && !r.checked) { var nk = el.getAttribute('data-otype'); QBM = r.m || QBM; if (nk === 'typed' && r.kind !== 'typed') qbSwap(r); qb().otype = nk; r.pick = -1; r.typed = ''; save(); render(false); }
      return true;
    }
    if ((el = t.closest('[data-qpick]'))) { if (r && !r.checked) { r.pick = +el.getAttribute('data-qpick'); save(); render(false); } return true; }
    if (t.closest('[data-qov]')) {   // the typed answer meant the same: count it
      if (r && r.checked && !r.got[r.cur]) { r.ov = true; QBM = r.m; qbMark(r, r.ids[r.cur], true); save(); render(false); }
      return true;
    }
    if (t.closest('[data-qgo]')) { qbGo(); return true; }
    if ((el = t.closest('[data-qcard]'))) {   // a lecture, at the card; back returns here
      var c = el.getAttribute('data-qcard').split('|');
      top().y = window.scrollY; stack.push({ t: 'lecture', lid: c[0], card: c[1] || undefined }); render(true); return true;
    }
    if (t.closest('[data-qback]')) { back(); return true; }
    return false;
  }
  function qbKey(e) {   // 1–5 or a–e picks, Enter checks, Enter again goes on (typing: Enter only)
    var r = store.qb && store.qb.run;
    if (tab !== 'qbank' || top().t !== 'qplay' || !r) return false;
    if (e.key === 'Enter' && (!e.target.closest || !e.target.closest('textarea'))) { qbGo(); return true; }
    if (e.target.closest && e.target.closest('input,textarea')) return false;
    if (r.kind === 'typed') return false;
    var k = e.key.toLowerCase(), n = r.perm[r.cur].length, j = /^[1-9]$/.test(k) ? +k - 1 : /^[a-e]$/.test(k) ? k.charCodeAt(0) - 97 : -1;
    if (j >= 0) { if (j < n && !r.checked) { r.pick = j; save(); render(false); } return true; }
    return false;
  }

  /* ---------- Exams tab: the EBE exam and the OSPE exam ---------- */
  function renderExams() {
    setBar(null);
    var ex = store.exam, ox = store.oex, h = '<section class="screen"><div class="hello"><span class="mono eyebrow">SS module · mock exams</span><h1>Exams</h1><p>Full mock exams like the real ones. The score and the explanations come at the end.</p></div><ul class="list">';
    h += '<li style="--i:0"><button class="tile" type="button" data-exopen="ebe" style="--sc:var(--hema)"><span class="badge">EB</span><span class="t"><b>EBE exam</b><span>' +
      (ex && !ex.done ? 'In progress · ' + answered(ex) + ' of ' + ex.qs.length + ' answered' : (window.EXAM_TOTAL || '') + ' text MCQs, one mark each') + '</span></span><span class="go">›</span></button></li>';
    h += '<li style="--i:1"><button class="tile" type="button" data-exopen="ospe" style="--sc:var(--eosin)"><span class="badge">OS</span><span class="t"><b>OSPE exam</b><span>' +
      (ox && !ox.done ? 'In progress · station ' + (ox.cur + 1) + ' of ' + ox.qs.length : 'Pictures, the prelabs and eye drugs · all written, or half MCQ') + '</span></span><span class="go">›</span></button></li>';
    view.innerHTML = h + '</ul></section>';
  }
  function ospeReady() { return needJs('ospe.js', 'ospe', function () { if (top().t === 'oexam') render(false); }); }
  function oSub(sid) { var a = window.OSPE || []; for (var i = 0; i < a.length; i++) if (a[i].id === sid) return a[i]; return { id: sid, name: sid, qs: [] }; }
  function renderOExam() {
    var v = top().v || 'intro';
    setBar('OSPE exam', 'SS module · mock exam');
    if (!ospeReady()) return;
    if (v === 'q' && store.oex && !store.oex.done) return drawOQ();
    if (v === 'result' && store.oex && store.oex.done) return drawOResult();
    if (v === 'review' && store.oex && store.oex.done) return drawOReview();
    var ox = store.oex, total = 0, h = '<section class="screen exam"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">Mock exam · OSPE</span><h1>OSPE exam</h1>' +
      '<p>Station by station: a picture with an arrow, a prelab question, or drugs affecting the eye. Choose how you want to answer.</p></div><h3 class="wpick">Stations</h3><div class="blueprint">';
    window.OSPE.forEach(function (s) { var n = Math.min(s.stations, s.qs.length); total += n; h += '<span style="--sc:var(--s-' + s.id + ')"><b>' + esc(s.name) + '</b><i>' + n + '</i></span>'; });
    h += '<span class="sum"><b>Total</b><i>' + total + '</i></span></div><h3 class="wpick">How do you want to answer?</h3>';
    if (ox && !ox.done) h += '<div class="xacts"><button class="btn big" type="button" data-oresume="1">Continue: station ' + (ox.cur + 1) + ' of ' + ox.qs.length + '</button></div><h3 class="wpick">Or start a new one</h3>';
    h += '<div class="omodes"><button class="omode" type="button" data-onew="written"><b>All written</b><span>Type every answer, like the real OSPE.</span></button>' +
      '<button class="omode" type="button" data-onew="mix"><b>50 / 50</b><span>Half MCQs, half written.</span></button></div>' +
      ((store.oexLog || []).length ? '<p class="xhint">Your last OSPE: ' + store.oexLog[store.oexLog.length - 1].got + ' / ' + store.oexLog[store.oexLog.length - 1].total + '.</p>' +
        (ox && ox.done ? '<div class="xacts"><button class="btn ghost big" type="button" data-oreview="1">Review my last OSPE</button></div>' : '') : '') + '</section>';
    view.innerHTML = h;
  }
  function newOExam(mode) {
    var seen = store.oseen || (store.oseen = {}), qs = [];
    window.OSPE.forEach(function (s) {
      var idx = s.qs.map(function (q, i) { return i; });
      shuffle(idx);
      idx.sort(function (a, b) { return (seen[s.id + ':' + a] || 0) - (seen[s.id + ':' + b] || 0); });   // the ones you have seen least first
      var n = Math.min(s.stations, s.qs.length), take = idx.slice(0, n);
      if (s.mix) {   // spread the stations over the subject's topics (the least-seen questions of each, in turn)
        var by = {}, order = [];
        idx.forEach(function (i) { var g = s.qs[i].g || 0; if (!by[g]) { by[g] = []; order.push(g); } by[g].push(i); });
        take = [];
        for (var r = 0; take.length < n; r++) order.forEach(function (g) { if (take.length < n && by[g][r] != null) take.push(by[g][r]); });
      }
      take.forEach(function (i) { qs.push({ s: s.id, i: i }); seen[s.id + ':' + i] = (seen[s.id + ':' + i] || 0) + 1; });
    });
    var kinds = qs.map(function (q, k) { return mode === 'written' || k % 2 ? 'typed' : 'mcq'; });
    shuffle(kinds);
    qs.forEach(function (q, k) {
      q.seed = Date.now().toString(36) + ':' + k;
      var item = oq(oSub(q.s).qs[q.i], q.seed);
      q.kind = mode === 'written' ? 'typed' : kinds[k];
      q.perm = shuffle(ochoices(item, q.s).map(function (o, j) { return j; }));
      q.pick = -1; q.typed = ''; q.ov = false;
    });
    store.oex = { mode: mode, qs: qs, cur: 0, done: false };
    save();
  }
  function oAnswered(ox) { return ox.qs.filter(function (q) { return q.kind === 'typed' ? q.typed.trim() : q.pick >= 0; }).length; }
  function oRight(q) { var item = oq(oSub(q.s).qs[q.i], q.seed); return q.kind === 'typed' ? q.ov || typedOk(q.typed, item.a, owrong(item)) : q.perm[q.pick] === 0; }
  function drawOQ(confirming) {
    var ox = store.oex, k = ox.cur, q = ox.qs[k], item = oq(oSub(q.s).qs[q.i], q.seed), n = ox.qs.length, sub = oSub(q.s), opts = ochoices(item, q.s);
    if (q.perm.length !== opts.length) { q.perm = shuffle(opts.map(function (o, j) { return j; })); q.pick = -1; }   // an exam saved before the bank changed
    var h = '<section class="screen exam" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">Station ' + (k + 1) + ' of ' + n + '</span><span class="xsub">' + esc(sub.name) + ' · ' + (q.kind === 'typed' ? 'written' : 'MCQ') + '</span></div>' +
      '<div class="xbar"><i style="width:' + pct(oAnswered(ox), n) + '%"></i></div>' + picHtml(item) + '<h2 class="xq">' + esc(item.q) + '</h2>';
    if (q.kind === 'typed') h += '<input class="otyped" id="oexin" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Your answer" value="' + esc(q.typed) + '">';
    else {
      h += '<div class="xopts" role="radiogroup" aria-label="Answers">';
      q.perm.forEach(function (o, j) { h += '<button class="xopt' + (q.pick === j ? ' on' : '') + '" type="button" role="radio" aria-checked="' + (q.pick === j) + '" data-opick="' + j + '"><span class="k">' + ABC[j] + '</span><span>' + esc(opts[o]) + '</span></button>'; });
      h += '</div>';
    }
    h += '<div class="xnav"><button class="btn ghost" type="button" data-ostep="-1"' + (k ? '' : ' disabled') + '>← Previous</button>' +
      (k < n - 1 ? '<button class="btn" type="button" data-ostep="1">Next →</button>' : '<button class="btn" type="button" data-ofinish="1">Finish exam</button>') + '</div>';
    if (confirming) h += '<div class="xconfirm" role="alert"><p><b>' + (n - oAnswered(ox)) + ' stations are still blank.</b> Blank stations score zero.</p><div class="xnav"><button class="btn" type="button" data-ofinish="2">Finish anyway</button></div></div>';
    h += '<div class="xgrid" aria-label="Jump to a station">';
    ox.qs.forEach(function (x, j) { h += '<button type="button" class="' + ((x.kind === 'typed' ? x.typed.trim() : x.pick >= 0) ? 'a' : '') + (j === k ? ' cur' : '') + '" data-ogo="' + j + '">' + (j + 1) + '</button>'; });
    h += '</div><p class="xhint">' + oAnswered(ox) + ' of ' + n + ' answered. ' + (q.kind === 'typed' ? 'Enter for the next station.' : 'Keys: a–' + ABC[q.perm.length - 1] + ' or 1–' + q.perm.length + ', Enter for next.') + '</p>' +
      (k < n - 1 ? '<button class="btn ghost" type="button" data-ofinish="1">Finish and see my score</button>' : '') + '</section>';
    view.innerHTML = h;
    var inp = $('oexin');
    if (inp) { inp.addEventListener('input', function () { q.typed = inp.value; save(); }); try { inp.focus({ preventScroll: true }); } catch (e) {} }
  }
  function goO(k) { var ox = store.oex; ox.cur = Math.max(0, Math.min(ox.qs.length - 1, k)); save(); drawOQ(); window.scrollTo(0, 0); }
  function finishO(force) {
    var ox = store.oex;
    if (!force && oAnswered(ox) < ox.qs.length) { drawOQ(true); return; }
    ox.done = true;
    oScore(true);
    top().v = 'result'; render(true);
  }
  function oScore(log) {   // the score (again after "count it right"), by subject
    var ox = store.oex, got = 0, by = {};
    ox.qs.forEach(function (q) { var ok = oRight(q), b = by[q.s] || (by[q.s] = [0, 0]); b[1]++; if (ok) { got++; b[0]++; } });
    var r = { got: got, total: ox.qs.length, by: by, mode: ox.mode, at: Date.now() }, L = store.oexLog || (store.oexLog = []);
    if (log) L.push(r); else if (L.length) L[L.length - 1] = r;
    save();
    return r;
  }
  function drawOResult() {
    var r = (store.oexLog || [])[store.oexLog.length - 1] || oScore(true), p = pct(r.got, r.total), wrong = r.total - r.got;
    var h = '<section class="screen exam"><div class="xscore"><span class="mono">OSPE · ' + (r.mode === 'written' ? 'all written' : '50 / 50') + '</span><b>' + r.got + '<small> / ' + r.total + '</small></b><span class="pctl">' + p + '%</span>' +
      '<p>' + (p >= 85 ? 'Excellent. You are ready.' : p >= 70 ? 'Good work. Review the ones you missed.' : 'Go over the review, revise those slides, and try a new one.') + '</p></div><div class="xsubs"><h3>By subject</h3>';
    window.OSPE.forEach(function (s) {
      var b = r.by[s.id]; if (!b) return;
      h += '<div class="row" style="--sc:var(--s-' + s.id + ')"><span>' + esc(s.name) + '</span><span class="m"><i style="width:' + pct(b[0], b[1]) + '%"></i></span><b>' + b[0] + ' / ' + b[1] + '</b></div>';
    });
    h += '</div><div class="xacts">' + (wrong ? '<button class="btn big" type="button" data-oreview="1">Review my answers (' + wrong + ' wrong)</button>' : '<button class="btn big" type="button" data-oreview="1">Review my answers</button>') +
      '<button class="btn ghost big" type="button" data-onew="' + r.mode + '">Start a new OSPE</button></div></section>';
    view.innerHTML = h;
  }
  function drawOReview() {
    var ox = store.oex, h = '<section class="screen exam"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">OSPE · review</span><h1>Your answers</h1>' +
      '<p>For a written answer marked wrong that means the same thing, tap "Count it right".</p></div>';
    ox.qs.forEach(function (q, k) {
      var item = oq(oSub(q.s).qs[q.i], q.seed), ok = oRight(q), w = qbWhere(item), yours = q.kind === 'typed' ? q.typed : q.pick >= 0 ? ochoices(item, q.s)[q.perm[q.pick]] : '';
      h += '<article class="chunk xrev ' + (ok ? 'ok' : 'bad') + '" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">Station ' + (k + 1) + ' · ' + (ok ? 'Correct' : yours ? 'Wrong' : 'Not answered') + '</span><span class="xsub">' + esc(oSub(q.s).name) + '</span></div>' +
        (item.img ? '<div class="orev" style="--ar:' + (item.iw / item.ih).toFixed(3) + '"><img src="img/o/' + esc(item.img) + '" alt="" loading="lazy">' + arrowsSvg(item) + '</div>' : '') + '<h3>' + esc(item.q) + '</h3>' +
        '<div class="opts"><div class="opt' + (ok ? ' right' : ' wrong') + '"><b>You:</b> ' + esc(yours || '(blank)') + '</div><div class="opt right"><b>Answer:</b> ' + esc(item.a[0]) + '</div></div>' +
        '<div class="qfb"><b>Why:</b> ' + esc(item.w) + '<span class="mono src">Source: ' + esc(item.ref) + '</span>' +
        (q.kind === 'typed' && yours && !typedOk(q.typed, item.a, owrong(item)) ? '<button class="linkish" type="button" data-oov="' + k + '">' + (q.ov ? 'Undo: count it wrong' : 'Count it right') + '</button> ' : '') +
        (w ? '<button class="linkish" type="button" data-qcard="' + esc(w.lid + '|' + w.cid) + '">Read it: ' + esc(w.label) + '</button>' : '') + '</div></article>';
    });
    view.innerHTML = h + '<div class="xacts"><button class="btn big" type="button" data-onew="' + ox.mode + '">Start a new OSPE</button></div></section>';
  }
  function oexClick(t) {
    var el;
    if ((el = t.closest('[data-exopen]'))) { go(el.getAttribute('data-exopen') === 'ebe' ? { t: 'exam', v: 'intro' } : { t: 'oexam', v: store.oex && !store.oex.done ? 'q' : 'intro' }); return true; }
    if (top().t !== 'oexam') return false;
    if (t.closest('[data-opic]') && picQ) { openLb('img/o/' + picQ.img, picQ.iw, picQ.ih, arrowsSvg(picQ)); return true; }
    if ((el = t.closest('[data-onew]'))) { newOExam(el.getAttribute('data-onew')); while (stack.length > 1 && top().t === 'oexam' && top().v === 'review') stack.pop(); top().v = 'q'; render(true); return true; }
    if (t.closest('[data-oresume]')) { top().v = 'q'; render(true); return true; }
    if ((el = t.closest('[data-opick]'))) { store.oex.qs[store.oex.cur].pick = +el.getAttribute('data-opick'); save(); drawOQ(); return true; }
    if ((el = t.closest('[data-ostep]'))) { goO(store.oex.cur + +el.getAttribute('data-ostep')); return true; }
    if ((el = t.closest('[data-ogo]'))) { goO(+el.getAttribute('data-ogo')); return true; }
    if ((el = t.closest('[data-ofinish]'))) { finishO(el.getAttribute('data-ofinish') === '2'); return true; }
    if (t.closest('[data-oreview]')) { go({ t: 'oexam', v: 'review' }); return true; }
    if ((el = t.closest('[data-oov]'))) { var q = store.oex.qs[+el.getAttribute('data-oov')]; q.ov = !q.ov; oScore(false); render(false); return true; }
    if ((el = t.closest('[data-qcard]'))) { var c = el.getAttribute('data-qcard').split('|'); top().y = window.scrollY; stack.push({ t: 'lecture', lid: c[0], card: c[1] || undefined }); render(true); return true; }
    return false;
  }
  function oexKey(e) {
    if (top().t !== 'oexam' || top().v !== 'q' || !store.oex || store.oex.done) return false;
    var ox = store.oex, q = ox.qs[ox.cur];
    if (e.key === 'Enter') { if (ox.cur < ox.qs.length - 1) goO(ox.cur + 1); else finishO(false); return true; }
    if (e.target.closest && e.target.closest('input,textarea')) return false;
    if (q.kind === 'typed') return false;
    var k = e.key.toLowerCase(), j = /^[1-9]$/.test(k) ? +k - 1 : /^[a-e]$/.test(k) ? k.charCodeAt(0) - 97 : -1;
    if (j >= 0 && j < q.perm.length) { q.pick = j; save(); drawOQ(); return true; }
    if (e.key === 'ArrowRight') { goO(ox.cur + 1); return true; }
    if (e.key === 'ArrowLeft') { goO(ox.cur - 1); return true; }
    return false;
  }

  function renderSubject(sid) {
    var s = subject(sid);
    setBar(s.name);
    var h = '<section class="screen" style="--sc:var(--s-' + s.id + ')"><div class="subhead"><span class="mono eyebrow">' + esc(s.name) + '</span><h1>' + esc(s.name) + '</h1><p>Choose the lecture you want to study.</p></div><ul class="list">';
    s.lectures.forEach(function (l, i) {
      var d = Math.min(doneIn(l.id), l.cards), p = pct(d, l.cards);
      h += '<li style="--i:' + i + '"><button class="tile" type="button" data-lec="' + esc(l.id) + '">' +
        '<span class="num">' + (i + 1) + '</span><span class="t"><b>' + esc(l.title) + '</b><span>' + (l.qs ? l.qs + (l.qs === 1 ? ' question' : ' questions') : 'About ' + l.minutes + ' min') + ' · ' + l.cards + ' cards' + (d ? ' · ' + d + ' done' : '') + '</span>' +
        '<span class="meter"><i style="width:' + p + '%"></i></span></span><span class="pct">' + (p === 100 ? '✓' : p + '%') + '</span></button></li>';
    });
    view.innerHTML = h + '</ul></section>';
  }

  var chunks = [], curLec = null;
  function renderLecture(lid) {
    var f = findLec(lid);
    curLec = f;
    setBar(f.l.title, f.s.name + ' · Lecture ' + f.n, true);
    if (!window.LEC || !window.LEC[lid]) {
      view.innerHTML = '<p class="loading">Opening the lecture…</p>';
      var sc = document.createElement('script');
      sc.src = 'lectures/' + lid + '.js';
      sc.onload = function () { if (top().lid === lid) { renderLecture(lid); window.scrollTo(0, top().y || 0); } };
      sc.onerror = function () { view.innerHTML = '<p class="loading">This lecture could not be loaded. Go back and try again.</p>'; };
      document.body.appendChild(sc);
      return;
    }
    var next = f.s.lectures[f.n], under = stack[stack.length - 2];
    view.innerHTML = '<section class="screen lecture" style="--sc:var(--s-' + f.s.id + ')">' +
      '<div class="lec-head"><span class="mono eyebrow">' + esc(f.s.name) + ' · Lecture ' + f.n + ' · about ' + f.l.minutes + ' min</span><h1>' + esc(f.l.title) + '</h1>' +
      (f.l.intro ? '<p>' + esc(f.l.intro) + '</p>' : '') + (f.l.source ? '<p class="mono">From: ' + esc(f.l.source) + '</p>' : '') +
      ((f.l.legend || []).length ? '<div class="legend">' + f.l.legend.map(function (c) { return '<span class="chip ' + esc(c[0]) + '">' + esc(c[1]) + '</span>'; }).join('') + '</div>' : '') + '</div>' +
      window.LEC[lid] +
      '<div class="lec-end"><p id="end-msg"></p>' +
      (f.l.qs ? '<button class="btn big" type="button" data-wtest="lec:' + esc(lid) + '">Test me on these ' + f.l.qs + ' questions</button>' : '') +
      '<button class="btn' + (f.l.qs ? ' ghost' : '') + '" type="button" data-backto="1">' + (under && under.t === 'wtest' ? 'Back to my test result' : 'Back to the lectures') + '</button>' +
      (next ? '<button class="btn ghost" type="button" data-next="' + esc(next.id) + '">Next lecture: ' + esc(next.title) + ' →</button>' : '') + '</div></section>';
    chunks = Array.prototype.slice.call(view.querySelectorAll('.chunk'));
    chunks.forEach(function (c) {
      var row = document.createElement('div'); row.className = 'gotrow';
      var b = document.createElement('button'); b.type = 'button'; b.className = 'got'; b.setAttribute('data-got', c.id);
      row.appendChild(b); c.appendChild(row);
    });
    paint();
    var jump = top().card && document.getElementById(top().card);   // opened from a test result: go to that question's card
    if (jump) { delete top().card; setTimeout(function () { jump.scrollIntoView({ block: 'start' }); }, 0); }
  }

  function paint() {
    if (!curLec) return;
    var n = 0;
    chunks.forEach(function (c) {
      var d = !!store.done[c.id]; if (d) n++;
      c.classList.toggle('done', d);
      var b = c.querySelector('.got'); b.textContent = d ? 'Got it ✓' : 'Got it'; b.setAttribute('aria-pressed', String(d));
    });
    $('track-fill').style.width = pct(n, chunks.length) + '%';
    var m = $('end-msg');
    if (m) m.textContent = n === chunks.length ? 'Lecture complete. Nice work.' : n + ' of ' + chunks.length + ' cards ticked.';
  }
  function toggle(id, force) { if (force === true || (force == null && !store.done[id])) store.done[id] = 1; else delete store.done[id]; save(); paint(); pushReminders(); }
  function firstUndone() { for (var i = 0; i < chunks.length; i++) if (!store.done[chunks[i].id]) return i; return Math.max(0, chunks.length - 1); }

  /* ---------- EBE exam (its own tab) ---------- */
  // Each attempt takes `marks` questions per subject (least-seen first), mixes all subjects in random order and shuffles every question's options.
  var LETTERS = 'ABCDE';
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function runs(qs) { var n = 0; for (var i = 1; i < qs.length; i++) if (qs[i].s === qs[i - 1].s) n++; return n; }
  function bankSize() { var n = 0; window.EXAM.forEach(function (s) { n += s.qs.length; }); return n; }
  function answered(ex) { return ex.qs.filter(function (q) { return q.pick >= 0; }).length; }
  function exSub(sid) { for (var i = 0; i < window.EXAM.length; i++) if (window.EXAM[i].id === sid) return window.EXAM[i]; return { name: sid }; }
  function newExam() {
    var seen = store.seen || (store.seen = {}), qs = [];
    window.EXAM.forEach(function (sub) {
      var pool = shuffle(sub.qs.map(function (q, i) { return i; }));
      pool.sort(function (a, b) { return (seen[sub.id + ':' + a] || 0) - (seen[sub.id + ':' + b] || 0); });
      // unseen questions first; within each "times seen" tier, one per lecture group before a group repeats
      var picked = [], used = {}, times = function (i) { return seen[sub.id + ':' + i] || 0; };
      var take = function (ok) { pool.forEach(function (i) { if (picked.length < sub.marks && picked.indexOf(i) < 0 && ok(i)) { picked.push(i); used[sub.qs[i].g] = 1; } }); };
      pool.map(times).filter(function (c, k, a) { return a.indexOf(c) === k; }).forEach(function (c) {
        take(function (i) { return times(i) === c && !used[sub.qs[i].g]; });
        take(function (i) { return times(i) === c; });
      });
      picked.forEach(function (i) {
        var q = sub.qs[i], order = q.o.map(function (x, k) { return k; });
        if (!q.f) shuffle(order);   // keep the book's order when an option says "all of the above"
        seen[sub.id + ':' + i] = (seen[sub.id + ':' + i] || 0) + 1;
        qs.push({ s: sub.id, i: i, q: q.q, o: order.map(function (k) { return q.o[k]; }), a: order.indexOf(q.a), w: q.w, ref: q.ref, pick: -1 });
      });
    });
    var best = shuffle(qs.slice());   // keep the order that puts the fewest same-subject questions back to back
    for (var t = 0; t < 40 && runs(best); t++) { var c = shuffle(qs.slice()); if (runs(c) < runs(best)) best = c; }
    store.exam = { qs: best, cur: 0, done: false };
    save();
  }
  function finishExam() {
    var ex = store.exam, by = {}, got = 0;
    ex.qs.forEach(function (q) { var b = by[q.s] || (by[q.s] = [0, 0]); b[1]++; if (q.pick === q.a) { b[0]++; got++; } });
    ex.done = true;
    ex.added = 0;
    ex.qs.forEach(function (q) { if (q.i != null && q.pick !== q.a) { mark(q.s + ':' + q.i, false); ex.added++; } });
    store.examLog = (store.examLog || []).concat([{ t: Date.now(), got: got, total: ex.qs.length, by: by }]).slice(-20);
    save();
  }

  /* ---------- mistakes review: wrong exam answers come back on later days until you get each one right twice ---------- */
  function today() { var d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 864e5); }
  function mark(key, right) {   // n = right answers in a row; 2 in a row and it leaves the list
    var m = store.miss || (store.miss = {}), e = m[key];
    if (right) { if (!e) return; e.n++; e.due = today() + 1; if (e.n >= 2) delete m[key]; }
    else m[key] = { n: 0, due: today() + (e ? 1 : 0) };   // a new mistake can be reviewed today; a repeat one waits a day
  }
  function missQ(key) { var p = key.split(':'), s = exSub(p[0]); return s.qs && s.qs[+p[1]] ? { s: p[0], q: s.qs[+p[1]] } : null; }
  function dueKeys() {
    var m = store.miss || {}, d = today();
    return Object.keys(m).filter(function (k) { return m[k].due <= d && (!window.EXAM || missQ(k)); });
  }
  function missCount() { return Object.keys(store.miss || {}).length; }
  function startMist() {
    var keys = shuffle(dueKeys());
    store.rv = { qs: keys.map(function (k) { var x = missQ(k), order = x.q.o.map(function (o, j) { return j; }); if (!x.q.f) shuffle(order); return { k: k, order: order, pick: -1 }; }), cur: 0, right: 0 };
    save();
  }
  function drawMist() {
    var rv = store.rv;
    if (!rv || rv.cur >= rv.qs.length) {   // the end of today's round
      var left = missCount(), due = dueKeys().length;
      view.innerHTML = '<section class="screen exam"><div class="xscore"><span class="mono">Mistakes review</span>' +
        (rv && rv.qs.length ? '<b>' + rv.right + '<small> / ' + rv.qs.length + ' right</small></b><p>' + (rv.right === rv.qs.length ? 'All right this time. ' : 'The ones you missed come back tomorrow. ') + 'A question leaves the list after you get it right twice in a row.</p>' : '<p>Nothing to review right now.</p>') +
        '</div><p class="xhint">' + (left ? left + (left === 1 ? ' question is' : ' questions are') + ' still on your list' + (due ? ', ' + due + ' due now.' : '; the next ones are due tomorrow.') : 'Your list is empty. Wrong exam answers are added here automatically.') + '</p>' +
        '<div class="xacts">' + (due ? '<button class="btn big" type="button" data-mstart="1">Review the ' + due + ' due now</button>' : '') + '<button class="btn ghost big" type="button" data-mback="1">Back to the EBE exam</button></div></section>';
      return;
    }
    var x = rv.qs[rv.cur], f = missQ(x.k);
    if (!f) { rv.cur++; save(); drawMist(); return; }
    var q = f.q, a = x.order.indexOf(q.a), sub = exSub(f.s), shown = x.pick >= 0;
    var h = '<section class="screen exam" style="--sc:var(--s-' + f.s + ')"><div class="xhead"><span class="mono">Mistake ' + (rv.cur + 1) + ' of ' + rv.qs.length + '</span><span class="xsub">' + esc(sub.name) + '</span></div>' +
      '<div class="xbar"><i style="width:' + pct(rv.cur + (shown ? 1 : 0), rv.qs.length) + '%"></i></div>' +
      '<h2 class="xq">' + esc(q.q) + '</h2><div class="xopts" role="radiogroup" aria-label="Answers">';
    x.order.forEach(function (j, k) {
      var cls = !shown ? '' : k === a ? ' right' : k === x.pick ? ' wrong' : '';
      h += '<button class="xopt' + cls + '" type="button" data-mpick="' + k + '"' + (shown ? ' disabled' : '') + '><span class="k">' + LETTERS[k] + '</span><span>' + esc(q.o[j]) + '</span></button>';
    });
    h += '</div>';
    if (shown) h += '<div class="qfb mfb"><b>' + (x.pick === a ? 'Right. ' : 'Not this time. The answer is ' + LETTERS[a] + '. ') + '</b>' + esc(q.w) + '<span class="mono src">Source: ' + esc(q.ref) + '</span></div>' +
      '<div class="xnav"><button class="btn" type="button" data-mnext="1">' + (rv.cur < rv.qs.length - 1 ? 'Next →' : 'Finish') + '</button></div>';
    else h += '<p class="xhint">Pick an answer to see if you have it now. Keys: A–E or 1–5.</p>';
    view.innerHTML = h + '</section>';
  }
  function pickMist(k) {
    var rv = store.rv, x = rv.qs[rv.cur], f = missQ(x.k);
    if (!f || x.pick >= 0 || k >= x.order.length) return;
    x.pick = k;
    var right = x.order[k] === f.q.a;
    if (right) rv.right++;
    mark(x.k, right); save(); drawMist();
  }

  function renderExam() {
    setBar('EBE exam', 'SS module · mock exam');
    if (!window.EXAM) {
      view.innerHTML = '<p class="loading">Opening the exam…</p>';
      var sc = document.createElement('script');
      sc.src = 'assets/exam.js';
      sc.onload = function () { if (top().t === 'exam') renderExam(); };
      sc.onerror = function () { view.innerHTML = '<p class="loading">The exam could not be loaded. Go back and try again.</p>'; };
      document.body.appendChild(sc);
      return;
    }
    var v = top().v;
    if (v === 'q' && store.exam && !store.exam.done) drawQ();
    else if (v === 'result' && store.exam && store.exam.done) drawResult();
    else if (v === 'review' && store.exam && store.exam.done) drawReview();
    else if (v === 'mist') drawMist();
    else drawIntro();
  }

  function drawIntro() {
    var ex = store.exam, log = store.examLog || [], total = 0;
    var marks = window.EXAM.reduce(function (n, s) { return n + s.marks; }, 0);
    var h = '<section class="screen exam"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">Mock exam · ' + marks + ' marks</span><h1>EBE exam</h1>' +
      '<p>' + marks + ' questions, 1 mark each, all text with no pictures. Every attempt draws the questions you have seen least from a bank of ' + bankSize() + ', and mixes the subjects in a random order. You get your score and the explanations at the end.</p></div>' +
      '<div class="blueprint">';
    window.EXAM.forEach(function (s) { total += s.marks; h += '<span style="--sc:var(--s-' + s.id + ')"><b>' + esc(s.name) + '</b><i>' + s.marks + '</i></span>'; });
    h += '<span class="sum"><b>Total</b><i>' + total + '</i></span></div><div class="xacts">';
    if (ex && !ex.done) h += '<button class="btn big" type="button" data-xresume="1">Resume exam · ' + answered(ex) + ' of ' + ex.qs.length + ' answered</button><button class="btn ghost big" type="button" data-xnew="1">Start a new exam</button>';
    else h += '<button class="btn big" type="button" data-xnew="1">Start the exam</button>' + (ex && ex.done ? '<button class="btn ghost big" type="button" data-xresult="1">See my last result</button>' : '');
    h += '</div>';
    var mc = missCount(), md = dueKeys().length;
    if (mc) h += '<button class="tile cont mistile" type="button" data-mopen="1" style="--sc:var(--eosin)"><span class="badge">↻</span><span class="t"><b>Review my mistakes</b><span>' +
      (md ? md + ' due now' : 'The next ones are due tomorrow') + ' · ' + mc + ' on the list</span></span><span class="go">›</span></button>';
    if (log.length) {
      h += '<div class="xlog"><h3>Past attempts (' + log.length + ' exam' + (log.length === 1 ? '' : 's') + ' done)</h3><ul>';
      log.slice(-5).reverse().forEach(function (r) {
        var d = new Date(r.t);
        h += '<li><span>' + d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ', ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }) + '</span><b>' + r.got + ' / ' + r.total + '</b><i>' + pct(r.got, r.total) + '%</i></li>';
      });
      h += '</ul></div>';
    }
    view.innerHTML = h + '</section>';
  }

  function drawQ(confirming) {
    var ex = store.exam, i = ex.cur, q = ex.qs[i], n = ex.qs.length, left = n - answered(ex), sub = exSub(q.s);
    var h = '<section class="screen exam" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">Question ' + (i + 1) + ' of ' + n + '</span><span class="xsub">' + esc(sub.name) + '</span></div>' +
      '<div class="xbar"><i style="width:' + pct(n - left, n) + '%"></i></div>' +
      '<h2 class="xq">' + esc(q.q) + '</h2><div class="xopts" role="radiogroup" aria-label="Answers">';
    q.o.forEach(function (o, k) {
      h += '<button class="xopt' + (q.pick === k ? ' on' : '') + '" type="button" role="radio" aria-checked="' + (q.pick === k) + '" data-xpick="' + k + '"><span class="k">' + LETTERS[k] + '</span><span>' + esc(o) + '</span></button>';
    });
    h += '</div><div class="xnav"><button class="btn ghost" type="button" data-xstep="-1"' + (i ? '' : ' disabled') + '>← Previous</button>' +
      (i < n - 1 ? '<button class="btn" type="button" data-xstep="1">Next →</button>' : '<button class="btn" type="button" data-xfinish="1">Finish exam</button>') + '</div>';
    if (confirming) {
      h += '<div class="xconfirm" role="alert"><p><b>' + left + (left === 1 ? ' question is' : ' questions are') + ' still unanswered.</b> Unanswered questions score zero.</p>' +
        '<div class="xnav"><button class="btn ghost" type="button" data-xgo="' + firstBlank(ex) + '">Go to the first one</button><button class="btn" type="button" data-xfinish="2">Finish anyway</button></div></div>';
    }
    h += '<div class="xgrid" aria-label="Jump to a question">';
    ex.qs.forEach(function (x, k) { h += '<button type="button" class="' + (x.pick >= 0 ? 'a' : '') + (k === i ? ' cur' : '') + '" data-xgo="' + k + '" aria-label="Question ' + (k + 1) + '">' + (k + 1) + '</button>'; });
    h += '</div><p class="xhint">' + hint(ex) + '</p>' +
      (i < n - 1 ? '<button class="btn ghost" type="button" data-xfinish="1">Finish and see my score</button>' : '') + '</section>';
    view.innerHTML = h;
  }
  function firstBlank(ex) { for (var k = 0; k < ex.qs.length; k++) if (ex.qs[k].pick < 0) return k; return 0; }
  function goQ(k) { store.exam.cur = Math.max(0, Math.min(store.exam.qs.length - 1, k)); save(); drawQ(); window.scrollTo(0, 0); }
  function hint(ex) { return answered(ex) + ' of ' + ex.qs.length + ' answered. Keys: A–E or 1–5 to answer, Enter or → for next, ← for previous.'; }
  function pick(k) {   // update in place, so the screen doesn't redraw (and fade) on every tap
    var ex = store.exam, q = ex.qs[ex.cur];
    if (k >= q.o.length) return;
    q.pick = k; save();
    Array.prototype.forEach.call(view.querySelectorAll('.xopt'), function (b, j) { b.classList.toggle('on', j === k); b.setAttribute('aria-checked', String(j === k)); });
    view.querySelector('[data-xgo="' + ex.cur + '"]').classList.add('a');
    view.querySelector('.xbar i').style.width = pct(answered(ex), ex.qs.length) + '%';
    view.querySelector('.xhint').textContent = hint(ex);
    var c = view.querySelector('.xconfirm'); if (c) c.parentNode.removeChild(c);
  }
  function tryFinish(force) {
    if (!force && answered(store.exam) < store.exam.qs.length) { drawQ(true); var c = view.querySelector('.xconfirm'); if (c) c.scrollIntoView({ block: 'center' }); return; }
    finishExam(); top().v = 'result'; render(true);
  }

  function drawResult() {
    var ex = store.exam, r = (store.examLog || [])[store.examLog.length - 1], p = pct(r.got, r.total);
    var msg = p >= 85 ? 'Excellent. You are ready.' : p >= 70 ? 'Good work. Review the ones you missed.' : p >= 50 ? 'You passed the halfway mark. Go over the explanations, then try again.' : 'Keep going. Read the explanations, revise those lectures and try a new exam.';
    var h = '<section class="screen exam"><div class="xscore"><span class="mono">Exam ' + store.examLog.length + ' · your score</span><b>' + r.got + '<small> / ' + r.total + '</small></b><span class="pctl">' + p + '%</span><p>' + msg + '</p></div>' +
      '<div class="xsubs"><h3>By subject</h3>';
    window.EXAM.forEach(function (s) {
      var b = r.by[s.id]; if (!b) return;
      h += '<div class="row" style="--sc:var(--s-' + s.id + ')"><span>' + esc(s.name) + '</span><span class="m"><i style="width:' + pct(b[0], b[1]) + '%"></i></span><b>' + b[0] + ' / ' + b[1] + '</b></div>';
    });
    var wrong = ex.qs.filter(function (q) { return q.pick !== q.a; }).length;
    h += '</div>' + (ex.added ? '<p class="xhint mnote">' + ex.added + (ex.added === 1 ? ' wrong or blank answer was' : ' wrong or blank answers were') + ' added to your mistakes review. They come back until you get each one right twice.</p>' : '') +
      '<div class="xacts"><button class="btn big" type="button" data-xnew="1">Start a new exam (exam ' + (store.examLog.length + 1) + ')</button>' +
      (ex.added ? '<button class="btn ghost big" type="button" data-mopen="1">Review my mistakes now</button>' : '') +
      (wrong ? '<button class="btn ghost big" type="button" data-xreview="wrong">Review my ' + wrong + ' wrong or blank answers</button>' : '') +
      '<button class="btn ghost big" type="button" data-xreview="all">Review all ' + ex.qs.length + ' answers</button></div></section>';
    view.innerHTML = h;
  }

  function drawReview() {
    var ex = store.exam, only = top().only === 'wrong';
    var h = '<section class="screen exam"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">EBE exam · review</span><h1>' + (only ? 'Wrong and blank answers' : 'All answers') + '</h1></div><div class="xacts"><button class="btn big" type="button" data-xnew="1">Start a new exam</button></div>';
    ex.qs.forEach(function (q, k) {
      var ok = q.pick === q.a;
      if (only && ok) return;
      h += '<article class="chunk xrev ' + (ok ? 'ok' : 'bad') + '" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">Q' + (k + 1) + ' · ' + (ok ? 'Correct' : q.pick < 0 ? 'Not answered' : 'Wrong') + '</span><span class="xsub">' + esc(exSub(q.s).name) + '</span></div>' +
        '<h3>' + esc(q.q) + '</h3><div class="opts">';
      q.o.forEach(function (o, j) {
        var cls = j === q.a ? ' right' : j === q.pick ? ' wrong' : '';
        h += '<div class="opt' + cls + '"><b>' + LETTERS[j] + '.</b> ' + esc(o) + (j === q.a ? ' <span class="tag">correct</span>' : j === q.pick ? ' <span class="tag">your answer</span>' : '') + '</div>';
      });
      h += '</div><div class="qfb"><b>Why:</b> ' + esc(q.w) + '<span class="mono src">Source: ' + esc(q.ref) + '</span></div></article>';
    });
    view.innerHTML = h + '<div class="xacts"><button class="btn big" type="button" data-xnew="1">Start a new exam</button></div></section>';
  }

  function examClick(t) {
    var el;
    if ((el = t.closest('[data-tab]'))) { switchTab(el.getAttribute('data-tab')); return true; }
    if ((el = t.closest('[data-wtest]'))) { startTest(el.getAttribute('data-wtest')); return true; }
    if ((el = t.closest('[data-wcard]'))) { var wc = el.getAttribute('data-wcard').split('|'); openCard(wc[0], wc[1]); return true; }
    if ((el = t.closest('[data-wopen]'))) { go({ t: 'wtest', v: el.getAttribute('data-wopen') }); return true; }
    if (top().t === 'wtest') return testClick(t);
    if (top().t !== 'exam') return false;
    if (t.closest('[data-xnew]')) { newExam(); if (top().v === 'review') stack.pop(); top().v = 'q'; render(true); return true; }
    if (t.closest('[data-xresume]')) { top().v = 'q'; render(true); return true; }
    if (t.closest('[data-xresult]')) { top().v = 'result'; render(true); return true; }
    if ((el = t.closest('[data-xpick]'))) { pick(+el.getAttribute('data-xpick')); return true; }
    if ((el = t.closest('[data-xstep]'))) { goQ(store.exam.cur + +el.getAttribute('data-xstep')); return true; }
    if ((el = t.closest('[data-xgo]'))) { goQ(+el.getAttribute('data-xgo')); return true; }
    if ((el = t.closest('[data-xfinish]'))) { tryFinish(el.getAttribute('data-xfinish') === '2'); return true; }
    if ((el = t.closest('[data-xreview]'))) { go({ t: 'exam', v: 'review', only: el.getAttribute('data-xreview') }); return true; }
    if (t.closest('[data-mopen]')) { if (!store.rv || store.rv.cur >= store.rv.qs.length) startMist(); go({ t: 'exam', v: 'mist' }); return true; }
    if (t.closest('[data-mstart]')) { startMist(); render(true); return true; }
    if ((el = t.closest('[data-mpick]'))) { pickMist(+el.getAttribute('data-mpick')); return true; }
    if (t.closest('[data-mnext]')) { store.rv.cur++; save(); render(true); return true; }
    if (t.closest('[data-mback]')) { back(); return true; }
    return false;
  }
  function examKey(e) {
    if (top().t === 'wtest') return testKey(e);
    if (top().t === 'exam' && top().v === 'mist' && store.rv && store.rv.cur < store.rv.qs.length) {
      var mk = e.key.toUpperCase(), mn = LETTERS.indexOf(mk), x = store.rv.qs[store.rv.cur];
      if (mn < 0 && /^[1-5]$/.test(mk)) mn = +mk - 1;
      if (x.pick < 0 && mn >= 0 && mk.length === 1) { pickMist(mn); return true; }
      if (x.pick >= 0 && (e.key === 'ArrowRight' || (e.key === 'Enter' && !(e.target.closest && e.target.closest('button'))))) { store.rv.cur++; save(); render(true); return true; }
      return false;
    }
    if (top().t !== 'exam' || top().v !== 'q' || !store.exam || store.exam.done) return false;
    var k = e.key.toUpperCase(), n = LETTERS.indexOf(k);
    if (n < 0 && /^[1-5]$/.test(k)) n = +k - 1;
    if (n >= 0 && k.length === 1) { pick(n); return true; }
    if (e.key === 'ArrowRight' || e.key === 'Enter') {
      if (e.key === 'Enter' && e.target.closest && e.target.closest('button')) return false;   // let Enter press the focused button
      if (store.exam.cur < store.exam.qs.length - 1) goQ(store.exam.cur + 1); else tryFinish(false);
      return true;
    }
    if (e.key === 'ArrowLeft') { goQ(store.exam.cur - 1); return true; }
    return false;
  }

  /* ---------- written questions: Test me (answer from memory, reveal, tick the points you remembered) ---------- */
  var WT = window.WTEST || [], WTI = {};
  WT.forEach(function (q) { WTI[q.id] = q; });
  function wtSub(sid) { return subject(sid, WCAT) || { name: sid }; }
  function wtLec(lid) { var f = findLec(lid); return f ? f.l : { title: '' }; }
  function qnum(q) { return q.q.match(/^Q\d+/)[0]; }
  function qtext(q) { return q.q.replace(/^Q\d+\.\s*/, ''); }
  function wGot(x) { return x.got.filter(Boolean).length; }
  function wtShown(t) { return t.qs.filter(function (x) { return x.shown; }).length; }
  function wtPool(scope) {   // 'all', 'missed' (below full marks last time), 'sub:<id>' or 'lec:<id>'
    var p = scope.split(':');
    return WT.filter(function (q) {
      if (p[0] === 'all') return true;
      if (p[0] === 'missed') return (store.wlast || {})[q.id] < 1;
      return p[0] === 'sub' ? q.s === p[1] : q.lec === p[1];
    }).map(function (q) { return q.id; });
  }
  function wtName(scope) {
    var p = scope.split(':');
    return p[0] === 'all' ? 'All subjects' : p[0] === 'missed' ? 'The ones I missed' : p[0] === 'retry' ? 'Retest' : p[0] === 'sub' ? wtSub(p[1]).name : wtLec(p[1]).title;
  }
  function startTest(scope, ids) {
    ids = shuffle((ids || wtPool(scope)).slice());
    if (!ids.length) return;
    store.wt = { scope: scope, qs: ids.map(function (id) { return { id: id, got: [], shown: false, typed: '' }; }), cur: 0, done: false };
    save();
    if (WRITTEN) {   // the test is a tab of its own
      if (tab !== 'exam') { exitFocus(true); top().y = window.scrollY; tab = 'exam'; stack = stacks.exam; }
      stack.length = 1; stack[0].v = 'q';
    } else if (top().t === 'wtest') top().v = 'q';   // started (or restarted) from the test screens
    else { exitFocus(true); top().y = window.scrollY; stack.push({ t: 'wtest', v: 'q' }); }   // from a lecture's end: back returns to it
    render(true);
  }
  function openCard(lid, cid) {   // from a test result back to the question's first card
    var f = findLec(lid);
    if (!f) return;
    top().y = window.scrollY;
    if (WRITTEN) { tab = 'study'; stack = stacks.study; stack.length = 1; stack.push({ t: 'subject', sid: f.s.id }, { t: 'lecture', lid: lid, card: cid }); }
    else stack.push({ t: 'lecture', lid: lid, card: cid });   // back returns to the test result
    store[lastKey()] = lid; save(); render(true);
  }
  function finishTest() {
    var t = store.wt, got = 0, total = 0, full = 0, by = {};
    store.wlast = store.wlast || {};
    t.qs.forEach(function (x) {
      var q = WTI[x.id];
      if (!q) return;
      var g = wGot(x), n = q.pts.length, b = by[q.s] || (by[q.s] = [0, 0]);
      got += g; total += n; b[0] += g; b[1] += n; if (g === n) full++;
      store.wlast[x.id] = g / n;
    });
    t.done = true;
    store.wlog = (store.wlog || []).concat([{ t: Date.now(), scope: t.scope, got: got, total: total, full: full, n: t.qs.length, by: by }]).slice(-20);
    save();
  }

  function renderTest() {
    setBar('Test me', 'Written questions');
    var v = top().v, t = store.wt;
    t && (t.qs = t.qs.filter(function (x) { return WTI[x.id]; }));   // drop questions the notes no longer have
    if (v === 'q' && t && !t.done && t.qs.length) drawWQ();
    else if (v === 'result' && t && t.done) drawWResult();
    else drawWIntro();
  }

  function drawWIntro() {
    var t = store.wt, log = store.wlog || [], missed = wtPool('missed').length;
    var h = '<section class="screen exam"><div class="subhead" style="--sc:var(--eosin)"><span class="mono eyebrow">Written questions · ' + WT.length + ' in total</span><h1>Test me</h1>' +
      '<p>One question at a time, answered from memory like the real paper. No options to pick from.</p></div>' +
      '<ol class="steps wsteps"><li><span><b>Read</b> the question.</span></li><li><span><b>Answer it</b>: type it, write it on paper, or say it out loud.</span></li>' +
      '<li><span>Tap <b>Show the answer</b>.</span></li><li><span><b>Tick each point</b> you remembered. Be honest with yourself.</span></li></ol>';
    if (t && !t.done && t.qs.length) h += '<div class="xacts"><button class="btn big" type="button" data-wresume="1">Resume: ' + esc(wtName(t.scope)) + ' · ' + wtShown(t) + ' of ' + t.qs.length + ' done</button></div>';
    var opts = [['all', 'Everything', WT.length, '']];
    if (missed) opts.push(['missed', 'Only the ones I missed', missed, '']);
    WCAT.forEach(function (s) { var n = wtPool('sub:' + s.id).length; if (n) opts.push(['sub:' + s.id, s.name, n, s.id]); });
    h += '<h3 class="wpick">What should I test you on?</h3><ul class="list">';
    opts.forEach(function (o, i) {
      h += '<li style="--i:' + i + '"><button class="tile" type="button" data-wtest="' + o[0] + '" style="--sc:var(--' + (o[3] ? 's-' + o[3] : 'eosin') + ')">' +
        '<span class="badge">' + (o[3] ? esc(badge(o[1])) : o[0] === 'all' ? '★' : '↻') + '</span><span class="t"><b>' + esc(o[1]) + '</b><span>' +
        o[2] + (o[2] === 1 ? ' question' : ' questions') + ', in a random order</span></span><span class="go">›</span></button></li>';
    });
    h += '</ul>';
    if (log.length) {
      h += '<div class="xlog"><h3>Past tests (' + log.length + ')</h3><ul>';
      log.slice(-5).reverse().forEach(function (r) {
        var d = new Date(r.t);
        h += '<li><span>' + d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ' · ' + esc(wtName(r.scope)) + '</span><b>' + r.got + ' / ' + r.total + '</b><i>' + pct(r.got, r.total) + '%</i></li>';
      });
      h += '</ul></div>';
    }
    view.innerHTML = h + '</section>';
  }

  function drawWQ(confirming) {
    var t = store.wt, i = t.cur, x = t.qs[i], q = WTI[x.id], n = t.qs.length, left = n - wtShown(t);
    var h = '<section class="screen exam wtest" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">Question ' + (i + 1) + ' of ' + n + '</span><span class="xsub">' + esc(wtSub(q.s).name) + '</span></div>' +
      '<div class="xbar"><i style="width:' + pct(n - left, n) + '%"></i></div>' +
      '<div class="wqhead"><span class="mono wfrom">' + esc(qnum(q)) + ' · ' + esc(wtLec(q.lec).title) + '</span><h2 class="xq">' + esc(qtext(q)) + '</h2></div>' +
      (x.shown ? '' : '<p class="wcount">This answer has <b>' + q.pts.length + ' points</b>. Try to list all ' + q.pts.length + ' before you look.</p>') +
      '<label class="wtype-l" for="wt-typed">Your answer (optional)</label>' +
      '<textarea id="wt-typed" class="wtype" rows="5" placeholder="Type it here, write it on paper, or say it out loud.">' + esc(x.typed || '') + '</textarea>';
    if (!x.shown) h += '<button class="btn big" type="button" data-wshow="1">Show the answer</button>';
    else {
      h += '<div class="wpts"><h3>Tick what you remembered</h3>';
      q.pts.forEach(function (p, k) {
        h += '<button type="button" class="wpt' + (x.got[k] ? ' on' : '') + '" data-wpt="' + k + '" aria-pressed="' + !!x.got[k] + '"><span class="box" aria-hidden="true"></span><span>' + esc(p) + '</span></button>';
      });
      h += '<p class="wscore">' + wGot(x) + ' of ' + q.pts.length + ' points remembered</p></div>' +
        '<details class="wfull"><summary>See the full model answer</summary><div class="wans">' + q.a + '</div></details>';
    }
    h += '<div class="xnav"><button class="btn ghost" type="button" data-wstep="-1"' + (i ? '' : ' disabled') + '>← Previous</button>' +
      (i < n - 1 ? '<button class="btn" type="button" data-wstep="1">Next →</button>' : '<button class="btn" type="button" data-wfinish="1">Finish test</button>') + '</div>';
    if (confirming) {
      var first = 0; while (first < n && t.qs[first].shown) first++;
      h += '<div class="xconfirm" role="alert"><p><b>' + left + (left === 1 ? ' question is' : ' questions are') + ' not answered yet.</b> They count as zero points.</p>' +
        '<div class="xnav"><button class="btn ghost" type="button" data-wgo="' + first + '">Go to the first one</button><button class="btn" type="button" data-wfinish="2">Finish anyway</button></div></div>';
    }
    h += '<div class="xgrid" aria-label="Jump to a question">';
    t.qs.forEach(function (y, k) { h += '<button type="button" class="' + (y.shown ? 'a' : '') + (k === i ? ' cur' : '') + '" data-wgo="' + k + '" aria-label="Question ' + (k + 1) + '">' + (k + 1) + '</button>'; });
    h += '</div><p class="xhint">' + (x.shown ? 'Keys: 1–9 tick a point, → next, ← previous.' : 'Key: Enter shows the answer (when you are not typing).') + '</p>' +
      (i < n - 1 ? '<button class="btn ghost" type="button" data-wfinish="1">Finish and see my score</button>' : '') + '</section>';
    view.innerHTML = h;
  }
  function reveal() {
    store.wt.qs[store.wt.cur].shown = true; save(); drawWQ();
    var p = view.querySelector('.wpts'); if (p) p.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
  function tick(k) {   // in place, so the screen doesn't redraw on every tap
    var x = store.wt.qs[store.wt.cur], q = WTI[x.id];
    if (!x.shown || k >= q.pts.length) return;
    x.got[k] = !x.got[k]; save();
    var b = view.querySelector('[data-wpt="' + k + '"]'); b.classList.toggle('on', x.got[k]); b.setAttribute('aria-pressed', String(x.got[k]));
    view.querySelector('.wscore').textContent = wGot(x) + ' of ' + q.pts.length + ' points remembered';
  }
  function goWQ(k) { store.wt.cur = Math.max(0, Math.min(store.wt.qs.length - 1, k)); save(); drawWQ(); window.scrollTo(0, 0); }
  function tryFinishTest(force) {
    if (!force && wtShown(store.wt) < store.wt.qs.length) { drawWQ(true); var c = view.querySelector('.xconfirm'); if (c) c.scrollIntoView({ block: 'center' }); return; }
    finishTest(); top().v = 'result'; render(true);
  }

  function drawWResult() {
    var t = store.wt, r = store.wlog[store.wlog.length - 1], p = pct(r.got, r.total);
    var msg = p >= 85 ? 'Excellent. You can write these.' : p >= 65 ? 'Good. Go over the points you missed below.' : p >= 40 ? 'Halfway there. Study the cards for the ones below, then retest just those.' : 'This is how memorising starts. Study the cards below, then retest just those.';
    var miss = t.qs.filter(function (x) { var q = WTI[x.id]; return q && wGot(x) < q.pts.length; });
    var h = '<section class="screen exam"><div class="xscore"><span class="mono">' + esc(wtName(t.scope)) + ' · your score</span><b>' + r.got + '<small> / ' + r.total + ' points</small></b><span class="pctl">' + p + '%</span>' +
      '<p>' + r.full + ' of ' + r.n + (r.n === 1 ? ' question' : ' questions') + ' fully remembered. ' + msg + '</p></div>';
    var subs = WCAT.filter(function (s) { return r.by[s.id]; });
    if (subs.length > 1) {
      h += '<div class="xsubs"><h3>By subject</h3>';
      subs.forEach(function (s) { var b = r.by[s.id]; h += '<div class="row" style="--sc:var(--s-' + s.id + ')"><span>' + esc(s.name) + '</span><span class="m"><i style="width:' + pct(b[0], b[1]) + '%"></i></span><b>' + b[0] + ' / ' + b[1] + '</b></div>'; });
      h += '</div>';
    }
    h += '<div class="xacts">' + (miss.length ? '<button class="btn big" type="button" data-wretry="1">Retest only the ' + miss.length + ' I missed</button>' : '') +
      '<button class="btn ' + (miss.length ? 'ghost ' : '') + 'big" type="button" data-wagain="1">Test me again on all ' + t.qs.length + '</button>' +
      '<button class="btn ghost big" type="button" data-whome="1">Choose another test</button></div>';
    if (miss.length) {
      h += '<h3 class="wpick">What you missed</h3>';
      miss.forEach(function (x) {
        var q = WTI[x.id];
        h += '<article class="chunk xrev bad" style="--sc:var(--s-' + q.s + ')"><div class="xhead"><span class="mono">' + esc(qnum(q)) + ' · ' + wGot(x) + ' of ' + q.pts.length + ' points</span><span class="xsub">' + esc(wtSub(q.s).name) + '</span></div>' +
          '<h3>' + esc(qtext(q)) + '</h3><ul class="wmiss">';
        q.pts.forEach(function (pt, k) { h += '<li class="' + (x.got[k] ? 'ok' : 'no') + '">' + esc(pt) + '</li>'; });
        h += '</ul><button class="btn ghost" type="button" data-wcard="' + esc(q.lec + '|' + q.c) + '">Study this question\'s cards</button></article>';
      });
    }
    view.innerHTML = h + '</section>';
  }

  function testClick(t) {
    var el, ts = store.wt, ids = function (only) { return ts.qs.filter(function (x) { var q = WTI[x.id]; return q && (!only || wGot(x) < q.pts.length); }).map(function (x) { return x.id; }); };
    if (t.closest('[data-wresume]')) { top().v = 'q'; render(true); return true; }
    if (t.closest('[data-whome]')) { top().v = 'intro'; render(true); return true; }
    if (t.closest('[data-wretry]')) { startTest('retry', ids(true)); return true; }
    if (t.closest('[data-wagain]')) { startTest(ts.scope, ids(false)); return true; }
    if (t.closest('[data-wshow]')) { reveal(); return true; }
    if ((el = t.closest('[data-wpt]'))) { tick(+el.getAttribute('data-wpt')); return true; }
    if ((el = t.closest('[data-wstep]'))) { goWQ(ts.cur + +el.getAttribute('data-wstep')); return true; }
    if ((el = t.closest('[data-wgo]'))) { goWQ(+el.getAttribute('data-wgo')); return true; }
    if ((el = t.closest('[data-wfinish]'))) { tryFinishTest(el.getAttribute('data-wfinish') === '2'); return true; }
    return false;
  }
  function testKey(e) {
    if (top().t !== 'wtest' || top().v !== 'q' || !store.wt || store.wt.done) return false;
    if (e.target.closest && e.target.closest('textarea, input')) return false;
    var x = store.wt.qs[store.wt.cur], onBtn = e.target.closest && e.target.closest('button');
    if (e.key === 'Enter' && onBtn) return false;   // let Enter press the focused button
    if (!x.shown && e.key === 'Enter') { reveal(); return true; }
    if (x.shown && /^[1-9]$/.test(e.key)) { tick(+e.key - 1); return true; }
    if (e.key === 'ArrowRight' || e.key === 'Enter') { if (store.wt.cur < store.wt.qs.length - 1) goWQ(store.wt.cur + 1); else tryFinishTest(false); return true; }
    if (e.key === 'ArrowLeft') { goWQ(store.wt.cur - 1); return true; }
    return false;
  }
  document.addEventListener('input', function (e) {
    if (e.target.id === 'wt-typed' && store.wt && !store.wt.done) { store.wt.qs[store.wt.cur].typed = e.target.value; save(); }
    if (e.target.id === 'find') find(e.target.value);
  });

  /* ---------- focus mode ---------- */
  var focusing = false, cur = 0;
  function show(i) {
    cur = Math.max(0, Math.min(chunks.length - 1, i));
    chunks.forEach(function (c, k) { c.classList.toggle('current', k === cur); });
    $('fctx').innerHTML = '<b>' + (cur + 1) + ' / ' + chunks.length + '</b>';
    window.scrollTo(0, 0);
  }
  function enterFocus(i) { if (!chunks.length) return; focusing = true; document.body.classList.add('focusing'); $('focusbar').hidden = false; $('btn-focus').textContent = 'Exit focus'; show(i); guardBack(); }
  function exitFocus(quiet) {
    if (!focusing) return;
    focusing = false; document.body.classList.remove('focusing'); $('focusbar').hidden = true; $('btn-focus').textContent = 'Focus';
    var c = chunks[cur]; chunks.forEach(function (x) { x.classList.remove('current'); });
    if (!quiet && c) c.scrollIntoView({ block: 'start' });
  }
  function nextCard() { toggle(chunks[cur].id, true); if (cur < chunks.length - 1) show(cur + 1); else exitFocus(); }
  $('btn-focus').addEventListener('click', function () { if (focusing) exitFocus(); else enterFocus(firstUndone()); });
  $('btn-resume').addEventListener('click', function () { var i = firstUndone(); if (focusing) show(i); else if (chunks[i]) chunks[i].scrollIntoView({ block: 'start', behavior: 'smooth' }); });
  $('f-prev').addEventListener('click', function () { show(cur - 1); });
  $('f-next').addEventListener('click', nextCard);
  $('f-exit').addEventListener('click', function () { exitFocus(); });

  /* ---------- clicks ---------- */
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t.closest) return;
    var el;
    if (examClick(t)) return;
    if (oexClick(t)) return;
    if (updatesClick(t)) return;
    if (remindClick(t)) return;
    if (creatorClick(t)) return;
    if (qbClick(t)) return;
    if ((el = t.closest('[data-hit]'))) { var hit = el.getAttribute('data-hit').split('|'); openHit(hit[0], hit[1]); return; }
    if ((el = t.closest('[data-sub]'))) { go({ t: 'subject', sid: el.getAttribute('data-sub') }); return; }
    if ((el = t.closest('[data-lec]'))) {
      var lid = el.getAttribute('data-lec'), f = findLec(lid);
      if (top().t === 'home') { top().y = window.scrollY; stack.push({ t: 'subject', sid: f.s.id }); }
      store[lastKey()] = lid; save(); go({ t: 'lecture', lid: lid }); return;
    }
    if ((el = t.closest('[data-next]'))) { var nid = el.getAttribute('data-next'); store[lastKey()] = nid; save(); stack.pop(); go({ t: 'lecture', lid: nid }); return; }
    if (t.closest('[data-backto]')) { back(); return; }
    if ((el = t.closest('[data-got]'))) {
      var id = el.getAttribute('data-got'); toggle(id);
      if (!focusing && store.done[id]) { var k = chunks.indexOf(document.getElementById(id)); if (chunks[k + 1]) chunks[k + 1].scrollIntoView({ block: 'start', behavior: 'smooth' }); }
      return;
    }
    if ((el = t.closest('.opt'))) {
      var q = el.closest('.quizq'), opts = Array.prototype.slice.call(q.querySelectorAll('.opt')), ans = +q.getAttribute('data-ans'), pick = opts.indexOf(el), fb = q.querySelector('.qfb');
      opts.forEach(function (x, j) { x.classList.toggle('right', j === ans); x.classList.toggle('wrong', j === pick && j !== ans); });
      fb.hidden = false;
      fb.innerHTML = (pick === ans ? '<b>Correct.</b> ' : '<b>Not quite.</b> The answer is ' + 'abcdefg'[ans] + '. ') + esc(q.getAttribute('data-why') || '');
      return;
    }
    if ((el = t.closest('.dz'))) { var img = el.querySelector('img'); openLb(img.getAttribute('src'), img.naturalWidth || +img.getAttribute('width'), img.naturalHeight || +img.getAttribute('height')); }
  });
  document.addEventListener('keydown', function (e) {
    if (splashKey && splashKey(e)) return;
    if (document.querySelector('.sheet-wrap')) {   // the What's new sheet: Escape or Enter closes it
      if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); closeSheet(); }
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (!$('lightbox').hidden) {
      if (e.key === 'Escape') { e.preventDefault(); closeLb(); }
      else if (e.key === '+' || e.key === '=') zoomBy(1.5);
      else if (e.key === '-') zoomBy(1 / 1.5);
      else if (e.key === '0') fitZ();
      return;
    }
    if (e.key === 'Escape') { e.preventDefault(); back(); return; }
    if (qbKey(e)) { e.preventDefault(); return; }
    if (oexKey(e)) { e.preventDefault(); return; }
    if (examKey(e)) { e.preventDefault(); return; }
    if (!focusing) return;
    if (e.key === 'ArrowRight' || (e.key === 'Enter' && !t2(e))) { e.preventDefault(); nextCard(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); show(cur - 1); }
  });
  function t2(e) { return e.target.closest && e.target.closest('button,summary'); }

  /* ---------- diagram zoom (pinch, double-tap, wheel, buttons) ---------- */
  var lb = $('lightbox'), ZMAX = 6, Z = { s: 1, tx: 0, ty: 0, base: null, el: null };
  var ptrs = {}, gesture = null, lastTap = 0, lastTapXY = null, tapTimer = null;
  function openLb(src, w, h, extra) {   // extra: drawn over the picture (an OSPE picture's arrows)
    $('lb-body').innerHTML = '<div class="zf" id="zf" style="--ar:' + ((w && h) ? (w / h).toFixed(3) : '1.4') + '"><img src="' + esc(src) + '" alt="Zoomed diagram" draggable="false">' + (extra || '') + '</div>';
    lb.hidden = false; document.documentElement.classList.add('lb-open');
    Z.el = $('zf'); Z.base = null; fitZ(); guardBack();
  }
  function closeLb() { clearTimeout(tapTimer); ptrs = {}; gesture = null; lb.hidden = true; document.documentElement.classList.remove('lb-open'); $('lb-body').innerHTML = ''; Z.el = null; }
  function measure() {
    var t = Z.el.style.transform; Z.el.style.transform = 'none';
    var r = Z.el.getBoundingClientRect(), v = lb.getBoundingClientRect(); Z.el.style.transform = t;
    Z.base = { x: r.left - v.left, y: r.top - v.top, w: r.width, h: r.height, vw: v.width, vh: v.height, ox: v.left, oy: v.top };
  }
  function clampZ() {
    var b = Z.base;
    if (Z.s <= 1.001) { Z.s = 1; Z.tx = 0; Z.ty = 0; return; }
    var w = b.w * Z.s, h = b.h * Z.s;
    Z.tx = w <= b.vw ? (b.vw - w) / 2 - b.x : Math.min(-b.x, Math.max(b.vw - w - b.x, Z.tx));
    Z.ty = h <= b.vh ? (b.vh - h) / 2 - b.y : Math.min(-b.y, Math.max(b.vh - h - b.y, Z.ty));
  }
  function applyZ() {
    if (!Z.el) return;
    if (!Z.base) measure();
    clampZ();
    Z.el.style.transform = 'translate(' + Z.tx + 'px,' + Z.ty + 'px) scale(' + Z.s + ')';
    $('lb-pct').textContent = Math.round(Z.s * 100) + '%';
    $('lb-hint').hidden = Z.s > 1;
  }
  function zoomAt(fx, fy, s2) {
    if (!Z.el) return;
    if (!Z.base) measure();
    var px = fx - Z.base.ox, py = fy - Z.base.oy;
    s2 = Math.max(1, Math.min(ZMAX, s2));
    var cx = (px - Z.base.x - Z.tx) / Z.s, cy = (py - Z.base.y - Z.ty) / Z.s;
    Z.s = s2; Z.tx = px - Z.base.x - cx * s2; Z.ty = py - Z.base.y - cy * s2;
    applyZ();
  }
  function zoomBy(f) { if (!Z.el) return; if (!Z.base) measure(); zoomAt(Z.base.ox + Z.base.vw / 2, Z.base.oy + Z.base.vh / 2, Z.s * f); }
  function fitZ() { Z.s = 1; Z.tx = 0; Z.ty = 0; applyZ(); }
  function dist(a, b) { return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)) || 1; }
  lb.addEventListener('pointerdown', function (e) {
    if (!Z.el || (e.target.closest && e.target.closest('button'))) return;
    if (!Z.base) measure();
    try { lb.setPointerCapture(e.pointerId); } catch (err) {}
    ptrs[e.pointerId] = { x: e.clientX, y: e.clientY };
    var ids = Object.keys(ptrs);
    if (ids.length === 1) gesture = { kind: 'pan', x0: e.clientX, y0: e.clientY, tx0: Z.tx, ty0: Z.ty, moved: false, onPic: !!(e.target.closest && e.target.closest('#zf')) };
    else if (ids.length === 2) {
      clearTimeout(tapTimer);
      var a = ptrs[ids[0]], b = ptrs[ids[1]], mx = (a.x + b.x) / 2 - Z.base.ox, my = (a.y + b.y) / 2 - Z.base.oy;
      gesture = { kind: 'pinch', d0: dist(a, b), s0: Z.s, cx: (mx - Z.base.x - Z.tx) / Z.s, cy: (my - Z.base.y - Z.ty) / Z.s };
    }
  });
  lb.addEventListener('pointermove', function (e) {
    if (!ptrs[e.pointerId] || !gesture) return;
    ptrs[e.pointerId] = { x: e.clientX, y: e.clientY };
    var ids = Object.keys(ptrs);
    if (gesture.kind === 'pinch' && ids.length >= 2) {
      var a = ptrs[ids[0]], b = ptrs[ids[1]], mx = (a.x + b.x) / 2 - Z.base.ox, my = (a.y + b.y) / 2 - Z.base.oy;
      var s2 = Math.max(1, Math.min(ZMAX, gesture.s0 * dist(a, b) / gesture.d0));
      Z.s = s2; Z.tx = mx - Z.base.x - gesture.cx * s2; Z.ty = my - Z.base.y - gesture.cy * s2; applyZ();
    } else if (gesture.kind === 'pan') {
      var dx = e.clientX - gesture.x0, dy = e.clientY - gesture.y0;
      if (Math.abs(dx) + Math.abs(dy) > 8) gesture.moved = true;
      if (gesture.moved && Z.s > 1) { Z.tx = gesture.tx0 + dx; Z.ty = gesture.ty0 + dy; applyZ(); }
    }
  });
  function endPtr(e) {
    if (!ptrs[e.pointerId]) return;
    delete ptrs[e.pointerId];
    var left = Object.keys(ptrs);
    if (gesture && gesture.kind === 'pinch') {
      if (left.length === 1) { var p = ptrs[left[0]]; gesture = { kind: 'pan', x0: p.x, y0: p.y, tx0: Z.tx, ty0: Z.ty, moved: true }; }
      else if (!left.length) gesture = null;
      return;
    }
    if (gesture && gesture.kind === 'pan' && !gesture.moved && e.type === 'pointerup') {
      var now = Date.now(), near = lastTapXY && Math.abs(lastTapXY.x - e.clientX) < 30 && Math.abs(lastTapXY.y - e.clientY) < 30;
      if (now - lastTap < 320 && near) { lastTap = 0; clearTimeout(tapTimer); if (Z.s > 1.05) fitZ(); else zoomAt(e.clientX, e.clientY, 2.5); }
      else { lastTap = now; lastTapXY = { x: e.clientX, y: e.clientY }; if (!gesture.onPic && Z.s <= 1.001) tapTimer = setTimeout(closeLb, 330); }
    }
    if (!left.length) gesture = null;
  }
  lb.addEventListener('pointerup', endPtr);
  lb.addEventListener('pointercancel', endPtr);
  lb.addEventListener('wheel', function (e) { e.preventDefault(); zoomAt(e.clientX, e.clientY, Z.s * Math.exp(-e.deltaY * 0.0015)); }, { passive: false });
  $('lb-in').addEventListener('click', function () { zoomBy(1.5); });
  $('lb-out').addEventListener('click', function () { zoomBy(1 / 1.5); });
  $('lb-fit').addEventListener('click', fitZ);
  $('lb-close').addEventListener('click', closeLb);
  window.addEventListener('resize', function () { if (Z.el) { Z.base = null; fitZ(); } });

  /* ---------- opening animation: a pen dot writes SS STUDY, then (in the study app) you choose where to start ---------- */
  var splashKey = null, CHOOSE = !WRITTEN && !ONLY_EXAM, startIds = [];
  function starts() {
    var ex = store.exam, wt = store.wt, last = store.last && findLec(store.last);
    var opts = [['study', 'Study', last ? 'Continue: ' + last.l.title : 'Learn the lectures, card by card'],
      ['exam', 'Exams', (ex && !ex.done ? 'EBE exam in progress · ' + answered(ex) + ' of ' + ex.qs.length + ' answered' : 'EBE and OSPE mock exams') +
        (dueKeys().length ? ' · ' + dueKeys().length + ' mistakes to review' : '')],
      ['qbank', 'Question bank', 'Every subject, level by level · check each answer'],
      ['ospe', 'OSPE', 'Pictures, prelabs and eye drugs'],
      ['written', 'Written', wt && !wt.done && wt.qs.length ? 'Test in progress · ' + wtShown(wt) + ' of ' + wt.qs.length + ' done' : WT.length + ' questions · learn them, then Test me']];
    opts = opts.filter(function (o) { return (o[0] !== 'written' || WT.length) && (o[0] !== 'ospe' || OCAT.length); });   // tabs with no content yet stay hidden
    startIds = opts.map(function (o) { return o[0]; });
    return '<div class="starts">' + (ME ? '<p class="hi">Welcome, ' + CREATOR + '</p>' : '') + '<p>Where do you want to start?</p>' + opts.map(function (o, k) {
      return '<button type="button" data-start="' + o[0] + '" style="--k:' + k + '"><span class="n">' + (k + 1) + '</span><span class="t"><b>' + o[1] + '</b><span>' + esc(o[2]) + '</span></span><span class="go">›</span></button>';
    }).join('') + '</div>';
  }
  function splash() {
    var G = { C: ['M30.4 6.4 A17 25 0 1 0 30.4 43.6'], N: ['M0 50 L0 0 L30 50 L30 0'], S: ['M29 7 C26 1 4 -1 2 12 C0 24 30 22 30 36 C30 50 6 53 1 43'],
      T: ['M0 0 L30 0', 'M15 0 L15 50'], U: ['M0 0 L0 33 C0 55 30 55 30 33 L30 0'], D: ['M0 50 L0 0 L9 0 C38 0 38 50 9 50 L0 50'], Y: ['M0 0 L15 24 L30 0', 'M15 24 L15 50'],
      P: ['M0 50 L0 0 L14 0 C34 0 34 27 14 27 L0 27'], E: ['M27 0 L0 0 L0 50 L27 50', 'M0 25 L21 25'], I: ['M2 0 L2 50'], A: ['M0 50 L15 0 L30 50', 'M6 32 L24 32'], L: ['M0 0 L0 50 L26 50'] };
    var GW = { C: 34, N: 30, S: 30, T: 30, U: 30, D: 31, Y: 30, P: 28, E: 27, I: 4, A: 30, L: 26 };
    function word(txt, scale, gap, y, cls, sw) {
      var total = 0, x, out = [];
      txt.split('').forEach(function (ch, i) { total += GW[ch] * scale + (i ? gap : 0); });
      x = (260 - total) / 2;
      txt.split('').forEach(function (ch, li) { G[ch].forEach(function (d) { out.push({ d: d, x: x, y: y, s: scale, cls: cls, sw: sw, li: li }); }); x += GW[ch] * scale + gap; });
      return out;
    }
    var nLec = 0, nSub = 0; CAT.forEach(function (s) { if (s.lectures.length) nSub++; nLec += s.lectures.length; });
    // the study app first writes SPECIAL SENSES; all but the two S's fade, and those glide up to become the small "SS"
    var INTRO = !WRITTEN && !ONLY_EXAM, small = word('SS', 0.5, 8, 16, 'ink-small', 9), kept = 0;
    var strokes = !INTRO ? small : word('SPECIAL', 0.8, 8, 26, 'ink-big', 8).concat(word('SENSES', 0.8, 8, 84, 'ink-big', 8)).map(function (k) {
      k.intro = 1; if (k.li === 0) k.to = small[kept++]; return k;
    });
    strokes = strokes.concat(word('STUDY', 0.95, 11, 56, 'ink-big', 8));
    strokes.push({ d: 'M0 0 L150 0', x: 55, y: 126, s: 1, cls: 'ink-line', sw: 6 });
    var svg = '<svg viewBox="0 0 260 160" aria-hidden="true">';
    strokes.forEach(function (k, i) { svg += '<path id="sp' + i + '" class="' + k.cls + '" d="' + k.d + '" transform="translate(' + k.x + ' ' + k.y + ') scale(' + k.s + ')" stroke-width="' + k.sw + '"/>'; });
    svg += '<text class="tag" x="130" y="150" text-anchor="middle">' + (WRITTEN ? WT.length + ' WRITTEN QUESTIONS' : nSub + ' SUBJECTS · ' + nLec + ' LECTURES') + (WEB ? '' : ' · OFFLINE') + '</text>' +
      '<circle class="ring" cx="0" cy="0" r="0" stroke-width="2" opacity="0"/><circle class="pen" cx="0" cy="0" r="4.5" opacity="0"/></svg>';
    var el = document.createElement('div');
    el.className = 'splash' + (CHOOSE ? ' pickable' : '');
    if (CHOOSE) { el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Choose where to start'); }
    else el.setAttribute('aria-hidden', 'true');
    el.innerHTML = '<div class="splash-in">' + svg + (CHOOSE ? starts() : '') + '</div><span class="skip">Tap to skip</span>' + (APPV ? '<span class="ver">v' + esc(APPV) + '</span>' : '');
    document.body.appendChild(el);
    var done = false, choosing = false, shownAt = 0, logo = el.querySelector('svg');
    function centre() {   // the pen writes in the middle of the screen; then the logo slides up to make room for the choices
      if (!CHOOSE || choosing) return;
      logo.style.transition = 'none'; logo.style.transform = 'none';   // measure where it ends up, without animating there
      var r = logo.getBoundingClientRect(), v = el.getBoundingClientRect();
      el.style.setProperty('--lx', (v.left + v.width / 2 - r.left - r.width / 2) + 'px');
      el.style.setProperty('--ly', (v.top + v.height / 2 - r.top - r.height / 2) + 'px');
      logo.style.transform = ''; logo.getBoundingClientRect(); logo.style.transition = '';
    }
    centre();
    window.addEventListener('resize', centre);
    function close(name) {
      if (done) return; done = true; splashKey = null;
      window.removeEventListener('resize', centre);
      if (name && name !== tab) switchTab(name);
      el.classList.add('out'); setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); whatsNew(); checkMessages(); welcome(); keyNag(); checkIn(); }, 480);
    }
    function finish() {   // the drawing is done or skipped: close, or show the three choices
      if (done || choosing) return;
      if (!CHOOSE) { close(); return; }
      choosing = true; shownAt = Date.now();
      paths.forEach(function (o) { o.p.style.strokeDashoffset = 0; }); settle();
      pen.setAttribute('opacity', 0); ring.setAttribute('opacity', 0); tag.classList.add('on');
      el.classList.add('choosing');
      try { el.querySelector('[data-start]').focus({ preventScroll: true }); } catch (e) {}
    }
    splashKey = function (e) {
      if (!choosing) { e.preventDefault(); finish(); return true; }
      var n = '123'.indexOf(e.key);
      if (e.repeat) e.preventDefault();   // a key held down to skip the drawing doesn't also pick
      else if (n >= 0 && n < startIds.length && e.key.length === 1) { e.preventDefault(); close(startIds[n]); }
      else if (e.key === 'Escape') { e.preventDefault(); close(); }
      return true;   // Tab and Enter still move between the buttons and press them
    };
    el.addEventListener('pointerdown', function () { if (!choosing) finish(); });
    el.addEventListener('click', function (e) {
      e.stopPropagation();
      var b = e.target.closest && e.target.closest('[data-start]');
      if (b && choosing && Date.now() - shownAt > 600) close(b.getAttribute('data-start'));   // not the same tap that skipped the drawing
    });
    var paths = strokes.map(function (k, i) {
      var p = el.querySelector('#sp' + i), L = p.getTotalLength();
      p.style.strokeDasharray = L + ' ' + L; p.style.strokeDashoffset = L;
      return { p: p, L: L, k: k };
    });
    var pen = el.querySelector('.pen'), ring = el.querySelector('.ring'), tag = el.querySelector('.tag');
    var keep = paths.filter(function (o) { return o.k.to; });
    function place(o, f) {   // a kept S, part way (f = 0..1) from its place in SPECIAL SENSES to its place in "SS"
      var a = o.k, b = a.to, g = ease(f);
      o.p.setAttribute('transform', 'translate(' + (a.x + (b.x - a.x) * g) + ' ' + (a.y + (b.y - a.y) * g) + ') scale(' + (a.s + (b.s - a.s) * g) + ')');
    }
    function fadeIntro() {
      paths.forEach(function (o) { if (o.k.intro && !o.k.to) o.p.classList.add('gone'); });
      keep.forEach(function (o) { o.p.setAttribute('class', 'ink-small'); });
    }
    function settle() {   // skipped: no fade, the letters just go
      paths.forEach(function (o) { if (o.k.intro && !o.k.to) o.p.style.transition = 'none'; });
      fadeIntro(); keep.forEach(function (o) { place(o, 1); });
    }
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) {
      paths.forEach(function (o) { o.p.style.strokeDashoffset = 0; }); settle(); tag.classList.add('on'); setTimeout(finish, CHOOSE ? 0 : 900); return;
    }
    function at(o, len) { var q = o.p.getPointAtLength(len); return { x: o.k.x + q.x * o.k.s, y: o.k.y + q.y * o.k.s }; }
    var tl = [], t = 200, SPEED = 0.78, LIFT = 34;
    paths.forEach(function (o, i) {
      if (i && paths[i - 1].k.intro && !o.k.intro) {   // SPECIAL SENSES is written: fade "pecial" and "enses", then the S's glide up
        tl.push({ fx: fadeIntro, t0: t + 250 }); t += 250 + 500;
        tl.push({ mv: 1, t0: t, t1: t + 750 }); t += 750 + 150;
      }
      if (i) { tl.push({ a: at(paths[i - 1], paths[i - 1].L), b: at(o, 0), t0: t, t1: t + LIFT }); t += LIFT; }
      var dur = Math.max(70, o.L * o.k.s / (o.k.intro ? 1.05 : SPEED)); tl.push({ o: o, t0: t, t1: t + dur }); t += dur;
    });
    var END = t, start = null;
    function ease(x) { return 0.5 - Math.cos(Math.PI * x) / 2; }
    function frame(now) {
      if (done || choosing) return;
      if (start == null) start = now;
      var e = now - start, pos = at(paths[0], 0);
      pen.setAttribute('opacity', Math.min(1, e / 160));
      for (var i = 0; i < tl.length && e >= tl[i].t0; i++) {
        var seg = tl[i];
        if (seg.fx) { if (!seg.ran) { seg.ran = 1; seg.fx(); } continue; }
        var f = Math.min(1, (e - seg.t0) / (seg.t1 - seg.t0));
        if (seg.mv) { keep.forEach(function (o) { place(o, f); }); continue; }
        if (seg.o) { var g = ease(f); seg.o.p.style.strokeDashoffset = seg.o.L * (1 - g); pos = at(seg.o, seg.o.L * g); }
        else pos = { x: seg.a.x + (seg.b.x - seg.a.x) * f, y: seg.a.y + (seg.b.y - seg.a.y) * f };
      }
      pen.setAttribute('cx', pos.x); pen.setAttribute('cy', pos.y);
      if (e < END) { requestAnimationFrame(frame); return; }
      var last = at(paths[paths.length - 1], paths[paths.length - 1].L), b0 = null;
      ring.setAttribute('cx', last.x); ring.setAttribute('cy', last.y); tag.classList.add('on');
      (function burst(n2) {
        if (done || choosing) return;
        if (b0 == null) b0 = n2;
        var f2 = Math.min(1, (n2 - b0) / 420);
        ring.setAttribute('r', 3 + 18 * f2); ring.setAttribute('opacity', 1 - f2); pen.setAttribute('r', 4.5 * (1 - f2));
        if (f2 < 1) requestAnimationFrame(burst);
      })(now);
      setTimeout(finish, CHOOSE ? 450 : 950);
    }
    requestAnimationFrame(frame);
    setTimeout(finish, END + 3000);   // never block the app, even if animation frames stall
  }

  var wtab = document.querySelector('[data-tab="written"]');
  if (wtab && !WT.length) wtab.hidden = true;   // no written questions yet: no Written tab
  var qtab = document.querySelector('[data-tab="qbank"]');
  if (qtab && (WRITTEN || ONLY_EXAM)) qtab.hidden = true;
  var otab = document.querySelector('[data-tab="ospe"]');
  if (otab && !OCAT.length) otab.hidden = true;
  pushReminders();
  if (!ONLY_EXAM) splash();   // its "subjects · lectures" line means nothing without the lectures
  render(true);
})();
