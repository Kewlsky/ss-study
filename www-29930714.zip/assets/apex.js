/* Quick navigation (Omega): the ⌘ Navigate button or Ctrl+K opens a search of every section; Enter opens the top match.
   Names match the sidebar, with a few extra words each, so "lab", "3d", "coins" or "updates" all find something. */
(function () {
  var d = document.createElement('dialog');
  d.className = 'apex-dialog';
  d.innerHTML = '<div class="sechead"><h2>Quick navigation</h2><button class="btn ghost" id="apex-close" type="button">Close</button></div>' +
    '<input type="search" placeholder="Find a section…" aria-label="Find a section"><div class="apex-links"></div>';
  document.body.appendChild(d);
  var input = d.querySelector('input'), list = d.querySelector('.apex-links');
  var items = [['Study', 'tab', 'study', 'home overview lectures subjects continue'], ['Exams', 'tab', 'exam', 'mock ebe ospe test'], ['Question bank', 'tab', 'qbank', 'q bank mcq practice levels'],
    ['OSPE', 'tab', 'ospe', 'pictures spotters prelabs'], ['Written questions', 'tab', 'written', 'test me essay'], ['Labs · Physiology studio', 'nav', 'labs', 'lab vision hearing retina cochlea eye drugs glaucoma experiments'],
    ['Medical studio', 'nav', 'medical', '3d anatomy model glb histology microscopy visual fields'], ['Specimen studio', 'nav', 'specimen', 'images compare slides zoom'],
    ['Shop', 'nav', 'shop', 'item shop store star orbs coins bundles loadout themes cosmetics'], ['Profile', 'nav', 'profile', 'level xp medals avatar name link devices'], ['Release center', 'nav', 'updates', 'updates whats new version changelog']];
  function target(i) { return document.querySelector('.snav [data-' + i[1] + '="' + i[2] + '"]'); }
  function filter() {
    var q = input.value.trim().toLowerCase();
    list.replaceChildren();
    var rank = function (i) {   // the best match first: the name starting with it, the name containing it, a keyword starting with it, then the rest
      var n = i[0].toLowerCase();
      return !q ? 0 : n.indexOf(q) === 0 ? 0 : n.indexOf(q) > 0 ? 1 : (' ' + i[3]).indexOf(' ' + q) >= 0 ? 2 : 3;
    };
    items.filter(function (i) { var t = target(i); return t && !t.hidden && (i[0] + ' ' + i[3]).toLowerCase().indexOf(q) >= 0; })
      .map(function (i, k) { return [rank(i), k, i]; }).sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; }).map(function (x) { return x[2]; }).forEach(function (i) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = i[0] + '  →';
      b.onclick = function () { d.close(); var t = target(i); if (t) t.click(); };
      list.appendChild(b);
    });
    if (!list.children.length) { var p = document.createElement('p'); p.className = 'xhint'; p.textContent = 'Nothing matches “' + input.value + '”.'; list.appendChild(p); }
  }
  function open() { if (d.open) return; input.value = ''; filter(); d.showModal(); input.focus(); }
  input.oninput = filter;
  input.onkeydown = function (e) { if (e.key === 'Enter') { var b = list.querySelector('button'); if (b) { e.preventDefault(); b.click(); } } };
  d.querySelector('#apex-close').onclick = function () { d.close(); };
  d.addEventListener('click', function (e) {   // a tap outside the box (on the dimmed page) closes it
    var r = d.getBoundingClientRect();
    if (e.target === d && (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom)) d.close();
  });
  document.getElementById('apex-command').onclick = open;
  document.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(); } });
})();
