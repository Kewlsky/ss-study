/* The ≡ menu on phones (below 900 px wide, where the sidebar is hidden): the sidebar slides out as a drawer.
   Opening, the button's three lines stretch out and become the drawer (one third each), then its sections come in.
   Closing (✕, a tap outside, a swipe to the left, Esc or the phone's back button) runs it backwards: the drawer folds
   back into the three lines. Picking a section closes it too. */
(function () {
  'use strict';
  var btn = document.getElementById('menu-btn'), side = document.getElementById('side');
  if (!btn || !side) return;
  var open = false, busy = 0, reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var scrim = document.createElement('div');
  scrim.className = 'side-scrim'; scrim.setAttribute('aria-hidden', 'true');
  document.body.appendChild(scrim);
  var strips = document.createElement('div');
  strips.className = 'side-strips'; strips.setAttribute('aria-hidden', 'true');
  strips.innerHTML = '<i></i><i></i><i></i>';
  side.insertBefore(strips, side.firstChild);
  var x = document.createElement('button');
  x.type = 'button'; x.className = 'side-x'; x.setAttribute('aria-label', 'Close the menu');
  x.innerHTML = '<i></i><i></i>';
  side.insertBefore(x, strips.nextSibling);
  var lines = btn.querySelectorAll('i'), bars = strips.querySelectorAll('i');
  function wide() { return window.matchMedia && matchMedia('(min-width: 900px)').matches; }
  function flip(i) {   // the transform that puts strip i exactly over line i of the button
    var L = lines[i].getBoundingClientRect(), S = bars[i].getBoundingClientRect();
    if (!S.width || !S.height) return 'none';
    return 'translate(' + (L.left - S.left).toFixed(1) + 'px,' + (L.top - S.top).toFixed(1) + 'px) scale(' + (L.width / S.width).toFixed(4) + ',' + (L.height / S.height).toFixed(4) + ')';
  }
  function stagger() {   // the drawer's sections come in one after another
    var k = 0;
    Array.prototype.forEach.call(side.querySelectorAll('.side-logo, .snav > *, .side-box'), function (el) { el.style.setProperty('--di', k++); });
  }
  function show() {
    if (open || wide()) return;
    open = true; clearTimeout(busy);
    stagger();
    document.body.classList.add('nav-open');
    side.classList.remove('closing'); side.classList.add('drawer');
    btn.setAttribute('aria-expanded', 'true');
    if (!reduce && bars[0].animate) {
      for (var i = 0; i < 3; i++) {
        bars[i].animate([{ transform: flip(i), borderRadius: '4px' }, { transform: 'none', borderRadius: '0px' }],
          { duration: 460, delay: i * 55, easing: 'cubic-bezier(.22, .9, .25, 1)', fill: 'backwards' });
      }
    }
    side.classList.add('open');
    setTimeout(function () { var f = side.querySelector('.snav button.on') || x; try { f.focus({ preventScroll: true }); } catch (e) {} }, reduce ? 0 : 420);
  }
  function hide() {
    if (!open) return;
    open = false;
    side.classList.remove('open'); side.classList.add('closing');
    btn.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('nav-open');
    var t = reduce ? 0 : 520;
    if (!reduce && bars[0].animate) {
      for (var i = 0; i < 3; i++) {
        bars[i].animate([{ transform: 'none', borderRadius: '0px' }, { transform: flip(i), borderRadius: '4px' }],
          { duration: 380, delay: 120 + (2 - i) * 45, easing: 'cubic-bezier(.55, 0, .75, .2)', fill: 'forwards' });
      }
    }
    busy = setTimeout(function () {
      side.classList.remove('drawer', 'closing');
      Array.prototype.forEach.call(bars, function (b) { if (b.getAnimations) b.getAnimations().forEach(function (a) { a.cancel(); }); });
    }, t);
    try { btn.focus({ preventScroll: true }); } catch (e) {}
  }
  btn.addEventListener('click', function () { if (open) hide(); else show(); });
  x.addEventListener('click', hide);
  scrim.addEventListener('click', hide);
  side.addEventListener('click', function (e) {   // a section was picked: let the app open it, then fold the drawer away
    if (open && e.target.closest && e.target.closest('.snav button, .side-box button, .side-box a')) setTimeout(hide, 60);
  });
  document.addEventListener('keydown', function (e) { if (open && e.key === 'Escape') hide(); });
  var sx = 0, sy = 0;
  side.addEventListener('touchstart', function (e) { if (open) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; } }, { passive: true });
  side.addEventListener('touchend', function (e) {
    if (!open) return;
    var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
    if (dx < -60 && Math.abs(dx) > Math.abs(dy) * 1.4) hide();
  }, { passive: true });
  window.addEventListener('resize', function () { if (open && wide()) hide(); });
  var hb = window.hubBack;   // the phone's back button closes the drawer before anything else
  window.hubBack = function () { if (open) { hide(); return 'handled'; } return hb ? hb() : 'exit'; };
})();
