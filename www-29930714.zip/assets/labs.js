/* The Labs page: the interactive senses labs from senselabs.js (vision, hearing, eye drugs), in grouped tabs
   (Physiology, Pharmacology). The last lab you opened opens again; leaving the page stops any animation.
   (Omega's five quick experiments were taken out on request.) Offline educational models, not clinical measurements. */
window.UXLabs=(function(){
let last=0,stop=()=>{};
function mount(root){
  const all=(window.SenseLabs&&SenseLabs.list)||[];
  let groups=[],tabs='';all.forEach((l,i)=>{if(groups.indexOf(l.g)<0){groups.push(l.g);tabs+=`<span class="ux-labgroup">${l.g}</span>`;}tabs+=`<button class="ux-labtab" data-lab="${i}">${l.n}</button>`;});
  root.innerHTML=`<section class="screen ux-labs"><div class="hello"><span class="ux-kicker">EXPERIMENT / OBSERVE / UNDERSTAND</span><h1>Labs.</h1><p>See how vision, hearing and the eye drugs work: change something and watch the mechanism respond. Built from your lectures; everything runs offline.</p></div><div class="ux-labtabs">${tabs}</div><div id="ux-experiment"></div></section>`;
  let exp=root.querySelector('#ux-experiment');
  if(!all.length){exp.innerHTML='<p class="xhint">The labs could not load. Close the app and open it again.</p>';return;}
  function select(i){
    stop();stop=()=>{};last=i;
    root.querySelectorAll('[data-lab]').forEach((b,j)=>b.setAttribute('aria-pressed',String(j===i)));
    exp.innerHTML='';const box=document.createElement('div');exp.appendChild(box);stop=all[i].mount(box)||(()=>{});   // a fresh box each time: the last lab's listeners go with its box
  }
  root.querySelectorAll('[data-lab]').forEach(b=>b.onclick=()=>select(+b.dataset.lab));
  select(Math.min(last,all.length-1));
}
return {mount,cleanup:()=>{stop();stop=()=>{};}};})();
