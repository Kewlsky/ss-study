/* Interactive labs for the special senses module, built on the lectures in content/:
   How vision works (physio 01 Vision), How hearing works (physio 02 Hearing + 04 hearing prelab) and Eye drugs
   (pharma 01 Drugs affecting the eye). Each lab draws an SVG model you change with sliders and buttons; the numbers are
   the lectures' own (lens 20 D at rest, 14 D of accommodation in children; dB = 20 log P/Pref; IOP 15-25 mm Hg ...).
   They are teaching models, not clinical simulators. window.SenseLabs.list = [{n, g, mount(host) -> cleanup}] */
(function () {
  'use strict';
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function interp(tab, x) {   // [[x, y], ...] sorted by x
    if (x <= tab[0][0]) return tab[0][1];
    for (var i = 1; i < tab.length; i++) if (x <= tab[i][0]) { var a = tab[i - 1], b = tab[i]; return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]); }
    return tab[tab.length - 1][1];
  }
  function head(tag, title, desc) { return '<div class="ux-labhead"><span class="ux-kicker">' + tag + '</span><h2>' + title + '</h2><p>' + desc + '</p></div>'; }
  function slider(k, label, min, max, val, step) {
    return '<label>' + label + ' <output data-o="' + k + '"></output><input type="range" data-k="' + k + '" min="' + min + '" max="' + max + '" value="' + val + '" step="' + (step || 1) + '" aria-label="' + esc(label) + '"></label>';
  }
  function seg(k, label, opts, on) {
    return '<div class="sl-field"><span class="sl-flabel">' + label + '</span><div class="sl-seg" role="group" aria-label="' + esc(label) + '">' + opts.map(function (o) {
      return '<button type="button" data-seg="' + k + '" data-v="' + o[0] + '" aria-pressed="' + (String(o[0]) === String(on)) + '">' + o[1] + '</button>';
    }).join('') + '</div></div>';
  }
  function tog(k, label) { return '<label class="sl-tog"><input type="checkbox" data-k="' + k + '"> ' + label + '</label>'; }
  function steps(list) { return '<ol class="sl-steps">' + list.map(function (s) { return '<li data-step="' + s[0] + '"><b>' + s[1] + '</b><span>' + s[2] + '</span></li>'; }).join('') + '</ol>'; }
  function readouts(rows) { return rows.map(function (r) { return '<div' + (r[2] ? ' class="' + r[2] + '"' : '') + '><small>' + r[0] + '</small><strong>' + r[1] + '</strong></div>'; }).join(''); }
  function bind(host, st, draw) {   // sliders, toggles and segmented buttons write into st, then redraw
    host.addEventListener('input', function (e) { var k = e.target.getAttribute('data-k'); if (!k) return; st[k] = e.target.type === 'checkbox' ? e.target.checked : +e.target.value; draw(); });
    host.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-seg]'); if (!b) return;
      var k = b.getAttribute('data-seg'), v = b.getAttribute('data-v'); st[k] = isNaN(+v) ? v : +v;
      Array.prototype.forEach.call(host.querySelectorAll('[data-seg="' + k + '"]'), function (x) { x.setAttribute('aria-pressed', x === b); });
      draw();
    });
  }
  function setVal(host, k, v) { var i = host.querySelector('[data-k="' + k + '"]'); if (i) { if (i.type === 'checkbox') i.checked = !!v; else i.value = v; } }
  function out(host, k, txt) { var o = host.querySelector('[data-o="' + k + '"]'); if (o) o.textContent = txt; }
  function lightSteps(host, on) { Array.prototype.forEach.call(host.querySelectorAll('[data-step]'), function (li) { var s = on[li.getAttribute('data-step')]; li.className = s || ''; }); }

  /* ================================ HOW VISION WORKS ================================ */
  var AMAX = [[8, 14], [20, 10], [30, 7.5], [40, 5], [45, 3.5], [50, 2], [55, 1.25], [60, 1], [70, 0.75]];   // accommodation (D) by age: 14 D in children (lecture)
  function vision(host) {
    var st = { dist: 100, light: 60, age: 20, eye: 0, glasses: false, reading: false }, VM = {}, W = null;
    host.innerHTML = head('PHYSIOLOGY / VISION', 'How vision works', 'Move the object near and far, dim the light, change the eye and its age. Watch the pupil, the lens and the ciliary muscle respond, and where the light comes to a focus.') +
      '<div class="ux-labgrid"><div class="ux-scope"><span class="ux-kicker">LIVE MODEL · THE EYE FROM THE SIDE</span><svg class="sl-svg" viewBox="0 0 640 330" role="img" aria-label="The eye: light rays from the object focus on the retina"></svg><div class="ux-readouts sl-ro"></div><p class="sl-verdict"></p>' + walksHtml(WALKS.vision) + GUIDE_HTML + '</div>' +
      '<div class="ux-controls"><h3>Experiment controls</h3>' +
      '<div class="sl-presets"><button type="button" class="btn ghost" data-pre="far">Look far</button><button type="button" class="btn ghost" data-pre="read">Read a book</button><button type="button" class="btn ghost" data-pre="dark">Dark room</button></div>' +
      slider('dist', 'Object distance', 0, 100, st.dist) + slider('light', 'Light', 0, 100, st.light) + slider('age', 'Age', 8, 70, st.age) +
      seg('eye', 'The eye', [[0, 'Normal'], [-3, 'Myopia −3 D'], [2, 'Hyperopia +2 D']], 0) +
      '<div class="sl-toggles">' + tog('glasses', 'Distance glasses') + tog('reading', 'Reading glasses +2.5 D') + '</div>' +
      '<p class="ux-modelnote">Lens = 20 D at rest; the ciliary muscle (parasympathetic) can add up to about 14 D in children, less with age. Glasses for distance correct the error: concave for myopia, convex for hyperopia.</p></div></div>' +
      '<h3 class="sl-h">The path of light, step by step</h3>' + steps([
        ['cornea', 'Cornea', 'Air → cornea is the strongest of the four refracting interfaces (cornea 1.38).'],
        ['pupil', 'Pupil', 'Bright light: parasympathetic → constrictor (circular) muscle → small pupil. Dim: sympathetic → dilator (radial) → wide pupil.'],
        ['lens', 'Lens and accommodation', '20 D at rest. For near objects the ciliary muscle contracts (parasympathetic, CN III), the lens grows more convex: up to 34 D in children.'],
        ['near', 'The near response: 3 Cs', 'Convergence (medial recti) + Constriction of the pupil + Curvature of the lens: Edinger-Westphal → ciliary ganglion → short ciliary nerves.'],
        ['retina', 'Retina', 'The image falls inverted on the retina; on the fovea cones give colour and acuity (nearly 1:1 with ganglion cells). Light hyperpolarises the photoreceptors.'],
        ['path', 'To the brain', 'Optic nerve → optic chiasma → optic tract → lateral geniculate body → optic radiation → visual cortex (area 17).']
      ]);
    var svg = host.querySelector('svg');
    function draw() {
      var D = 0.1 * Math.pow(60, st.dist / 100);   // 10 cm … 6 m
      var Amax = interp(AMAX, st.age), R = st.eye, G = st.glasses ? R : 0, add = st.reading ? 2.5 : 0;
      var N = 1 / D + R - G - add, A = clamp(N, 0, Amax), def = N - A;   // def > 0: not enough power (focus behind); < 0: too much (in front)
      var near = D < 1, pupil = clamp(8 - 6 * st.light / 100 - (near ? 0.8 : 0), 2, 8);
      VM = { d: byId('none'), cond: 'healthy', T: 1, U: 1, P: 1, iop: 15, light: 1, cornea: 1, acc: 'normal', pupil: pupil, lux: st.light };   // what the walks read
      out(host, 'dist', D >= 5.9 ? '6 m (far)' : D >= 1 ? D.toFixed(1) + ' m' : Math.round(D * 100) + ' cm');
      out(host, 'light', st.light < 25 ? 'Dim' : st.light > 75 ? 'Bright' : 'Daylight');
      out(host, 'age', st.age + ' years');
      // ---- the drawing ----
      var cy = 165, ox = 30 + (1 - st.dist / 100) * 140, oh = 42, pr = pupil * 4, lrx = 11 + A * 1.15, lry = 47 - A * 0.55;
      var fx = 560 + clamp(def * 15, -110, 120), fy = cy + oh * 0.42, contracted = A > 0.25;
      var sky = Math.round(10 + st.light * 0.5);
      var h = '<defs><filter id="sl-blur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="' + Math.min(6, Math.abs(def) * 1.6).toFixed(2) + '"/></filter>' +
        '<radialGradient id="sl-sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6c8" stop-opacity="' + (st.light / 100).toFixed(2) + '"/><stop offset="1" stop-color="#fff6c8" stop-opacity="0"/></radialGradient></defs>' +
        '<rect width="640" height="330" fill="rgb(' + sky + ',' + (sky + 8) + ',' + (sky + 26) + ')"/><circle cx="60" cy="40" r="70" fill="url(#sl-sun)"/>';
      // the object (an upright arrow) and its distance
      h += '<g class="sl-obj"><path d="M' + ox + ' ' + cy + 'V' + (cy - oh) + '" stroke="#ffd36e" stroke-width="5" stroke-linecap="round"/><path d="M' + (ox - 9) + ' ' + (cy - oh + 11) + 'L' + ox + ' ' + (cy - oh - 3) + 'L' + (ox + 9) + ' ' + (cy - oh + 11) + '" fill="none" stroke="#ffd36e" stroke-width="4" stroke-linejoin="round"/></g>';
      // glasses
      if (G || add) {
        var pw = -G + add, gx = 232;   // net lens power in front of the eye: + convex, − concave
        h += pw > 0 ? '<path d="M' + gx + ' 112 Q' + (gx + 14) + ' 165 ' + gx + ' 218 Q' + (gx - 14) + ' 165 ' + gx + ' 112Z" class="sl-glass"/>'
          : '<path d="M' + (gx - 8) + ' 112 L' + (gx + 8) + ' 112 Q' + (gx - 2) + ' 165 ' + (gx + 8) + ' 218 L' + (gx - 8) + ' 218 Q' + (gx + 2) + ' 165 ' + (gx - 8) + ' 112Z" class="sl-glass"/>';
        h += '<text x="' + gx + '" y="236" text-anchor="middle" class="sl-t">' + (pw > 0 ? 'convex' : 'concave') + ' ' + (pw > 0 ? '+' : '') + pw.toFixed(1) + ' D</text>';
      }
      // the eyeball, retina, optic nerve
      h += '<ellipse cx="420" cy="' + cy + '" rx="150" ry="130" class="sl-sclera"/><ellipse cx="420" cy="' + cy + '" rx="141" ry="121" class="sl-vitreous"/>';
      var ret = []; for (var t = -68; t <= 68; t += 4) { var a = t * Math.PI / 180; ret.push((420 + 141 * Math.cos(a)).toFixed(1) + ' ' + (cy + 121 * Math.sin(a)).toFixed(1)); }
      h += '<path d="M' + ret.join(' L') + '" class="sl-retina"/><circle cx="561" cy="' + cy + '" r="4" class="sl-fovea"/>';
      h += '<path d="M566 150 L640 136 L640 196 L566 180Z" class="sl-nerve"/>';
      // cornea and anterior chamber
      h += '<path d="M287 66 Q233 165 287 264" class="sl-cornea"/>';
      // ciliary body and zonules
      [-1, 1].forEach(function (s) {
        var y = cy + s * 74;
        h += '<ellipse cx="322" cy="' + y + '" rx="17" ry="10" class="sl-ciliary' + (contracted ? ' on' : '') + '"/>' +
          '<path d="M322 ' + (y - s * 9) + ' L322 ' + (cy + s * lry) + '" class="sl-zonule' + (contracted ? ' slack' : '') + '"/>';
      });
      // iris and pupil
      h += '<rect x="296" y="' + (cy - 82) + '" width="9" height="' + (82 - pr) + '" rx="3" class="sl-iris"/><rect x="296" y="' + (cy + pr) + '" width="9" height="' + (82 - pr) + '" rx="3" class="sl-iris"/>';
      // the lens
      h += '<ellipse cx="324" cy="' + cy + '" rx="' + lrx.toFixed(1) + '" ry="' + lry.toFixed(1) + '" class="sl-lens"/>';
      // rays: through the top and bottom of the pupil and through the lens centre, to the focus
      var tip = [ox, cy - oh], ends = [];
      [[301, cy - pr + 2], [324, cy], [301, cy + pr - 2]].forEach(function (p) {
        var dx = fx - p[0], dy = fy - p[1], k = (561 - p[0]) / dx, ry = p[1] + dy * k;   // where the ray meets the retina (x = 561)
        ends.push(ry);
        h += '<path d="M' + tip[0] + ' ' + tip[1] + ' L' + p[0] + ' ' + p[1] + ' L561 ' + ry.toFixed(1) + '" class="sl-ray"/>';
        if (fx > 561) h += '<path d="M561 ' + ry.toFixed(1) + ' L' + fx.toFixed(1) + ' ' + fy.toFixed(1) + '" class="sl-ray ghost"/>';
      });
      if (Math.abs(def) > 0.15) h += '<path d="M558 ' + Math.min(ends[0], ends[2]).toFixed(1) + ' L558 ' + Math.max(ends[0], ends[2]).toFixed(1) + '" class="sl-blurline"/>';
      h += '<circle cx="' + fx.toFixed(1) + '" cy="' + fy.toFixed(1) + '" r="4" class="sl-focus"/>';
      // the image on the retina: inverted, sharp or blurred
      h += '<g filter="url(#sl-blur)"><path d="M548 ' + cy + ' V' + (cy + oh * 0.42) + '" stroke="#ffd36e" stroke-width="3"/></g>';
      // labels
      h += '<text x="262" y="56" class="sl-t">Cornea</text>' + tl(300, cy - 92, 'Iris', 'light', '', 'middle') +
        tl(352, cy - 30, 'Lens ' + (20 + A).toFixed(1) + ' D', 'near') + '<text x="300" y="' + (cy + 105) + '" class="sl-t">Ciliary muscle' + (contracted ? ' · contracting' : ' · relaxed') + '</text>' +
        tl(566, cy - 64, 'Retina', 'photo') + '<text x="572" y="' + (cy + 4) + '" class="sl-t sl-small">fovea</text>' + tl(634, 128, 'Optic nerve', 'seeing', ' sl-small', 'end') +
        '<text x="' + ox + '" y="' + (cy + 22) + '" text-anchor="middle" class="sl-t">' + (D >= 5.9 ? '6 m' : D >= 1 ? D.toFixed(1) + ' m' : Math.round(D * 100) + ' cm') + '</text>';
      if (near) h += '<g class="sl-badge"><rect x="16" y="282" width="190" height="34" rx="10"/><text x="30" y="304">Near response: 3 Cs on</text></g>';
      svg.innerHTML = h;
      // ---- the readouts and the verdict ----
      var npD = Amax - R + G + add, np = npD > 0 ? 100 / npD : Infinity;
      var where = Math.abs(def) <= 0.25 ? 'Sharp on the fovea' : def < 0 ? 'Blurred: focus in front of the retina' : 'Blurred: focus behind the retina';
      host.querySelector('.sl-ro').innerHTML = readouts([
        ['Lens power', (20 + A).toFixed(1) + ' D'], ['Accommodation', A.toFixed(1) + ' / ' + Amax.toFixed(1) + ' D'], ['Pupil', pupil.toFixed(1) + ' mm'],
        ['Near point', np === Infinity ? '—' : np >= 100 ? (np / 100).toFixed(1) + ' m' : Math.round(np) + ' cm'], ['Image', Math.abs(def) <= 0.25 ? 'Sharp' : 'Blurred', Math.abs(def) <= 0.25 ? 'ok' : 'bad'],
        ['Error', R === 0 ? 'Emmetropia' : R < 0 ? 'Myopia' : 'Hyperopia']]);
      var why = Math.abs(def) <= 0.25 ? (A > 0.25 ? 'The ciliary muscle has rounded the lens by ' + A.toFixed(1) + ' D, so the near object focuses on the fovea.' : 'At rest the lens and cornea bring the image to a sharp focus on the fovea.')
        : def < 0 ? (R < 0 && !st.glasses ? 'Myopia: the eye is too strong for far objects, so the focus falls in front of the retina. A concave lens (distance glasses) spreads the rays and pushes the focus back.' : 'Too much power for this distance: the focus falls in front of the retina.')
        : (Amax < N ? (st.age >= 45 && N - (R - G) > 0.5 ? 'Presbyopia: at ' + st.age + ' the lens can add only ' + Amax.toFixed(1) + ' D, not the ' + N.toFixed(1) + ' D needed, so the focus falls behind the retina. Reading glasses (convex) help.' : 'Hyperopia: even full accommodation (' + Amax.toFixed(1) + ' D) is not enough, so the focus falls behind the retina. A convex lens brings it forward.') : 'The focus falls behind the retina.');
      host.querySelector('.sl-verdict').innerHTML = '<b>' + where + '.</b> ' + why;
      lightSteps(host, { cornea: 'on', pupil: st.light > 75 || st.light < 25 || near ? 'on' : '', lens: A > 0.25 ? 'on' : '', near: near ? 'on' : '', retina: Math.abs(def) <= 0.25 ? 'on' : 'warn', path: 'on' });
      if (W) W.refresh();
    }
    W = walker(host, function () { return VM; });
    bind(host, st, draw);
    host.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-pre]'); if (!b) return;
      var p = b.getAttribute('data-pre');
      if (p === 'far') { st.dist = 100; st.light = 60; } else if (p === 'read') { st.dist = 26; st.light = 70; } else { st.light = 5; }
      setVal(host, 'dist', st.dist); setVal(host, 'light', st.light); draw();
    });
    draw();
    return function () { W.stop(); };
  }

  /* ================================ HOW HEARING WORKS ================================ */
  var DBEX = [[0, 'absolute threshold'], [20, 'faint whisper'], [40, 'quiet office'], [60, 'conversation'], [80, 'city bus'], [100, 'subway train'], [120, 'loud thunder'], [140, 'pain and damage']];
  function hearing(host) {
    var st = { f: 50, db: 60, cond: 'normal' }, raf = 0, alive = true, t0 = performance.now(), HM = {}, W = null;
    host.innerHTML = head('PHYSIOLOGY / HEARING', 'How hearing works', 'Play a tone and follow it: the drum and ossicles push it into the cochlea, a travelling wave peaks at its own place on the basilar membrane, the hair cells there fire the cochlear nerve. Then try a deaf ear.') +
      '<div class="ux-labgrid"><div class="ux-scope"><span class="ux-kicker">LIVE MODEL · THE EAR, WITH THE COCHLEA UNROLLED</span><svg class="sl-svg" viewBox="0 0 640 300" role="img" aria-label="The ear: sound travels to the cochlea"></svg><div class="ux-readouts sl-ro"></div><p class="sl-verdict"></p>' + walksHtml(WALKS.hearing) + GUIDE_HTML + '</div>' +
      '<div class="ux-controls"><h3>Experiment controls</h3>' +
      '<div class="sl-presets"><button type="button" class="btn ghost" data-pre="talk">Conversation</button><button type="button" class="btn ghost" data-pre="high">High whistle</button><button type="button" class="btn ghost" data-pre="low">Low hum</button></div>' +
      slider('f', 'Pitch (frequency)', 0, 100, st.f) + slider('db', 'Loudness (intensity)', 0, 140, st.db, 5) +
      seg('cond', 'The left ear', [['normal', 'Normal'], ['cond', 'Conductive deafness'], ['sn', 'Sensorineural deafness']], 'normal') +
      '<p class="ux-modelnote">dB = 20 log (P / Pref), Pref = 0.0002 dyne/cm² at 1,000 Hz: ×10 pressure = +20 dB. We hear about 20–16,000 Hz, best at 1,000–4,000 Hz.</p></div></div>' +
      '<h3 class="sl-h">Tuning-fork tests for this ear</h3><div class="sl-forks"></div>' +
      '<h3 class="sl-h">From sound to signal, step by step</h3>' + steps([
        ['outer', 'Pinna and external meatus', 'Collect the sound and direct it to the drum. Air filled.'],
        ['drum', 'Tympanic membrane and ossicles', 'Impedance matching: the large drum on the small oval window, plus the lever of malleus, incus and stapes, turn air waves into fluid pressure waves.'],
        ['oval', 'Oval window and scalae', 'The stapes footplate pushes the oval window: waves run in the perilymph (scala vestibuli → helicotrema → scala tympani → round window).'],
        ['place', 'The basilar membrane: place principle', 'Narrow, stiff base near the oval window vibrates to high notes; the wide, flexible apex near the helicotrema to low notes.'],
        ['hair', 'Hair cells', 'Cilia bend against the tectorial membrane: one way K⁺ conductance rises → depolarisation (the other way hyperpolarisation) = the cochlear microphonic. Ca²⁺ enters → glutamate.'],
        ['nerve', 'Cochlear nerve and brain', 'Action potentials in the cochlear nerve. Loudness = faster firing + more fibres. Location = time lag and intensity difference between the ears (cortex, medial geniculate body).']
      ]);
    var svg = host.querySelector('svg'), state = {};
    function freq() { return 20 * Math.pow(1000, st.f / 100); }
    function thr(f) {   // a normal audiogram (dB): 0 at 1-4 kHz, rising at both ends; nothing above 16 kHz (the prelab's upper limit)
      if (f > 16000) return 200;
      if (f < 1000) return 75 * Math.pow(Math.log10(1000 / f) / Math.log10(50), 1.6);
      if (f > 4000) return 60 * Math.pow(Math.log10(f / 4000) / Math.log10(4), 2);
      return 0;
    }
    function draw() {
      var f = freq(), T = thr(f), loss = st.cond === 'cond' ? 35 : st.cond === 'sn' ? 25 + 30 * clamp(Math.log10(f / 1000) / Math.log10(8), 0, 1) : 0;
      var eff = st.db - T - loss, ex = DBEX[Math.round(clamp(st.db, 0, 140) / 20)];
      out(host, 'f', f >= 1000 ? (f / 1000).toFixed(f >= 10000 ? 0 : 1) + ' kHz' : Math.round(f) + ' Hz');
      out(host, 'db', st.db + ' dB · ' + ex[1]);
      var p = 1 - (Math.log10(f) - Math.log10(20)) / 3, xp = 236 + p * 362;   // 0 = base (20 kHz) … 1 = apex (20 Hz)
      state = { xp: xp, amp: clamp(eff, 0, 80) / 80 * 26 + (eff > 0 ? 4 : 0), width: 26 + p * 46, f: f, eff: eff, sn: st.cond === 'sn', cond: st.cond === 'cond' };
      var h = '<rect width="640" height="300" fill="#0d1422"/>' +
        // the sound and the outer ear
        '<g class="sl-speaker"><rect x="10" y="132" width="14" height="26" rx="3"/><path d="M24 132 L40 118 L40 172 L24 158Z"/></g>' +
        (st.db > 0 ? '<g class="sl-waves" style="--dur:' + clamp(2.4 - Math.log10(f) * 0.5, 0.5, 2).toFixed(2) + 's"><path d="M50 128 Q60 145 50 162"/><path d="M60 120 Q74 145 60 170"/><path d="M70 112 Q88 145 70 178"/></g>' : '') +
        '<path d="M96 96 C76 100 76 136 92 140 C80 152 84 188 104 192" class="sl-pinna"/><rect x="96" y="134" width="56" height="22" rx="4" class="sl-canal' + (state.cond ? ' blocked' : '') + '"/>' +
        // middle ear: drum and ossicles
        '<rect x="152" y="92" width="64" height="112" rx="14" class="sl-middle"/>' +
        '<ellipse cx="154" cy="145" rx="4" ry="28" class="sl-drum vib" style="--dur:' + clamp(0.9 - Math.log10(f) * 0.15, 0.12, 0.6).toFixed(2) + 's;--amp:' + clamp(st.db / 140, 0.1, 1).toFixed(2) + '"/>' +
        '<g class="sl-oss vib2' + (state.cond ? ' stiff' : '') + '" style="--dur:' + clamp(0.9 - Math.log10(f) * 0.15, 0.12, 0.6).toFixed(2) + 's"><path d="M158 128 L176 120 L184 132" class="sl-bone"/><path d="M184 132 L196 140 L190 150" class="sl-bone"/><path d="M190 150 L204 150 M204 140 L204 160" class="sl-bone"/></g>' +
        '<text x="184" y="86" text-anchor="middle" class="sl-t">Middle ear (air)</text>' + tl(122, 224, 'Drum', 'sound', '', 'middle') + tl(188, 224, 'Ossicles', 'sound', '', 'middle') +
        // inner ear: the cochlea unrolled
        '<ellipse cx="220" cy="150" rx="4" ry="9" class="sl-window"/><ellipse cx="220" cy="186" rx="4" ry="7" class="sl-window"/>' +
        '<rect x="226" y="104" width="382" height="94" rx="20" class="sl-cochlea"/><path d="M236 151 L598 147 L598 155 L236 152Z" class="sl-bm"/>' +
        '<text x="236" y="98" class="sl-t">Base: narrow, stiff · high notes</text><text x="598" y="98" text-anchor="end" class="sl-t">Apex: wide, flexible · low notes</text>' +
        '<text x="240" y="124" class="sl-t sl-small">scala vestibuli (perilymph)</text><text x="240" y="190" class="sl-t sl-small">scala tympani (perilymph)</text><text x="604" y="190" text-anchor="end" class="sl-t sl-small">helicotrema</text>' +
        '<path id="sl-wave" class="sl-tw" d=""/>';
      // hair cells along the membrane (the first stretch lost in sensorineural deafness)
      for (var i = 0; i < 26; i++) {
        var x = 240 + i * 14, near = Math.abs(x - xp) < state.width * 0.8, dead = state.sn && x < 330, lit = near && eff > 0 && !dead;
        h += '<circle cx="' + x + '" cy="143" r="3.4" class="sl-hc' + (lit ? ' lit' : '') + (dead ? ' dead' : '') + '"/>';
      }
      // the nerve
      var rate = clamp(Math.round(eff * 3), 0, 300);
      h += '<path d="M' + xp.toFixed(1) + ' 160 Q' + xp.toFixed(1) + ' 235 320 268 L620 268" class="sl-cn' + (rate ? ' firing' : '') + '" style="--dur:' + (rate ? clamp(60 / rate, 0.15, 2).toFixed(2) : 2) + 's"/>' +
        tl(620, 288, 'Cochlear nerve → brainstem → medial geniculate body → auditory cortex', 'audpath', '', 'end');
      svg.innerHTML = h;
      // readouts and verdict
      var place = p < 0.3 ? 'Base (near the oval window)' : p > 0.7 ? 'Apex (near the helicotrema)' : 'Middle of the membrane';
      HM = { d: { name: '' }, cond: st.cond, f: f, eff: eff, db: st.db, p: p, place: p < 0.3 ? 'at the base (near the oval window)' : p > 0.7 ? 'at the apex (near the helicotrema)' : 'in the middle of the membrane' };   // what the walks read
      host.querySelector('.sl-ro').innerHTML = readouts([
        ['Pressure', '×' + Math.round(Math.pow(10, st.db / 20)).toLocaleString() + ' threshold'], ['Peak on the membrane', place], ['Hair cells', eff > 0 ? 'K⁺ in → depolarise' : 'Barely bent'],
        ['Nerve firing', rate ? rate + ' /s (model)' : 'Resting'], ['Heard?', st.db >= 140 ? 'Pain' : eff > 10 ? 'Yes' : eff > 0 ? 'Faintly' : 'No', st.db >= 140 ? 'bad' : eff > 0 ? 'ok' : 'bad'], ['Threshold here', Math.round(T + loss) + ' dB']]);
      host.querySelector('.sl-verdict').innerHTML = f > 16000 ? '<b>Above the range of hearing.</b> We hear about 20–16,000 Hz, and the upper limit falls with age.'
        : st.cond === 'cond' && eff <= 0 && st.db - T > 0 ? '<b>Lost on the way in.</b> In conductive deafness (wax, a perforated drum, stiff ossicles) air conduction falls but the cochlea is fine: bone conduction is normal.'
        : st.cond === 'sn' && eff <= 0 && st.db - T > 0 ? '<b>The cochlea cannot answer.</b> In sensorineural deafness the hair cells or the auditory pathway are damaged: air and bone conduction both fall, often worst for high notes.'
        : eff > 0 ? '<b>Heard.</b> The wave peaks at the ' + place.toLowerCase() + '; louder sounds make each fibre fire faster and recruit more fibres.'
        : '<b>Too quiet to hear</b> at this pitch: the threshold here is ' + Math.round(T + loss) + ' dB.';
      // tuning forks (hearing prelab, slides 14-15)
      var forks = st.cond === 'cond' ? [['Weber', 'Louder in the LEFT (diseased) ear', 'no masking noise there'], ['Rinne (left)', 'Negative: BC > AC', 'not heard in air after bone is over'], ['Schwabach', 'Lengthened', 'bone conduction better than normal']]
        : st.cond === 'sn' ? [['Weber', 'Louder in the RIGHT (normal) ear', 'the healthy ear wins'], ['Rinne (left)', 'Positive: AC > BC', 'if the deafness is partial'], ['Schwabach', 'Shortened', 'bone conduction worse than normal']]
        : [['Weber', 'Equal on both sides', 'heard in the middle'], ['Rinne', 'Positive: AC > BC', 'still heard in air after bone is over'], ['Schwabach', 'Normal', 'same as the examiner']];
      host.querySelector('.sl-forks').innerHTML = forks.map(function (x) { return '<div class="sl-fork"><small>' + x[0] + '</small><b>' + x[1] + '</b><span>' + x[2] + '</span></div>'; }).join('') +
        '<p class="sl-hook">' + (st.cond === 'cond' ? 'Conductive = everything points to the SICK ear.' : st.cond === 'sn' ? 'Sensorineural = the HEALTHY ear wins. A positive Rinne does not mean normal.' : 'Normal: air beats bone (AC > BC).') + '</p>';
      lightSteps(host, { outer: st.cond === 'cond' ? 'warn' : 'on', drum: st.cond === 'cond' ? 'warn' : 'on', oval: st.cond === 'cond' ? 'warn' : 'on', place: 'on', hair: st.cond === 'sn' ? 'warn' : eff > 0 ? 'on' : '', nerve: st.cond === 'sn' ? 'warn' : eff > 0 ? 'on' : '' });
      if (W) W.refresh();
    }
    function wave(now) {   // the travelling wave: an envelope peaking at its place, moving from base to apex
      if (!alive || !host.isConnected) { alive = false; return; }
      var w = svg.querySelector('#sl-wave'), s = state, t = (now - t0) / 1000, pts = [];
      if (w) {
        for (var x = 236; x <= 598; x += 3) {
          var env = s.amp * Math.exp(-Math.pow((x - s.xp) / s.width, 2)) * (x < s.xp ? 1 : Math.exp(-(x - s.xp) / 18));
          pts.push(x + ' ' + (151 + env * Math.sin((x - 236) / 9 - t * 7)).toFixed(1));
        }
        w.setAttribute('d', 'M' + pts.join(' L'));
      }
      raf = requestAnimationFrame(wave);
    }
    W = walker(host, function () { return HM; });
    bind(host, st, draw);
    host.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-pre]'); if (!b) return;
      var p = b.getAttribute('data-pre');
      if (p === 'talk') { st.f = 52; st.db = 60; } else if (p === 'high') { st.f = 85; st.db = 70; } else { st.f = 18; st.db = 70; }
      setVal(host, 'f', st.f); setVal(host, 'db', st.db); draw();
    });
    draw();
    if (!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) raf = requestAnimationFrame(wave); else wave(t0);
    return function () { alive = false; cancelAnimationFrame(raf); W.stop(); };
  }

  /* ================================ EYE DRUGS ================================ */
  // From "Drugs affecting the eye" (p.123-131). pupil mm; light/cornea reflex 1 present, 0 absent; acc: near (ciliary spasm),
  // normal, cyclo (cycloplegia), weak (weak cycloplegia); P aqueous formation, T trabecular (conventional) outflow,
  // U uveoscleral outflow, osm osmotic pull; tgt: sph constrictor pupillae, dil dilator, cm ciliary muscle, epi ciliary
  // epithelium, uveo uveoscleral route, trab trabeculum, cns brain, blood plasma; ca/oa: closed / open angle (ok, no, '').
  var DRUGS = [
    { id: 'none', name: 'No drug', grp: 'Baseline', cls: 'The eye as it is', pupil: 4, tgt: [], mech: 'Constrictor pupillae (M3, parasympathetic) is dominant over the dilator (α1, sympathetic). The ciliary epithelium makes aqueous (mainly β2); 90% drains through the trabeculum and Schlemm\'s canal, 10% by the uveoscleral route.' },
    { id: 'pilo', name: 'Pilocarpine', grp: 'Miotics', cls: 'Parasympathomimetic, direct (cholinomimetic alkaloid) · 1–4%', pupil: 1.8, acc: 'near', T: 1.7, Tc: 3, hyper: 0.5, tgt: ['sph', 'cm'], ca: 'ok', oa: 'ok',
      mech: 'Stimulates M3 on the constrictor pupillae (miosis) and the ciliary muscle (accommodation for near). Miosis and ciliary contraction open the canal of Schlemm, so aqueous drains better.',
      use: 'Closed-angle glaucoma: the drug of choice to lower IOP before iridectomy, in low concentration (≤2%). Open-angle glaucoma.', side: 'Lacrimation, conjunctival congestion; systemic effects can follow local use.', hook: 'Miosis, near focus, lower pressure: everything a glaucoma eye needs.' },
    { id: 'physo', name: 'Physostigmine', grp: 'Miotics', cls: 'Anticholinesterase, reversible · ¼–½%', pupil: 2, acc: 'near', T: 1.6, Tc: 2.8, hyper: 0.5, tgt: ['sph', 'cm'], ca: 'ok', oa: 'ok',
      mech: 'Blocks cholinesterase, so acetylcholine builds up at M3: miosis, ciliary contraction, better drainage.', use: 'Glaucoma (also used to lower IOP in closed angle).', side: 'Allergic reactions limit its use; lid twitches (all anticholinesterases).' },
    { id: 'echo', name: 'Echothiophate', grp: 'Miotics', cls: 'Anticholinesterase, irreversible (also isoflurophate)', pupil: 1.2, acc: 'near', T: 1.8, Tc: 0.8, hyper: 0.8, tgt: ['sph', 'cm'], ca: 'no', oa: 'ok',
      mech: 'Irreversibly blocks cholinesterase: strong, long-lasting M3 stimulation.', use: 'Open-angle glaucoma.', side: 'Extreme miosis, local irritation, cataract, lid twitches.', contra: 'Contraindicated in closed-angle glaucoma (congestion, extreme miosis).', trap: 'Irreversible anticholinesterases give the strongest miosis but cause cataract.' },
    { id: 'guan', name: 'Guanethidine', grp: 'Miotics', cls: 'Sympatholytic', pupil: 2.6, T: 1.2, Tc: 1.5, tgt: ['dil'],
      mech: 'Blocks the sympathetic supply to the dilator pupillae, so the constrictor works unopposed: miosis.', use: 'One of the three groups of miotics.' },
    { id: 'morph', name: 'Morphine', grp: 'Miotics', cls: 'Opioid, acting centrally', pupil: 1.4, tgt: ['cns'],
      mech: 'Miosis by a central action, not on the eye itself.', use: 'Not used on the eye: a pinpoint pupil is a sign of opioid use.', hook: '"Pupils Get Mini": Parasympathomimetics, Guanethidine, Morphine.' },
    { id: 'phen', name: 'Phenylephrine', grp: 'Active mydriatics', cls: 'Sympathomimetic, direct α1 agonist · 2.5–10% (0.12% decongestant)', pupil: 7.2, T: 1, Tc: 0.4, blanch: 1, tgt: ['dil'], ca: 'no',
      mech: 'Stimulates α1 on the dilator pupillae: active mydriasis. Constricts the conjunctival vessels (decongestion). No cycloplegia.', use: 'Fundus examination (2.5–10%); 0.12% to decongest the eye.', contra: 'Contraindicated in closed-angle glaucoma.', hook: 'Active = the dilator works, nothing is paralysed: reflexes kept, focus kept.' },
    { id: 'coca', name: 'Cocaine', grp: 'Active mydriatics', cls: 'Local anaesthetic; blocks uptake 1, inhibits MAO', pupil: 6.5, cornea: 0, T: 1, Tc: 0.45, blanch: 1, tgt: ['dil'], ca: 'no',
      mech: 'Prevents uptake 1 of catecholamines and inhibits MAO: active mydriasis with the light reflex present. As a local anaesthetic it numbs the cornea.', use: 'Surface anaesthetic for the cornea and conjunctiva.', trap: 'The one mydriatic that abolishes the corneal reflex, while the light reflex stays.' },
    { id: 'atro', name: 'Atropine', grp: 'Passive mydriatics', cls: 'Parasympatholytic: blocks M3 (also homatropine, cyclopentolate)', pupil: 8, light: 0, acc: 'cyclo', T: 0.75, Tc: 0.3, tgt: ['sph', 'cm'], ca: 'no', oa: 'no',
      mech: 'Blocks M3, paralysing the constrictor pupillae (passive mydriasis) and the ciliary muscle (cycloplegia: focus fixed for far). Mydriasis and cycloplegia close the angle and the canal of Schlemm: IOP rises.', use: 'Treating iritis; measuring refraction; fundus examination.', side: 'Raised IOP; less lacrimation.', contra: 'Absolutely contraindicated in glaucoma.', hook: 'Passive = the constrictor is paralysed: no light reflex, no focus, pressure up.' },
    { id: 'tropi', name: 'Tropicamide', grp: 'Passive mydriatics', cls: 'Parasympatholytic, a weak cycloplegic', pupil: 7, light: 0, acc: 'weak', T: 0.85, Tc: 0.35, tgt: ['sph', 'cm'], ca: 'no', oa: 'no',
      mech: 'Blocks M3 like atropine, but its cycloplegia is weak.', use: 'Fundus examination: the most used, because it is only a weak cycloplegic.', contra: 'Contraindicated in glaucoma (passive mydriatics raise IOP).' },
    { id: 'timo', name: 'Timolol', grp: 'Glaucoma drugs', cls: 'β-blocker · 0.25–0.5% (also betaxolol, levobunolol)', P: 0.7, tgt: ['epi'], ca: 'ok', oa: 'ok',
      mech: 'Blocks β receptors (mainly β2) on the ciliary epithelium: less aqueous is formed.', use: 'Open-angle glaucoma; recently with pilocarpine in closed angle.', side: 'Tolerance; systemic absorption.', contra: 'Asthma and cardiac patients.', trap: 'Timolol drops still reach the blood: never in asthma.' },
    { id: 'brimo', name: 'Brimonidine', grp: 'Glaucoma drugs', cls: 'Selective α2 agonist (apraclonidine: short use only, tachyphylaxis)', P: 0.8, U: 1.8, tgt: ['epi', 'uveo'], ca: 'ok', oa: 'ok',
      mech: 'Reduces aqueous secretion and enhances uveoscleral outflow.', use: 'Open-angle glaucoma; also to lower IOP before iridectomy in closed angle.', side: 'Allergic conjunctivitis, dry mouth, fatigue.' },
    { id: 'latano', name: 'Latanoprost', grp: 'Glaucoma drugs', cls: 'Prostaglandin analogue (also travoprost, bimatoprost)', U: 4, hyper: 0.6, pig: 1, tgt: ['uveo'], oa: 'ok',
      mech: 'Enhances uveoscleral outflow: the most potent ocular hypotensives.', use: 'Open-angle glaucoma. Not for closed angle: the onset is too slow.', side: 'Hyperpigmentation of the eye, conjunctival hyperaemia, headache.', hook: '"Prostaglandins Pour it out the side": the strongest drops, via the uveoscleral route, but they darken the eye.' },
    { id: 'epi', name: 'Epinephrine / dipivefrin', grp: 'Glaucoma drugs', cls: 'Sympathomimetic (dipivefrin: a prodrug of epinephrine)', pupil: 5, U: 1.6, hyper: 0.5, tgt: ['uveo'], oa: 'ok',
      mech: 'Increases outflow via the uveoscleral veins.', use: 'Open-angle glaucoma.', side: 'Allergy, red eye (less with dipivefrin), systemic absorption.' },
    { id: 'acet', name: 'Acetazolamide', grp: 'Glaucoma drugs', cls: 'Carbonic anhydrase inhibitor: oral (topical: dorzolamide, brinzolamide)', P: 0.6, tgt: ['epi'], ca: 'ok', oa: 'ok',
      mech: 'Inhibits carbonic anhydrase in the ciliary epithelium: with no HCO3⁻, less aqueous is secreted.', use: 'Closed angle (orally, before iridectomy); open angle (topical dorzolamide, brinzolamide).' },
    { id: 'mann', name: 'Mannitol', grp: 'Glaucoma drugs', cls: 'Osmotic agent · IV 20% (glycerine 50% orally, Mg sulphate rectally)', osm: 0.62, tgt: ['blood'], ca: 'ok',
      mech: 'Raises plasma osmolality and draws water out of the eye: a rapid, marked fall in IOP.', use: 'Closed-angle glaucoma: first, to lower IOP before iridectomy.' },
    { id: 'dexa', name: 'Dexamethasone drops', grp: 'Other', cls: 'Corticosteroid (anti-inflammatory)', T: 0.7, Tc: 0.7, tgt: [], ca: 'no', oa: 'no',
      mech: 'Anti-inflammatory and anti-allergic; but it can raise IOP.', use: 'Inflammation and allergy of the eye.', side: 'Cataract and glaucoma.', trap: 'Steroid eye drops can cause glaucoma and cataract.' }
  ];
  var CONDS = { healthy: { T: 1, name: 'Healthy eye' }, open: { T: 0.5, name: 'Open-angle glaucoma' }, closed: { T: 0.2, name: 'Closed-angle glaucoma' } };
  /* ---- Follow it, step by step: the aqueous routes, the reflex tracts to the brain and back, and what happens when a
     drug is used where it is contraindicated. Each walk is drawn on a map (the drainage angle, the brain from below, or
     the body). A step draws its part of the route (go: segments, or chains of segments drawn one after the other),
     lights its parts (lit) and may change the picture (fx: classes, the iris, the IOP gauge). Notes react to the drug. */
  function has(d, t) { return (d.tgt || []).indexOf(t) >= 0; }
  function N(t, c, stop) { return { t: t, c: c || 'info', stop: !!stop }; }
  function byId(id) { for (var i = 0; i < DRUGS.length; i++) if (DRUGS[i].id === id) return DRUGS[i]; return DRUGS[0]; }
  function merge() { var o = {}, i, k; for (i = 0; i < arguments.length; i++) for (k in arguments[i]) o[k] = arguments[i][k]; return o; }
  function gLab(x, y, node, txt, anchor, cls) { return '<text x="' + x + '" y="' + y + '" class="g-lab' + (cls || '') + '" data-node="' + node + '"' + (anchor ? ' text-anchor="' + anchor + '"' : '') + '>' + txt + '</text>'; }
  function gNode(x, y, node) { return '<circle cx="' + x + '" cy="' + y + '" r="4.5" class="bm-n" data-node="' + node + '"/>'; }
  function gEye(node, x) { return '<g class="bm-eye" data-node="' + node + '" transform="translate(' + x + ' 34)"><ellipse rx="26" ry="15" class="bm-white"/><g class="bm-iris"><circle r="11"/><circle r="5" class="bm-pupil"/></g><rect class="bm-lid" x="-28" y="-17" width="56" height="34" rx="16"/></g>'; }

  // the iris in the angle map: every shape is "M C", so one can turn into another smoothly
  var IRIS = {
    n: ['M156 98 C156 140 158 180 160 212', 12, '#6f8fb3'],    // normal
    nr: ['M146 92 C152 136 157 178 160 212', 12, '#6f8fb3'],   // a narrow angle: the root close to the trabeculum
    d: ['M146 92 C150 116 154 136 158 156', 20, '#6f8fb3'],    // dilated: short and thick
    b: ['M132 84 C144 106 152 128 158 152', 22, '#6f8fb3'],    // bunched into the angle, over the trabeculum
    m0: ['M146 92 C150 140 160 200 182 238', 9, '#a0688a'],    // extreme miosis, congested, pressed on the lens
    m: ['M138 88 C112 136 136 206 182 238', 10, '#a0688a']     // bowed forward onto the trabeculum (iris bombé)
  };
  var AQ = { aq1: ['M222 98 C222 112 218 126 210 142', 'aq'], aq2: ['M210 142 C200 170 188 198 178 226', 'aq'], aq3: ['M178 226 C160 248 116 242 100 212 C88 190 88 162 96 140', 'aq'], aq4: ['M96 140 C102 118 112 102 122 92', 'aq'] };
  var TR = { tr1: ['M120 92 C123 86 126 80 128 73', 'tr'], tr2: ['M128 73 L131 62', 'tr'], tr3: ['M137 54 C141 46 146 38 152 30', 'tr'], tr4: ['M152 28 C190 17 220 28 260 20 S330 24 372 15', 'tr'] };
  var UV = { uv1: ['M120 98 C132 100 146 98 158 92', 'uv'], uv2: ['M158 92 C172 82 190 74 214 65', 'uv'], uv3: ['M214 65 C260 63.5 320 62 372 60', 'uv'] };
  var PRE = ['aq1', 'aq2', 'aq3', 'aq4'], PRE_TR = PRE.concat(['tr1', 'tr2', 'tr3', 'tr4']);
  var BR = {
    onL: ['M120 50 Q150 92 190 108', 'in'], onR: ['M260 50 Q230 92 190 108', 'in'],
    ptL: ['M190 108 C176 122 164 140 178 158', 'in'], ptR: ['M190 108 C204 122 216 140 202 158', 'in'],
    e1: ['M178 158 L183 176', 'mid'], e2: ['M178 158 C188 163 193 169 197 176', 'mid'], e3: ['M202 158 L197 176', 'mid'], e4: ['M202 158 C192 163 187 169 183 176', 'mid'],
    c3L: ['M183 176 C164 172 146 130 122 80', 'out'], c3R: ['M197 176 C216 172 234 130 258 80', 'out'],
    scL: ['M122 80 L116 50', 'out'], scR: ['M258 80 L264 50', 'out'],
    otL: ['M190 108 C175 120 160 135 136 166', 'in'], otR: ['M190 108 C205 120 220 135 244 166', 'in'],
    radL: ['M136 166 C108 196 112 250 150 290', 'in'], radR: ['M244 166 C272 196 268 250 230 290', 'in'],
    a8: ['M230 292 C300 290 316 220 286 130', 'mid'], a8ew: ['M286 130 C270 146 230 168 192 180', 'mid'],
    mrL: ['M190 189 C166 172 150 110 140 42', 'out'], mrR: ['M190 189 C214 172 230 110 240 42', 'out'],
    v1: ['M108 36 C70 50 60 150 86 196', 'in'], v1b: ['M86 196 C120 214 150 230 176 236', 'in'],
    v7a: ['M176 236 L184 248', 'mid'], v7b: ['M176 236 C188 238 193 243 196 248', 'mid'],
    fnL: ['M184 248 C150 262 60 270 40 200 C26 150 40 70 96 30', 'out'], fnR: ['M196 248 C230 262 320 270 340 200 C354 150 340 70 284 30', 'out']
  };
  var BODY = { b1: ['M68 62 C78 82 74 104 64 118', 'drug'], b2: ['M72 124 C110 112 130 92 168 92 C210 90 236 120 240 152', 'drug'], b3a: ['M232 168 C222 162 214 158 204 154', 'drug'], b3b: ['M262 168 C272 162 280 158 290 154', 'drug'] };

  var GMAPS = {
    angle: { vb: '0 0 380 270', draw: function (g) {
      var ir = IRIS[g.iris || 'n'];
      return '<rect width="380" height="270" fill="#0d1422"/>' +
        '<ellipse cx="292" cy="300" rx="112" ry="130" class="am-lens" data-node="lens"/>' +
        '<path d="M214 96 L262 176 M238 88 L292 171 M200 100 L240 186" class="am-zon"/>' +
        '<path d="M300 63 L380 61 L380 75 L300 79 Z" class="am-choroid" data-node="scs"/>' +
        '<g class="am-cbv" data-node="cbv"><circle cx="312" cy="70" r="3.2"/><circle cx="338" cy="69" r="3.2"/><circle cx="364" cy="68" r="3.2"/></g>' +
        '<path d="M150 70 L330 61 L162 108 Z" class="am-cb" data-node="cb"/>' +
        '<path d="M168 106 q6 10 13 -4 q6 10 13 -4 q6 10 13 -4 q6 10 13 -4 q6 10 13 -4 q6 10 13 -4" class="am-epi" data-node="epi"/>' +
        '<path d="M96 36 L380 28 L380 58 L118 66 Z" class="am-sclera"/>' +
        '<path d="M150 26 C190 16 220 28 260 20 S330 24 376 14" class="am-vein" data-node="epv"/>' +
        '<path d="M137 54 C141 46 146 38 152 30" class="am-coll" data-node="coll"/>' +
        '<ellipse cx="132" cy="58" rx="9" ry="4.5" class="am-schlemm" data-node="schlemm"/>' +
        '<g class="am-trab" data-node="trab"><path d="M114 66 L140 64 L144 84 L118 88 Z"/><path d="M118 70 L138 82 M122 66 L142 78 M114 76 L132 86 M128 66 L118 84 M136 66 L124 86"/></g>' +
        '<path d="M104 42 Q14 150 52 270" class="am-cornea" data-node="cornea"/>' +
        '<path d="' + ir[0] + '" class="am-iris" data-node="iris" style="stroke-width:' + ir[1] + 'px;stroke:' + ir[2] + '"/>' +
        '<path d="M94 22 L125 54" class="g-lead" data-node="schlemm"/><path d="M72 70 L115 76" class="g-lead" data-node="trab"/><path d="M252 104 L240 92" class="g-lead" data-node="epi"/>' +
        gLab(92, 20, 'schlemm', 'Schlemm’s canal', 'end') + gLab(70, 64, 'trab', 'Trabecular', 'end') + gLab(70, 75, 'trab', 'meshwork', 'end') +
        gLab(232, 11, 'epv', 'Episcleral veins', 'middle') + gLab(6, 236, 'cornea', 'Cornea') + gLab(100, 160, 'ac', 'Anterior', 'middle') + gLab(100, 171, 'ac', 'chamber', 'middle') +
        gLab(222, 150, 'pc', 'Posterior chamber', 'middle') + gLab(176, 254, 'pupil', 'Pupil', 'middle') + gLab(168, 196, 'iris', 'Iris') +
        gLab(250, 113, 'epi', 'Ciliary processes') + gLab(232, 80, 'cb', 'Ciliary muscle', 'middle', ' in') + gLab(376, 92, 'scs', 'Suprachoroidal', 'end') + gLab(376, 102, 'scs', 'space', 'end') +
        gLab(250, 214, 'lens', 'Lens', 'middle');
    }, top: function () {
      var x = '<circle r="8"/><path d="M-3.5 -3.5 L3.5 3.5 M3.5 -3.5 L-3.5 3.5"/>';
      return '<g class="am-x" data-x="trab" transform="translate(128 78)">' + x + '</g><g class="am-x" data-x="pupil" transform="translate(180 222)">' + x + '</g>' +
        '<g class="am-iop" transform="translate(288 234)"><rect width="84" height="30" rx="9"/><text x="10" y="12" class="am-iopk">IOP</text><text x="10" y="25" class="am-iopv">–</text></g>';
    } },
    brain: { vb: '0 0 380 312', draw: function () {
      return '<rect width="380" height="312" fill="#0d1422"/><ellipse cx="190" cy="196" rx="150" ry="112" class="bm-brain"/>' +
        '<path d="M120 50 Q150 92 190 108 M260 50 Q230 92 190 108 M190 108 C175 120 160 135 136 166 M190 108 C205 120 220 135 244 166 M136 166 C108 196 112 250 150 290 M244 166 C272 196 268 250 230 290" class="bm-anat"/>' +
        '<ellipse cx="190" cy="180" rx="32" ry="24" class="bm-region" data-node="mid"/><ellipse cx="190" cy="240" rx="28" ry="16" class="bm-region" data-node="pons"/>' +
        '<text x="190" y="201" class="bm-rl">Midbrain</text><text x="190" y="268" class="bm-rl">Pons</text>' +
        '<path d="M126 296 Q150 304 172 294 M208 294 Q230 304 254 296" class="bm-ctx" data-node="a17"/><ellipse cx="286" cy="122" rx="13" ry="8" class="bm-ctx2" data-node="a8"/>' +
        gNode(190, 108, 'chiasm') + gNode(136, 166, 'lgb') + gNode(244, 166, 'lgb') + gNode(178, 158, 'pret') + gNode(202, 158, 'pret') + gNode(183, 176, 'ew') + gNode(197, 176, 'ew') +
        gNode(190, 189, 'n3') + gNode(122, 80, 'cg') + gNode(258, 80, 'cg') + gNode(86, 196, 'tg') + gNode(176, 236, 'n5') + gNode(184, 248, 'n7') + gNode(196, 248, 'n7') +
        gEye('eyeL', 120) + gEye('eyeR', 260) +
        '<path d="M64 2 L104 28" class="bm-ray" data-node="ray"/><path d="M52 44 C66 38 82 36 98 36" class="bm-touch" data-node="touch"/>' +
        '<g class="bm-near" data-node="nearobj"><rect x="178" y="3" width="24" height="15" rx="2"/><path d="M190 3 V18"/></g>' +
        gLab(190, 82, 'on', 'Optic nerve (II)', 'middle') + gLab(208, 116, 'chiasm', 'Optic chiasma') + gLab(138, 143, 'ot', 'Optic tract', 'end') +
        gLab(124, 163, 'lgb', 'LGB', 'end') + gLab(256, 163, 'lgb', 'LGB') + gLab(236, 150, 'pret', 'Pretectal nuclei') + gLab(190, 216, 'ew', 'Edinger-Westphal nuclei', 'middle') +
        gLab(230, 192, 'n3', 'III motor nucleus') + gLab(112, 86, 'cg', 'Ciliary ganglion', 'end') + gLab(268, 86, 'cg', 'Ciliary ganglion') +
        gLab(150, 310, 'a17', 'Visual cortex (area 17)', 'middle') + gLab(304, 104, 'a8', 'Area 8 (frontal eye field)', 'middle') +
        gLab(96, 210, 'tg', 'Trigeminal ganglion') + gLab(222, 234, 'n5', 'Trigeminal sensory n.') + gLab(222, 247, 'n7', 'Facial motor nuclei') +
        '<g class="bm-key" transform="translate(250 306)"><circle cy="-3" r="3" class="k-in"/><text x="6">sensory</text><circle cx="50" cy="-3" r="3" class="k-mid"/><text x="56">centre</text><circle cx="92" cy="-3" r="3" class="k-out"/><text x="98">motor</text></g>';
    } },
    body: { vb: '0 0 380 270', draw: function () {
      return '<rect width="380" height="270" fill="#0d1422"/>' +
        '<circle cx="70" cy="80" r="62" class="by-head"/><path d="M150 262 L150 118 Q150 84 188 84 L322 84 Q360 84 360 118 L360 262" class="by-body"/>' +
        '<path d="M56 4 C50 14 46 20 46 25 A10 10 0 0 0 66 25 C66 20 62 14 56 4Z" class="by-drop" data-node="drop"/>' +
        '<g class="by-eye" data-node="eye"><ellipse cx="56" cy="58" rx="14" ry="8"/><circle cx="56" cy="58" r="5" class="i"/></g>' +
        '<path d="M68 62 C78 82 74 104 64 118" class="by-duct"/><ellipse cx="64" cy="124" rx="9" ry="7" class="by-nose" data-node="nose"/>' +
        '<ellipse cx="190" cy="160" rx="34" ry="58" class="by-lung" data-node="lungs"/><ellipse cx="304" cy="160" rx="34" ry="58" class="by-lung" data-node="lungs"/>' +
        '<path d="M247 70 L247 112 M247 112 C232 120 210 126 196 140 M247 112 C262 120 284 126 298 140 M212 128 L202 156 M282 128 L292 156" class="by-bronch" data-node="lungs"/>' +
        '<path d="M247 202 C222 184 216 162 232 154 C240 150 247 156 247 162 C247 156 254 150 262 154 C278 162 272 184 247 202Z" class="by-heart" data-node="heart"/>' +
        '<ellipse cx="318" cy="240" rx="44" ry="15" class="by-liver" data-node="liver"/><path d="M304 232 L332 248 M332 232 L304 248" class="by-skip" data-node="liver"/>' +
        '<text x="247" y="236" class="by-hr norm" text-anchor="middle">HR 72</text><text x="247" y="236" class="by-hr slow" text-anchor="middle">HR 48 ↓</text>' +
        '<text x="304" y="96" class="by-wz" text-anchor="middle">bronchospasm</text>' +
        gLab(78, 46, 'eye', 'Eye') + gLab(82, 92, 'duct', 'Nasolacrimal') + gLab(82, 103, 'duct', 'duct') + gLab(78, 128, 'nose', 'Nose') +
        gLab(247, 220, 'heart', 'Heart', 'middle') + gLab(190, 232, 'lungs', 'Lungs', 'middle') + gLab(318, 266, 'liver', 'Liver: skipped', 'middle');
    } }
  };

  // notes that react to the drug in the eye (m: the model with that drug)
  function nMade(m) { var d = m.d; if (m.P < 1) return N(d.name + ' acts here: ' + d.mech, 'good'); if (has(d, 'blood')) return N(d.name + ' works from the blood, not here: ' + d.mech, 'good'); return null; }
  function nTrab(m) {
    var d = m.d, r = m.T / CONDS[m.cond].T;
    if (d.id === 'dexa') return N('Steroid drops clog this meshwork, so less drains and the IOP rises.', 'bad');
    if (r > 1.02) return N(d.name + ' acts here: ' + (has(d, 'cm') ? 'the ciliary muscle contracts and pulls the meshwork open, and the small pupil draws the iris out of the angle, so more drains.' : 'with the pupil small, the iris is drawn out of the angle, so more drains.'), 'good');
    if (r < 0.98) return N(d.name + ' narrows this route: ' + (d.acc === 'near' ? 'the extreme miosis and the congested iris crowd the angle.' : (has(d, 'cm') ? 'the ciliary muscle relaxes, and ' : '') + 'the thick, dilated iris crowds the angle.'), 'bad');
    if (m.cond === 'open') return N('Open-angle glaucoma: the angle is open, but this meshwork drains poorly.');
    if (m.cond === 'closed') return N('Closed-angle glaucoma: the iris root lies against this meshwork and blocks the way in.', 'bad');
    return null;
  }
  function nUveo(m) { return m.U > 1 ? N(m.d.name + ' acts here: ' + m.d.mech, 'good') : null; }
  function nEW(m) { return has(m.d, 'cns') ? N(m.d.name + ' acts here, in the brain: it drives the Edinger-Westphal nuclei, so both pupils become pinpoint.', 'drug') : null; }
  function nSph(m) {
    var d = m.d;
    if (has(d, 'sph') && !m.light) return N('✕ ' + d.name + ' blocks M3 here: the signal arrives, but the constrictor is paralysed, so the pupil stays wide. Light reflex absent.', 'bad');
    if (has(d, 'sph')) return N(d.name + ' stimulates M3 here as well, so the pupil is already small.', 'drug');
    if (has(d, 'dil')) return N(d.name + ' works on the dilator, not on this path, so the constrictor still answers: light reflex present.', 'drug');
    return null;
  }
  function nCm(m) {
    var d = m.d;
    if (m.acc === 'cyclo') return N('✕ ' + d.name + ' paralyses the ciliary muscle and the constrictor here (cycloplegia): the lens cannot round up and the pupil stays wide, so near things stay blurred.', 'bad');
    if (m.acc === 'weak') return N(d.name + ' weakens the ciliary muscle a little: focusing for near is weak.', 'bad');
    if (m.acc === 'near') return N(d.name + ' keeps the ciliary muscle contracted (spasm): the eye is already fixed for near, and far things blur.', 'drug');
    return null;
  }
  function nCornea(m) { return m.cornea ? null : N('✕ ' + m.d.name + ' is a local anaesthetic: it numbs these nerve endings, so no signal starts. Corneal reflex absent.', 'bad', true); }
  function nSwitched(m, sc) { return sc && sc.switched ? N('The model eye above is now set to ' + CONDS[m.cond].name.toLowerCase() + '.') : null; }
  function nContra(m) { return N(m.d.contra || ('Steroid eye drops can cause glaucoma and cataract: avoid them in glaucoma.'), 'bad'); }

  var GUIDES = {
    aq: { map: 'angle', route: 'aq', kick: 'FOLLOW THE AQUEOUS', title: 'Where aqueous is made and where it goes', segs: AQ,
      steps: [
        { h: 'Made by the ciliary epithelium', p: 'The epithelium on the ciliary processes secretes aqueous. Its receptors are mainly β2 (some β1), and carbonic anhydrase supplies the HCO3⁻ it needs.', lit: ['epi', 'cb'], note: nMade },
        { h: 'Into the posterior chamber', p: 'It fills the narrow space behind the iris and in front of the lens.', go: ['aq1'], lit: ['pc'] },
        { h: 'Through the pupil', p: 'It slips between the iris and the lens and passes through the pupil.', go: ['aq2'], lit: ['pupil', 'iris'] },
        { h: 'Round the anterior chamber', p: 'It circulates between the iris and the cornea, feeding the cornea and the lens, which have no blood vessels.', go: ['aq3'], lit: ['ac', 'cornea', 'lens'] },
        { h: 'To the angle: two ways out', p: 'Where the cornea meets the iris it leaves: 90% through the trabeculum into the canal of Schlemm, 10% by the uveoscleral route. The IOP (normal 15–25 mm Hg) depends on how much is made and how easily it drains.', go: ['aq4'], lit: ['trab'] }
      ],
      more: [['tr', 'The front door: Schlemm’s canal (90%)'], ['uv', 'The side door: uveoscleral (10%)']] },
    tr: { map: 'angle', route: 'tr', kick: 'THE CONVENTIONAL ROUTE · 90%', title: 'Out through the trabeculum and Schlemm’s canal', segs: merge(AQ, TR), pre: PRE,
      steps: [
        { h: 'Aqueous reaches the angle', p: 'About 90% of it leaves here, by the conventional route: the front door.', lit: ['trab'] },
        { h: 'Through the trabecular meshwork', p: 'A spongy sieve of tiny collagen beams at the angle. Aqueous filters through its gaps; most of the resistance to outflow is here.', go: ['tr1'], lit: ['trab'], note: nTrab },
        { h: 'Into the canal of Schlemm', p: 'A circular canal that runs all the way round the eye at the edge of the cornea and collects what comes through the meshwork.', go: ['tr2'], lit: ['schlemm'] },
        { h: 'Out through the sclera', p: 'Small collector channels (aqueous veins) carry it out through the sclera.', go: ['tr3'], lit: ['coll'] },
        { h: 'Into the episcleral veins', p: 'On the surface of the sclera it joins the episcleral veins, and so the blood.', go: ['tr4'], lit: ['epv'] }
      ],
      more: [['uv', 'The side door: uveoscleral (10%)'], ['aq', 'Where aqueous is made']] },
    uv: { map: 'angle', route: 'uv', kick: 'THE UVEOSCLERAL ROUTE · 10%', title: 'Out by the uveoscleral route', segs: merge(AQ, UV), pre: PRE,
      steps: [
        { h: 'Aqueous reaches the angle', p: 'About 10% leaves by a side door that skips the trabeculum.', lit: ['cb'] },
        { h: 'Into the face of the ciliary body', p: 'At the angle the front of the ciliary muscle is bare, and aqueous soaks into it there.', go: ['uv1'], lit: ['cb'], note: nUveo },
        { h: 'Between the muscle bundles', p: 'It seeps back through the spaces between the bundles of the ciliary muscle.', go: ['uv2'], lit: ['cb'],
          note: function (m) { return m.d.id === 'latano' ? N('Prostaglandin analogues relax the ciliary muscle and loosen the tissue between its bundles, so these spaces widen and far more gets through: the strongest drops.', 'good') : null; } },
        { h: 'Into the suprachoroidal space', p: 'It reaches the thin space between the ciliary body and choroid on one side and the sclera on the other.', go: ['uv3'], lit: ['scs'] },
        { h: 'Taken up by the veins', p: 'The veins of the ciliary body and choroid take it up, and a little seeps on through the sclera.', lit: ['cbv'] }
      ],
      more: [['tr', 'The front door: Schlemm’s canal (90%)'], ['aq', 'Where aqueous is made']] },

    light: { map: 'brain', kick: 'THE LIGHT REFLEX · FOLLOW THE TRACT', title: 'The light reflex: to the brain and back', segs: BR,
      steps: [
        { h: 'Light falls on the retina', p: 'A light is shone into one eye. The rods and cones respond, and the ganglion cells fire.', lit: ['ray', 'eyeL'] },
        { h: 'Along the optic nerve to the chiasma', p: 'The signal runs back along the optic nerve (II). At the optic chiasma the nasal fibres cross, so both optic tracts carry it.', go: ['onL'], lit: ['on', 'chiasm'] },
        { h: 'Off the optic tract to the pretectal nuclei', p: 'Before the lateral geniculate body, the reflex fibres leave the optic tract for the pretectal nuclei of the midbrain. The visual cortex is not involved.', go: ['ptL', 'ptR'], lit: ['ot', 'pret'] },
        { h: 'To both Edinger-Westphal nuclei', p: 'Each pretectal nucleus signals the Edinger-Westphal nuclei of both sides. That is why both pupils constrict: the direct and the indirect (consensual) light reflex.', go: ['e1', 'e2', 'e3', 'e4'], lit: ['ew'], note: nEW },
        { h: 'Oculomotor nerve to the ciliary ganglion', p: 'Parasympathetic fibres leave with the oculomotor nerve (III) and relay in the ciliary ganglion.', go: ['c3L', 'c3R'], lit: ['cg'] },
        { h: 'Short ciliary nerves to the constrictor', p: 'Acetylcholine acts on M3 of the constrictor pupillae, and both pupils constrict.', go: ['scL', 'scR'], lit: ['eyeL', 'eyeR'], note: nSph,
          fx: function (m) { return { c: m.light ? 'constrict' : '' }; } }
      ],
      more: [['near', 'The near reflex'], ['cornea', 'The corneal reflex']] },
    near: { map: 'brain', kick: 'THE NEAR REFLEX · FOLLOW THE TRACT', title: 'The near (accommodation) reflex', segs: BR,
      steps: [
        { h: 'Looking at something near', p: 'Changing from a far object to a near one blurs the image on the retina.', lit: ['nearobj', 'eyeL', 'eyeR'] },
        { h: 'Optic nerve to the chiasma', p: 'The signal runs back along both optic nerves (II) to the optic chiasma.', go: ['onL', 'onR'], lit: ['on', 'chiasm'] },
        { h: 'Optic tract to the lateral geniculate body', p: 'Unlike the light reflex, it stays in the optic tract all the way to the lateral geniculate body (LGB) of the thalamus.', go: ['otL', 'otR'], lit: ['ot', 'lgb'] },
        { h: 'Optic radiation to the visual cortex', p: 'The optic radiation carries it to the visual cortex (area 17), which sees the blur.', go: ['radL', 'radR'], lit: ['a17'] },
        { h: 'To the frontal eye field', p: 'The visual cortex signals the frontal eye field (area 8).', go: ['a8'], lit: ['a8'] },
        { h: 'Down to the oculomotor nuclei', p: 'Area 8 drives the Edinger-Westphal nucleus (parasympathetic) and the somatic motor nucleus of III.', go: ['a8ew'], lit: ['ew', 'n3'] },
        { h: 'The parasympathetic arm', p: 'Edinger-Westphal → ciliary ganglion → short ciliary nerves → the ciliary muscle (the lens gets rounder) and the constrictor pupillae (the pupil gets smaller).', go: [['c3L', 'scL'], ['c3R', 'scR']], lit: ['cg', 'eyeL', 'eyeR'], note: nCm,
          fx: function (m) { return { c: m.light ? 'constrict' : '' }; } },
        { h: 'The somatic arm', p: 'The somatic motor nucleus of III → the medial rectus of both eyes: the eyes converge. Near response = convergence, constriction of the pupil and curvature of the lens.', go: ['mrL', 'mrR'], lit: ['n3', 'eyeL', 'eyeR'],
          fx: function (m) { return { c: ['converge', m.light ? 'constrict' : ''] }; } }
      ],
      more: [['light', 'The light reflex'], ['cornea', 'The corneal reflex']] },
    cornea: { map: 'brain', kick: 'THE CORNEAL REFLEX · FOLLOW THE TRACT', title: 'The corneal (blink) reflex', segs: BR,
      steps: [
        { h: 'Touch the cornea', p: 'A wisp of cotton touches the cornea and stimulates its free nerve endings (the long ciliary nerves, from the nasociliary nerve).', lit: ['touch', 'eyeL'], note: nCornea },
        { h: 'Ophthalmic nerve to the trigeminal ganglion', p: 'The signal runs back along the ophthalmic division of the trigeminal (V1) to the trigeminal ganglion.', go: ['v1'], lit: ['tg'] },
        { h: 'Into the brainstem', p: 'It enters the pons and reaches the sensory nucleus of the trigeminal.', go: ['v1b'], lit: ['pons', 'n5'] },
        { h: 'To both facial nuclei', p: 'Interneurons pass it to the facial motor nuclei of both sides.', go: ['v7a', 'v7b'], lit: ['n7'] },
        { h: 'Facial nerve to orbicularis oculi', p: 'The facial nerve (VII) contracts orbicularis oculi: both eyes blink (direct and consensual).', go: ['fnL', 'fnR'], lit: ['eyeL', 'eyeR'],
          fx: function (m) { return { c: m.cornea ? 'blink' : '' }; } }
      ],
      more: [['light', 'The light reflex'], ['near', 'The near reflex']] },

    // what happens when a drug is used where it is contraindicated
    'wi-angle': { what: true, map: 'angle', cond: 'closed', iris: 'nr', kick: 'CONTRAINDICATED · WHAT IF IT IS USED?', title: function (d) { return d.name + ' in closed-angle glaucoma'; }, segs: merge(AQ, TR), pre: PRE_TR,
      steps: [
        { h: 'A narrow angle', p: 'In closed-angle glaucoma the iris root lies close to the trabeculum, so the way out for aqueous is narrow. IOP now: {from} mm Hg.', lit: ['trab', 'iris'], fx: { iris: 'nr', iop: 'from' }, note: nSwitched },
        { h: function (d) { return has(d, 'sph') ? 'The constrictor is paralysed' : 'The dilator pulls the pupil open'; },
          p: function (d) { return has(d, 'sph') ? '{name} blocks M3: the constrictor pupillae is paralysed, so the pupil dilates (passive mydriasis). The ciliary muscle is paralysed too (cycloplegia).' : d.id === 'coca' ? '{name} stops the re-uptake of noradrenaline, so the dilator pupillae contracts and the pupil dilates (active mydriasis).' : '{name} stimulates α1 on the dilator pupillae, so the pupil dilates (active mydriasis).'; },
          lit: ['iris', 'pupil'], fx: { iris: 'd', iop: 'from' } },
        { h: 'The iris bunches into the angle', p: function (d) { return 'A dilated iris is short and thick. Its root folds forward into the narrow angle and covers the trabeculum.' + (has(d, 'cm') ? ' With the ciliary muscle relaxed, nothing pulls the meshwork open either.' : ''); },
          lit: ['trab', 'iris'], fx: { iris: 'b', c: 'x', iop: 'from' } },
        { h: 'Aqueous is trapped', p: 'The ciliary epithelium keeps making aqueous, but it can no longer reach the canal of Schlemm.', lit: ['epi', 'ac'], fx: { iris: 'b', c: ['x', 'block'], iop: 'from' } },
        { h: 'The pressure shoots up', p: 'IOP: {from} → {to} mm Hg. An acute attack: a painful red eye, blurred vision with haloes, headache and vomiting. Left untreated, the pressure damages the optic nerve and the eye can go blind.', fx: { iris: 'b', c: ['x', 'block'], iop: 'to' }, note: nContra }
      ],
      fixLabel: 'Treat the attack: ', fix: [['mann', 'osmotic, works fast'], ['pilo', 'drug of choice, ≤2%']] },
    'wi-open': { what: true, map: 'angle', cond: 'open', kick: 'CONTRAINDICATED · WHAT IF IT IS USED?', title: function (d) { return d.name + ' in open-angle glaucoma'; }, segs: merge(AQ, TR), pre: PRE_TR,
      steps: [
        { h: 'Open-angle glaucoma', p: 'The angle is open, but the trabeculum drains poorly, so the IOP is already up: {from} mm Hg.', lit: ['trab'], fx: { iop: 'from' }, note: nSwitched },
        { h: 'Cycloplegia and mydriasis', p: '{name} blocks M3: the ciliary muscle relaxes and the pupil dilates.', lit: ['cb', 'iris'], fx: { iris: 'd', iop: 'from' } },
        { h: 'The drain narrows', p: 'The relaxed ciliary muscle stops pulling the trabeculum and the canal of Schlemm open, and the thick iris crowds the angle.', lit: ['trab', 'schlemm'], fx: { iris: 'd', c: 'narrow', iop: 'from' } },
        { h: 'The pressure rises', p: 'IOP: {from} → {to} mm Hg, and the optic nerve is damaged faster.', fx: { iris: 'd', c: 'narrow', iop: 'to' }, note: nContra }
      ],
      fixLabel: 'Use instead: ', fix: [['timo', 'less aqueous'], ['latano', 'the most potent']] },
    'wi-echo': { what: true, map: 'angle', cond: 'closed', iris: 'nr', kick: 'CONTRAINDICATED · WHAT IF IT IS USED?', title: function (d) { return d.name + ' in closed-angle glaucoma'; }, segs: merge(AQ, TR), pre: PRE_TR,
      steps: [
        { h: 'A narrow angle', p: 'In closed-angle glaucoma the iris root lies close to the trabeculum, so the way out for aqueous is narrow. IOP now: {from} mm Hg.', lit: ['trab', 'iris'], fx: { iris: 'nr', iop: 'from' }, note: nSwitched },
        { h: 'Extreme miosis', p: '{name} blocks cholinesterase for good: the pupil becomes very small and the vessels of the iris congest.', lit: ['iris', 'pupil'], fx: { iris: 'm0', iop: 'from' } },
        { h: 'Pupillary block', p: 'The tight, swollen iris presses on the lens, so aqueous can no longer pass from the posterior to the anterior chamber.', lit: ['pc', 'pupil'], fx: { iris: 'm0', c: 'pblock', iop: 'from' } },
        { h: 'The iris bows forward', p: 'Aqueous builds up behind the iris and pushes it forward onto the trabeculum (iris bombé): the angle closes.', lit: ['iris', 'trab'], fx: { iris: 'm', c: ['pblock', 'x', 'block'], iop: 'from' } },
        { h: 'The pressure rises', p: 'IOP: {from} → {to} mm Hg. Pilocarpine, a direct miotic that wears off, is used in closed angle instead.', fx: { iris: 'm', c: ['pblock', 'x', 'block'], iop: 'to' }, note: nContra }
      ],
      fixLabel: 'Use instead: ', fix: [['pilo', 'a direct miotic'], ['mann', 'osmotic, works fast']] },
    'wi-dexa': { what: true, map: 'angle', cond: 'open', kick: 'NOT IN GLAUCOMA · WHAT IF IT IS USED?', title: function (d) { return d.name + ' in glaucoma'; }, segs: merge(AQ, TR), pre: PRE_TR,
      steps: [
        { h: 'Open-angle glaucoma', p: 'The angle is open, but the trabeculum drains poorly, so the IOP is already up: {from} mm Hg.', lit: ['trab'], fx: { iop: 'from' }, note: nSwitched },
        { h: 'Steroid drops reach the drain', p: 'Corticosteroids make the cells of the trabecular meshwork lay down more matrix, so its gaps clog.', lit: ['trab'], fx: { c: 'clog', iop: 'from' } },
        { h: 'Less drains', p: 'Aqueous filters through the meshwork even more slowly.', lit: ['trab', 'schlemm'], fx: { c: ['clog', 'narrow'], iop: 'from' } },
        { h: 'Steroid glaucoma', p: 'IOP: {from} → {to} mm Hg. With long use, steroid drops also cause cataract.', lit: ['lens'], fx: { c: ['clog', 'narrow'], iop: 'to' }, note: nContra }
      ],
      fixLabel: 'Treat the pressure: ', fix: [['timo', 'less aqueous'], ['latano', 'the most potent']] },
    'wi-timo': { what: true, map: 'body', kick: 'CONTRAINDICATED · WHAT IF IT IS USED?', title: 'Timolol in asthma or heart disease', segs: BODY,
      steps: [
        { h: 'A drop in the eye', p: 'Timolol drops lower the IOP by making less aqueous. But not all of a drop stays in the eye.', lit: ['drop', 'eye'] },
        { h: 'Down the tear duct', p: 'The extra runs through the nasolacrimal duct into the nose.', go: ['b1'], lit: ['duct', 'nose'] },
        { h: 'Into the blood, past the liver', p: 'The nasal mucosa absorbs it straight into the veins. It skips the liver (no first-pass metabolism), so it reaches the heart and lungs almost as if it had been injected.', go: ['b2'], lit: ['liver', 'heart'] },
        { h: 'Lungs: β2 blocked', p: 'It blocks β2 receptors on the bronchial muscle, so the bronchi constrict. In asthma this can set off a severe attack: wheeze and breathlessness.', go: ['b3a', 'b3b'], lit: ['lungs'], fx: { c: 'bronch' } },
        { h: 'Heart: β1 blocked', p: 'It blocks β1 in the heart: a slow heart (bradycardia), heart block, and heart failure gets worse.', lit: ['heart'], fx: { c: ['bronch', 'brady'] },
          note: function () { return N('Contraindicated in asthma and in cardiac patients. Pressing on the inner corner of the eye for a minute after the drop keeps more of it in the eye.', 'bad'); } }
      ],
      fixLabel: 'Use instead: ', fix: [['latano', 'no β-blockade'], ['brimo', 'α2 agonist']] }
  };
  var WHATIF = { atro: 'wi-angle', tropi: 'wi-angle', phen: 'wi-angle', coca: 'wi-angle', echo: 'wi-echo', dexa: 'wi-dexa', timo: 'wi-timo' };
  var GUIDE_HTML = '<section class="sl-guide" hidden aria-label="Follow it step by step">' +
    '<div class="sl-ghead"><div><span class="ux-kicker sl-gkick"></span><h4 class="sl-gtitle"></h4></div><button type="button" class="sl-gx" aria-label="Close">✕</button></div>' +
    '<svg class="sl-gmap" role="img"></svg>' +
    '<div class="sl-gbody" aria-live="polite"><span class="sl-gnum"></span><b class="sl-gh"></b><p class="sl-gp"></p><p class="sl-gnote" hidden></p></div>' +
    '<div class="sl-gnav"><button type="button" class="sl-gbtn sl-gprev" aria-label="Back a step">‹</button><div class="sl-gdots"></div><button type="button" class="sl-gbtn sl-gnext"></button></div>' +
    '<div class="sl-gmore"></div></section>';
  function tl(x, y, txt, g, cls, anchor, bare) {   // a label on the cross-section that opens a walk
    return '<text x="' + x + '" y="' + y + '" class="sl-t sl-tl' + (cls || '') + '" data-guide="' + g + '"' + (anchor ? ' text-anchor="' + anchor + '"' : '') + (bare ? '' : ' role="button" tabindex="0"') + '>' + txt + (bare ? '' : '<tspan class="sl-tlc"> ›</tspan>') + '</text>';
  }
  /* The walk, shared by all the labs: open one, show a step (draw its part of the route, light its parts, change the
     picture), and step with › / ‹ / the dots / the arrow keys. getModel() gives the lab's current state for the notes
     and the maps; onRoute(r) lets a lab brighten the same route on its own picture. Any [data-guide] in the lab opens one. */
  function walker(host, getModel, onRoute) {
    var G = { id: null, k: 0, raf: 0, raf2: 0, sc: null, anim: false, drug: '' };
    var gEl = host.querySelector('.sl-guide'), gMap = gEl.querySelector('.sl-gmap');
    onRoute = onRoute || function () {};
    function quiet() { return document.documentElement.classList.contains('ux-motion-quiet') || !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); }
    function nameOf(m) { return (m.d && m.d.name) || ''; }
    function txt(v, m) {
      var s = typeof v === 'function' ? v(m.d, m, G.sc) : (v || '');
      return s.replace(/\{name\}/g, nameOf(m)).replace(/\{from\}/g, G.sc ? G.sc.from : '').replace(/\{to\}/g, G.sc ? G.sc.to : '');
    }
    function each(sel, fn) { Array.prototype.forEach.call(gMap.querySelectorAll(sel), fn); }
    function openGuide(id, sc) {
      var g = GUIDES[id]; if (!g) return;
      cancelAnimationFrame(G.raf); cancelAnimationFrame(G.raf2);
      G.id = id; G.k = 0; G.sc = sc || null; G.drug = ''; G.anim = false;
      var mp = GMAPS[g.map], idx = {}, base = '', segs = '', m = getModel();
      (g.pre || []).forEach(function (x) { idx[x] = -1; });
      g.steps.forEach(function (s, i) { (s.go || []).forEach(function (c) { [].concat(c).forEach(function (x) { idx[x] = i; }); }); });
      Object.keys(idx).forEach(function (x) {
        var sg = typeof g.segs[x] === 'function' ? g.segs[x](m) : g.segs[x];
        base += '<path d="' + sg[0] + '" class="g-base"/>';
        segs += '<path d="' + sg[0] + '" class="g-seg s-' + sg[1] + (idx[x] < 0 ? ' pre' : '') + '" data-sg="' + x + '" data-i="' + idx[x] + '"/>';
      });
      gEl.hidden = false;
      gEl.querySelector('.sl-gkick').textContent = g.kick;
      gEl.querySelector('.sl-gtitle').textContent = txt(g.title, m);
      gMap.setAttribute('viewBox', mp.vb); gMap.setAttribute('aria-label', txt(g.title, m)); gMap.setAttribute('class', 'sl-gmap g-' + g.map);
      gMap.innerHTML = mp.draw(g, m) + '<g>' + base + '</g><g>' + segs + '</g>' + (mp.top ? mp.top(g, m) : '') + '<g class="g-dots"></g>';
      if (m.pupil) gMap.style.setProperty('--pup', clamp(m.pupil / 4, 0.3, 1.9).toFixed(2));
      each('.g-seg', function (p) { var L = p.getTotalLength(); p.setAttribute('data-len', L); p.style.strokeDasharray = L + ' ' + L; p.style.strokeDashoffset = +p.getAttribute('data-i') < 0 ? 0 : L; });
      gEl.querySelector('.sl-gdots').innerHTML = g.steps.map(function (s, i) { return '<button type="button" data-gstep="' + i + '" aria-label="Step ' + (i + 1) + '"></button>'; }).join('');
      onRoute(g.route || null);
      showStep(0, false);
      var r = gEl.getBoundingClientRect();
      if (r.top < 70 || r.top > innerHeight - 200) gEl.scrollIntoView({ behavior: quiet() ? 'auto' : 'smooth', block: 'start' });
    }
    function closeGuide() { cancelAnimationFrame(G.raf); cancelAnimationFrame(G.raf2); G.id = null; G.anim = false; gEl.hidden = true; onRoute(null); }
    function go(k) {
      var g = GUIDES[G.id]; if (!g) return;
      if (k > g.steps.length - 1) k = 0;   // after the last step: from the start
      if (k < 0) return;
      showStep(k, k === G.k + 1);
    }
    function showStep(k, anim) {
      var g = GUIDES[G.id]; if (!g) return;
      cancelAnimationFrame(G.raf); G.anim = false;
      var m = getModel(), steps = g.steps, s = steps[k], last = steps.length - 1, stopAt = -1, i, n;
      G.k = k;
      for (i = 0; i <= last; i++) { n = steps[i].note && steps[i].note(m, G.sc); if (n && n.stop) { stopAt = i; break; } }
      var ghost = stopAt >= 0 && k > stopAt, chains = (s.go || []).map(function (c) { return [].concat(c); }), animate = !!(anim && chains.length && !quiet());
      each('.g-seg', function (p) {
        var si = +p.getAttribute('data-i'), L = +p.getAttribute('data-len');
        p.classList.toggle('ghost', stopAt >= 0 && si > stopAt);
        if (si >= 0) p.style.strokeDashoffset = si < k || (si === k && !animate) ? 0 : L;
      });
      var lit = s.lit || [], seen = [];
      for (i = 0; i < k; i++) seen = seen.concat(steps[i].lit || []);
      each('[data-node]', function (el) { var nd = el.getAttribute('data-node'); el.classList.toggle('on', lit.indexOf(nd) >= 0); el.classList.toggle('seen', lit.indexOf(nd) < 0 && seen.indexOf(nd) >= 0); });
      gEl.querySelector('.sl-gnum').textContent = 'Step ' + (k + 1) + ' of ' + steps.length;
      gEl.querySelector('.sl-gh').textContent = txt(s.h, m);
      gEl.querySelector('.sl-gp').textContent = txt(s.p, m);
      n = s.note && s.note(m, G.sc);
      if (!n && ghost) n = N('With ' + nameOf(m) + ', nothing gets this far: this is the path the signal would take.', 'bad');
      var ne = gEl.querySelector('.sl-gnote'); ne.hidden = !n; if (n) { ne.textContent = n.t; ne.className = 'sl-gnote ' + n.c; }
      gEl.querySelector('.sl-gprev').disabled = k === 0;
      gEl.querySelector('.sl-gnext').textContent = k === last ? 'From the start ↺' : k === 0 ? (g.map === 'brain' || g.map === 'aud' ? 'Follow the tract ›' : 'Follow it ›') : 'Next ›';
      Array.prototype.forEach.call(gEl.querySelectorAll('[data-gstep]'), function (b, j) { b.classList.toggle('done', j < k); if (j === k) b.setAttribute('aria-current', 'step'); else b.removeAttribute('aria-current'); });
      gEl.querySelector('.sl-gmore').innerHTML = k < last ? '' :
        (g.fix || []).map(function (f) { return '<button type="button" class="sl-gfix" data-drug="' + f[0] + '">' + esc(g.fixLabel || '') + esc(byId(f[0]).name) + (f[1] ? ' <small>' + esc(f[1]) + '</small>' : '') + ' ›</button>'; }).join('') +
        (g.more || []).map(function (x) { return '<button type="button" class="sl-gmo" data-guide="' + x[0] + '">' + esc(x[1]) + ' ›</button>'; }).join('');
      var fx = typeof s.fx === 'function' ? s.fx(m) : (s.fx || {});
      if (animate) { G.anim = true; run(chains, ghost, function () { G.anim = false; applyFx(fx, true); }); }
      else { heads(chains, ghost); applyFx(fx, anim); }
    }
    function run(chains, ghost, done) {   // draw each chain of segments with a dot running along its front
      var els = chains.map(function (c) { return c.map(function (x) { return gMap.querySelector('[data-sg="' + x + '"]'); }).filter(Boolean); });
      var tot = els.map(function (c) { return c.reduce(function (a, p) { return a + +p.getAttribute('data-len'); }, 0); });
      var dur = clamp(Math.max.apply(null, tot.concat([1])) * 6, 650, 1500), t0 = performance.now(), dl = gMap.querySelector('.g-dots');
      dl.innerHTML = ghost ? '' : els.map(function () { return '<circle r="4.5" class="g-dot"/>'; }).join('');
      var dots = dl.querySelectorAll('circle');
      function frame(now) {
        var e = Math.min(1, Math.max(0, now - t0) / dur), ee = e < 0.5 ? 2 * e * e : 1 - Math.pow(-2 * e + 2, 2) / 2;
        els.forEach(function (c, j) {
          var pos = ee * tot[j], acc = 0, placed = false;
          c.forEach(function (p) {
            var L = +p.getAttribute('data-len'), part = clamp(pos - acc, 0, L);
            p.style.strokeDashoffset = L - part;
            if (!placed && dots[j] && pos <= acc + L + 0.01) { var pt = p.getPointAtLength(part); dots[j].setAttribute('cx', pt.x.toFixed(1)); dots[j].setAttribute('cy', pt.y.toFixed(1)); placed = true; }
            acc += L;
          });
        });
        if (e < 1) G.raf = requestAnimationFrame(frame);
        else { Array.prototype.forEach.call(dots, function (d) { d.setAttribute('class', 'g-dot head'); }); done(); }
      }
      G.raf = requestAnimationFrame(frame);
    }
    function heads(chains, ghost) {   // a glowing dot where this step's route ends
      var h = '';
      if (!ghost) chains.forEach(function (c) {
        var p = gMap.querySelector('[data-sg="' + c[c.length - 1] + '"]'); if (!p) return;
        var pt = p.getPointAtLength(+p.getAttribute('data-len'));
        h += '<circle r="4.5" class="g-dot head" cx="' + pt.x.toFixed(1) + '" cy="' + pt.y.toFixed(1) + '"/>';
      });
      gMap.querySelector('.g-dots').innerHTML = h;
    }
    function applyFx(fx, anim) {
      var g = GUIDES[G.id]; if (!g) return;
      gMap.setAttribute('class', 'sl-gmap g-' + g.map + [].concat(fx.c || []).filter(Boolean).map(function (c) { return ' fx-' + c; }).join(''));
      var ip = gMap.querySelector('.am-iris');
      if (ip) { var ir = IRIS[fx.iris || g.iris || 'n']; ip.style.d = 'path("' + ir[0] + '")'; ip.setAttribute('d', ir[0]); ip.style.strokeWidth = ir[1] + 'px'; ip.style.stroke = ir[2]; }
      var gauge = gMap.querySelector('.am-iop');
      if (gauge) { var v = fx.iop && G.sc ? G.sc[fx.iop] : null; gauge.classList.toggle('on', v != null); if (v != null) setIop(v, anim); }
    }
    function setIop(v, anim) {   // the gauge counts up to the new pressure
      var el = gMap.querySelector('.am-iopv'), from = el.getAttribute('data-v') ? +el.getAttribute('data-v') : v, t0 = performance.now();
      cancelAnimationFrame(G.raf2); el.setAttribute('data-v', v);
      function paint(x) { el.textContent = Math.round(x) + ' mm Hg'; el.setAttribute('class', 'am-iopv ' + (x <= 25 ? 'ok' : x <= 35 ? 'mid' : 'bad')); }
      if (!anim || quiet() || from === v) { paint(v); return; }
      (function f(now) { var e = Math.min(1, Math.max(0, now - t0) / 900); paint(from + (v - from) * e); if (e < 1) G.raf2 = requestAnimationFrame(f); })(t0);
    }
    host.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target : null; if (!t) return;
      var gd = t.closest('[data-guide]'); if (gd) { openGuide(gd.getAttribute('data-guide')); return; }
      if (!G.id || !gEl.contains(t)) return;
      if (t.closest('.sl-gx')) { closeGuide(); return; }
      if (t.closest('.sl-gnext')) { go(G.k + 1); return; }
      if (t.closest('.sl-gprev')) { go(G.k - 1); return; }
      var sd = t.closest('[data-gstep]'); if (sd) go(+sd.getAttribute('data-gstep'));
    });
    host.addEventListener('keydown', function (e) {   // labels on the pictures and the reflex rows work from the keyboard; arrows step the walk
      var t = e.target;
      if ((e.key === 'Enter' || e.key === ' ') && t.getAttribute && t.getAttribute('data-guide') && t.tagName !== 'BUTTON') { e.preventDefault(); openGuide(t.getAttribute('data-guide')); return; }
      if (G.id && gEl.contains(t) && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) { e.preventDefault(); go(G.k + (e.key === 'ArrowRight' ? 1 : -1)); }
    });
    return { G: G, open: openGuide, close: closeGuide,
      refresh: function () { if (G.id && !G.anim) showStep(G.k, false); },
      stop: function () { cancelAnimationFrame(G.raf); cancelAnimationFrame(G.raf2); } };
  }

  /* ---- the physiology walks: what light does in the retina, the visual pathway, from the eardrum to the cochlear nerve,
     and the auditory pathway. From physio 01 Vision (light transduction, the neural network, ganglion cells), anat 01
     (the visual pathway) and physio 02 Hearing (impedance matching, the scalae, hair cells, the place principle). ---- */
  function rtLab(x, y, node, t, sub, cls) { return gLab(x, y, node, t) + (sub ? '<text x="' + x + '" y="' + (y + 10) + '" class="rt-sub' + (cls || '') + '">' + sub + '</text>' : ''); }
  function rtNode(y, node, sym) { return '<circle cx="232" cy="' + y + '" r="12" class="rt-node" data-node="' + node + '"/><text x="232" y="' + (y + 3) + '" class="rt-sym">' + sym + '</text>'; }
  GMAPS.retina = { vb: '0 0 380 300', draw: function () {
    var h = '<rect width="380" height="300" fill="#0d1422"/>', cols = [96, 136, 176];
    // the retina, light coming in from the top (the vitreous side)
    h += '<path d="M80 24 L200 24" class="rt-axon"/><path d="M96 36 L96 24 M156 36 L156 24" class="rt-axon"/>' +
      '<path d="M96 83 L96 52 M136 83 L152 51 M176 83 L160 51 M96 132 L96 109 M136 132 L136 109 M176 132 L176 109" class="rt-wire"/>' +
      '<circle cx="96" cy="44" r="8" class="rt-cell" data-node="gan"/><circle cx="156" cy="44" r="8" class="rt-cell" data-node="gan"/>' +
      '<ellipse cx="126" cy="64" rx="14" ry="4" class="rt-cell" data-node="ama"/>' +
      cols.map(function (x) { return '<ellipse cx="' + x + '" cy="96" rx="6" ry="13" class="rt-cell" data-node="bip"/>'; }).join('') +
      '<ellipse cx="136" cy="124" rx="40" ry="4" class="rt-cell" data-node="hor"/>' +
      cols.map(function (x) { return '<circle cx="' + x + '" cy="136" r="4" class="rt-term" data-node="term"/><rect x="' + (x - 6) + '" y="142" width="12" height="38" rx="4" class="rt-inner"/>'; }).join('') +
      '<g data-node="rod"><rect x="91" y="182" width="10" height="50" rx="2" class="rt-outer"/><path d="M91 188 H101 M91 194 H101 M91 200 H101 M91 206 H101 M91 212 H101 M91 218 H101 M91 224 H101" class="rt-disk"/></g>' +
      '<path d="M130 182 L142 182 L136 224 Z" class="rt-outer cone"/>' +
      '<rect x="171" y="182" width="10" height="50" rx="2" class="rt-outer"/><path d="M171 190 H181 M171 198 H181 M171 206 H181 M171 214 H181 M171 222 H181" class="rt-disk"/>' +
      '<rect x="70" y="236" width="130" height="14" class="rt-pe" data-node="pe"/><rect x="70" y="250" width="130" height="14" class="rt-ch"/>' +
      gLab(104, 12, 'vit', 'Vitreous: light comes in ↓') + gLab(198, 34, 'on', 'to the optic nerve', 'end') +
      gLab(4, 47, 'gan', 'Ganglion cells') + gLab(4, 67, 'ama', 'Amacrine') + gLab(4, 99, 'bip', 'Bipolar cells') + gLab(4, 127, 'hor', 'Horizontal') +
      gLab(4, 200, 'rod', 'Rods & cones') + gLab(4, 242, 'pe', 'Pigment') + gLab(4, 252, 'pe', 'epithelium') + '<text x="4" y="282" class="rt-sub">signals travel back up ↑</text>';
    // inside the rod: the cascade
    h += '<rect x="208" y="6" width="166" height="288" rx="12" class="rt-inset"/><text x="291" y="22" class="rt-title">INSIDE THE ROD</text>' +
      rtNode(52, 'rho', 'Rh') + rtNode(98, 'trd', 'T') + rtNode(144, 'pde', 'PDE') + rtNode(190, 'na', 'Na⁺') + rtNode(236, 'mv', 'mV') + rtNode(278, 'glu', 'Glu') +
      rtLab(250, 50, 'rho', 'Rhodopsin', '11-cis → all-trans retinal') + rtLab(250, 96, 'trd', 'Transducin', 'a G protein, switched on') +
      rtLab(250, 142, 'pde', 'Phosphodiesterase', 'cGMP → 5′-GMP: cGMP falls') +
      gLab(250, 188, 'na', 'Na⁺ channels') + '<text x="250" y="198" class="rt-sub rt-dark rt-na">open: Na⁺ leaks in (dark)</text><text x="250" y="198" class="rt-sub rt-lit rt-na">closed: no Na⁺ comes in</text>' +
      gLab(250, 234, 'mv', 'Membrane potential') + '<text x="250" y="244" class="rt-sub rt-dark rt-mv">−40 mV (dark)</text><text x="250" y="244" class="rt-sub rt-lit rt-mv">−70 mV: hyperpolarised</text>' +
      gLab(250, 276, 'glu', 'Glutamate release') + '<text x="250" y="286" class="rt-sub rt-dark rt-glu">steady in the dark</text><text x="250" y="286" class="rt-sub rt-lit rt-glu">less: the rod is OFF</text>';
    return h;
  } };
  GMAPS.ear = { vb: '0 0 380 300', draw: function (g, m) {
    var xp = 146 + clamp(m && m.p != null ? m.p : 0.5, 0, 1) * 210;
    return '<rect width="380" height="300" fill="#0d1422"/>' +
      // outer and middle ear (air), the windows, the cochlea unrolled
      '<path d="M30 40 C6 46 6 82 24 88 C10 96 12 128 32 132" class="ea-pinna" data-node="pinna"/>' +
      '<rect x="28" y="77" width="58" height="18" rx="4" class="ea-canal" data-node="canal"/><rect x="88" y="50" width="50" height="80" rx="12" class="ea-mid"/>' +
      '<ellipse cx="89" cy="86" rx="3" ry="22" class="ea-drum" data-node="drum"/>' +
      '<g class="ea-oss" data-node="oss"><path d="M92 72 L104 62 L112 72"/><path d="M112 72 L122 80 L118 90"/><path d="M118 90 L131 90 M131 81 L131 99"/></g>' +
      '<ellipse cx="136" cy="90" rx="3" ry="8" class="ea-win" data-node="oval"/><ellipse cx="136" cy="118" rx="3" ry="6" class="ea-win" data-node="round"/>' +
      '<rect x="140" y="70" width="232" height="66" rx="14" class="ea-coch"/><path d="M140 92 L356 92 L356 112 L140 112 Z" class="ea-media" data-node="sm"/>' +
      '<path d="M140 92 L356 92" class="ea-reis"/><path d="M140 112 L356 112" class="ea-bm" data-node="bm"/>' +
      '<path d="M' + (xp - 16) + ' 112 Q' + xp + ' 98 ' + (xp + 16) + ' 112" class="ea-peak"/><path d="M' + xp + ' 114 L170 158 M' + xp + ' 114 L210 158" class="ea-zoom"/>' +
      gLab(4, 30, 'pinna', 'Pinna') + gLab(57, 72, 'canal', 'Canal', 'middle') + gLab(113, 46, 'oss', 'Ossicles', 'middle') + gLab(89, 124, 'drum', 'Drum', 'middle') +
      gLab(116, 146, 'oval', 'Oval window', 'middle') + gLab(146, 64, 'base', 'Base: high notes') + gLab(370, 64, 'apex', 'Apex (helicotrema): low', 'end') +
      gLab(150, 89, 'sv', 'Scala vestibuli · perilymph') + gLab(150, 106, 'sm', 'Scala media · endolymph (high K⁺)') + gLab(150, 132, 'st', 'Scala tympani · perilymph') +
      // the organ of Corti, zoomed in
      '<rect x="16" y="158" width="348" height="138" rx="12" class="ea-inset"/><text x="190" y="172" class="rt-title">ORGAN OF CORTI · ZOOMED IN</text>' +
      '<rect x="18" y="178" width="344" height="40" class="ea-endo" data-node="endo"/>' +
      '<path d="M60 202 L100 202" class="ea-tm"/><rect x="100" y="198" width="170" height="9" rx="4" class="ea-tm" data-node="tm"/>' +
      '<g class="ea-ohc" data-node="ohc"><rect x="230" y="224" width="12" height="34" rx="5"/><rect x="248" y="224" width="12" height="34" rx="5"/><rect x="266" y="224" width="12" height="34" rx="5"/><path d="M236 224 V207 M254 224 V207 M272 224 V207"/></g>' +
      '<rect x="178" y="220" width="24" height="42" rx="10" class="ea-hc" data-node="hc"/><circle cx="190" cy="242" r="4" class="ea-nuc"/>' +
      '<g class="ea-cilia" data-node="hc"><path d="M183 220 L183 209 M190 220 L190 207 M197 220 L197 205"/></g>' +
      '<path d="M40 266 L340 266" class="ea-bm2" data-node="bm"/>' +
      '<g class="ea-k" data-node="kplus"><circle cx="216" cy="186" r="7"/><text x="216" y="189">K⁺</text></g>' +
      '<g class="ea-ca" data-node="ca"><circle cx="170" cy="255" r="7"/><text x="170" y="258">Ca</text></g>' +
      '<g class="ea-glu" data-node="glu"><circle cx="186" cy="262" r="2"/><circle cx="192" cy="265" r="2"/><circle cx="198" cy="262" r="2"/></g>' +
      '<path d="M196 266 C222 282 280 290 350 290" class="ea-nerve" data-node="cn"/>' +
      gLab(104, 194, 'tm', 'Tectorial membrane') + gLab(284, 192, 'endo', 'Endolymph: high K⁺') + gLab(166, 236, 'hc', 'Inner hair cell', 'end') +
      gLab(290, 238, 'ohc', 'Outer hair') + gLab(290, 248, 'ohc', 'cells') + gLab(44, 280, 'bm', 'Basilar membrane') + gLab(352, 283, 'cn', 'Cochlear nerve', 'end');
  } };
  GMAPS.aud = { vb: '0 0 380 300', draw: function () {
    function ear(node, x) { return '<g class="au-ear" data-node="' + node + '" transform="translate(' + x + ' 252)"><path d="M-12 0 a12 12 0 1 0 24 0 a9 9 0 1 0 -18 0 a6 6 0 1 0 12 0"/></g>'; }
    return '<rect width="380" height="300" fill="#0d1422"/><ellipse cx="190" cy="150" rx="176" ry="138" class="bm-brain"/>' +
      '<ellipse cx="74" cy="56" rx="46" ry="18" class="au-ctx" data-node="ac41"/><ellipse cx="306" cy="56" rx="46" ry="18" class="au-ctx" data-node="ac41"/>' +
      '<rect x="150" y="128" width="80" height="166" rx="22" class="bm-region" data-node="bs"/>' +
      '<text x="190" y="176" class="bm-rl">Midbrain</text><text x="190" y="236" class="bm-rl">Pons</text><text x="190" y="282" class="bm-rl">Medulla</text>' +
      gNode(150, 100, 'mgb') + gNode(230, 100, 'mgb') + gNode(172, 150, 'ic') + gNode(208, 150, 'ic') + gNode(170, 214, 'soc') + gNode(210, 214, 'soc') + gNode(166, 252, 'cnuc') + gNode(214, 252, 'cnuc') +
      ear('earL', 26) + ear('earR', 354) +
      gLab(190, 22, 'ac41', 'Auditory cortex (area 41), temporal lobes', 'middle') + gLab(238, 116, 'mgb', 'Medial geniculate bodies') + gLab(238, 154, 'ic', 'Inferior colliculi') +
      gLab(238, 186, 'll', 'Lateral lemniscus') + gLab(238, 218, 'soc', 'Superior olivary nuclei') + gLab(238, 256, 'cnuc', 'Cochlear nuclei') + gLab(36, 276, 'nerve', 'Cochlear nerve (VIII)');
  } };

  function nLight(m) {
    return m.lux != null && m.lux < 25 ? N('Dim light: this is the rods’ job. Rhodopsin is very sensitive and up to 300 rods share one ganglion cell, so you see in shades of grey, but not sharply.')
      : N('In daylight the cones do the same with their own pigments (iodopsin: red 560, green 530, blue 420 nm). That gives colour, and in the fovea sharp detail.');
  }
  function fmtHz(f) { return f >= 1000 ? (f / 1000).toFixed(f >= 10000 ? 0 : 1) + ' kHz' : Math.round(f) + ' Hz'; }
  var RT_FX = ['naclosed', 'hyper', 'lessglu'];
  GUIDES.photo = { map: 'retina', kick: 'WHEN LIGHT FALLS ON THE RETINA', title: 'From light to a nerve signal', segs: {
      lt: ['M96 4 L96 182', 'light'], c1: ['M101 206 C150 206 180 52 220 52', 'light'],
      c2: ['M232 64 L232 86', 'mid'], c3: ['M232 110 L232 132', 'mid'], c4: ['M232 156 L232 178', 'mid'], c5: ['M232 202 L232 224', 'mid'], c6: ['M232 248 L232 266', 'mid'],
      n1: ['M96 132 L96 109', 'sig'], n2: ['M96 132 C104 127 116 125 128 124', 'sig'], n3: ['M96 83 L96 52', 'sig'], n4: ['M96 36 L96 24 L198 24', 'sig'] },
    steps: [
      { h: 'Light reaches the retina', p: 'Focused by the cornea and the lens, light arrives at the retina from the inside: the vitreous side.', lit: ['vit'] },
      { h: 'Through the retina to the rods and cones', p: 'The rods and cones lie deepest, so light first passes through the ganglion cells and the neural network. Behind them the pigment epithelium (melanin) soaks up stray light, so the image stays sharp.', go: ['lt'], lit: ['gan', 'bip', 'rod', 'pe'] },
      { h: 'Rhodopsin catches the light', p: 'In the disks of the rod’s outer segment, light changes the shape of retinal in rhodopsin: 11-cis retinal becomes all-trans retinal (metarhodopsin II).', go: ['c1'], lit: ['rod', 'rho'], note: nLight },
      { h: 'Transducin switches on', p: 'Metarhodopsin II activates transducin, a G protein.', go: ['c2'], lit: ['trd'] },
      { h: 'cGMP falls', p: 'Transducin activates phosphodiesterase, which breaks cyclic GMP down to 5′-GMP, so cGMP falls.', go: ['c3'], lit: ['pde'] },
      { h: 'The Na⁺ channels close', p: 'In the dark, cGMP holds the Na⁺ channels of the outer segment open, so Na⁺ leaks in all the time. With less cGMP they close.', go: ['c4'], lit: ['na'], fx: { c: RT_FX.slice(0, 1) } },
      { h: 'The rod hyperpolarises', p: 'With no Na⁺ coming in, the membrane potential falls from about −40 mV to −70 mV. Light switches the photoreceptor OFF.', go: ['c5'], lit: ['mv'], fx: { c: RT_FX.slice(0, 2) } },
      { h: 'Less glutamate', p: 'Hyperpolarised, the synaptic body at the base of the rod releases less glutamate onto the bipolar and horizontal cells.', go: ['c6'], lit: ['glu', 'term'], fx: { c: RT_FX } },
      { h: 'Bipolar and horizontal cells', p: 'Some bipolar cells depolarise and excite their ganglion cell; others hyperpolarise and inhibit it. Horizontal cells spread the signal sideways and inhibit nearby bipolar cells: lateral inhibition sharpens the edges of the image. These short cells use electrotonic spread, not action potentials.', go: ['n1', 'n2'], lit: ['bip', 'hor'], fx: { c: RT_FX } },
      { h: 'The ganglion cells fire', p: 'Ganglion cells fire about 5 action potentials a second even unstimulated; their input pushes the rate up or down. Amacrine cells add sideways processing. In the fovea about one cone feeds one ganglion cell (acuity); up to 300 rods share one (sensitivity).', go: ['n3'], lit: ['gan', 'ama'], fx: { c: RT_FX } },
      { h: 'Into the optic nerve', p: 'The ganglion cell axons run over the inner surface of the retina to the optic disc and leave the eye as the optic nerve.', go: ['n4'], lit: ['on'], fx: { c: RT_FX } }
    ],
    more: [['seeing', 'Follow it to the visual cortex'], ['light', 'The light reflex']] };
  GUIDES.seeing = { map: 'brain', kick: 'THE VISUAL PATHWAY · FOLLOW THE TRACT', title: 'From the retina to the visual cortex', segs: BR,
    steps: [
      { h: 'Both retinas send signals', p: 'The ganglion cells of each eye fire as the image falls on the retina.', lit: ['eyeL', 'eyeR'] },
      { h: 'Along the optic nerves', p: 'Their axons leave each eye as the optic nerve (II) and pass back through the optic canal.', go: ['onL', 'onR'], lit: ['on', 'chiasm'] },
      { h: 'The optic chiasma', p: 'The fibres from the nasal half of each retina cross to the other side; the temporal fibres stay on the same side. So the left optic tract carries the left half of each retina, which sees the right half of the world.', lit: ['chiasm'] },
      { h: 'Optic tracts to the lateral geniculate body', p: 'Each optic tract winds round the crus cerebri to the lateral geniculate body (LGB) of the thalamus, where it relays.', go: ['otL', 'otR'], lit: ['ot', 'lgb'] },
      { h: 'Optic radiation to the visual cortex', p: 'From the LGB the optic radiation runs back: the upper fibres through the parietal lobe, the lower fibres (Meyer’s loop) through the temporal lobe, to the visual cortex (area 17) in the occipital lobe.', go: ['radL', 'radR'], lit: ['a17'] },
      { h: 'The visual cortex sees', p: 'Area 17 builds the picture. Each half of the cortex sees the opposite half of the visual field, so a lesion behind the chiasma blinds the same half of both fields.', lit: ['a17'] }
    ],
    more: [['photo', 'What light does in the retina'], ['near', 'The near reflex'], ['light', 'The light reflex']] };
  var EA_FX = ['drum', 'oss', 'flu', 'wave', 'bend', 'kin', 'glu', 'fire'];
  GUIDES.sound = { map: 'ear', kick: 'WHEN SOUND REACHES THE EAR', title: 'From the eardrum to the cochlear nerve', segs: {
      s1: ['M2 86 L86 86', 'snd'], s2: ['M91 72 L104 62 L112 72 L122 80 L118 90 L130 90', 'snd'], s3: ['M139 88 C144 84 148 78 156 76', 'flu'],
      s4a: ['M156 76 L362 76', 'flu'], s4b: ['M362 76 C376 88 376 108 362 118', 'flu'], s4c: ['M362 118 L140 118', 'flu'],
      s5: function (m) { return ['M146 112 L' + (146 + clamp(m.p != null ? m.p : 0.5, 0, 1) * 210).toFixed(1) + ' 112', 'bm']; },
      s6: ['M190 268 L190 216', 'flu'], s7: ['M214 186 C208 194 200 204 194 212', 'k'], s8: ['M190 230 L190 260', 'k'], s9: ['M196 266 C222 282 280 290 350 290', 'nerve'] },
    steps: [
      { h: 'Sound waves arrive', p: 'The pinna collects the sound waves and directs them down the external auditory meatus. The outer and middle ear are filled with air.', lit: ['pinna', 'canal'] },
      { h: 'The tympanic membrane vibrates', p: 'The pressure waves push the drum in and out at the same frequency as the sound.', go: ['s1'], lit: ['drum'], fx: { c: EA_FX.slice(0, 1) },
        note: function (m) { return m.cond === 'cond' ? N('Conductive deafness: wax in the canal or a perforated drum stops much of the sound here. Bone conduction skips this part, so it stays normal.', 'bad') : null; } },
      { h: 'The ossicles pass it on', p: 'Malleus → incus → stapes. The large drum pressing on the small oval window concentrates the force, and the ossicles add a lever: impedance matching, needed because fluid resists movement far more than air.', go: ['s2'], lit: ['oss'], fx: { c: EA_FX.slice(0, 2) },
        note: function (m) { return m.cond === 'cond' ? N('Stiff ossicles (otosclerosis) are another cause of conductive deafness: less movement reaches the oval window.', 'bad') : null; } },
      { h: 'The stapes rocks the oval window', p: 'The footplate of the stapes sits in the oval window. As it rocks, it pushes the perilymph of the scala vestibuli.', go: ['s3'], lit: ['oval', 'sv'], fx: { c: EA_FX.slice(0, 2) } },
      { h: 'The fluids of the cochlea move', p: 'The pressure wave runs through the perilymph (scala vestibuli → helicotrema → scala tympani) and moves Reissner’s membrane, the endolymph of the scala media and the basilar membrane with it. Fluid cannot be squeezed, so the round window bulges out each time the oval window goes in.', go: [['s4a', 's4b', 's4c']], lit: ['sv', 'sm', 'st', 'round'], fx: { c: EA_FX.slice(0, 3) } },
      { h: 'The basilar membrane peaks at one place', p: function (d, m) { return 'A travelling wave runs along the basilar membrane and peaks where the membrane matches the pitch: the narrow, stiff base for high notes, the wide, flexible apex for low notes (the place principle). This ' + fmtHz(m.f || 1000) + ' tone peaks ' + (m.place || 'in the middle') + '.'; }, go: ['s5'], lit: ['bm'], fx: { c: EA_FX.slice(0, 4) } },
      { h: 'The hair cells bend', p: 'The hair cells sit on the basilar membrane with their cilia in the tectorial membrane. The basilar membrane is more elastic, so as it moves the cilia are bent by a shearing force.', go: ['s6'], lit: ['hc', 'tm', 'bm'], fx: { c: EA_FX.slice(0, 5) } },
      { h: 'K⁺ flows in from the endolymph', p: 'Bending one way raises the K⁺ conductance: K⁺ from the endolymph flows in and depolarises the hair cell. Bending the other way hyperpolarises it. This oscillating receptor potential is the cochlear microphonic.', go: ['s7'], lit: ['kplus', 'endo', 'hc'], fx: { c: EA_FX.slice(0, 6) },
        note: function (m) { return m.cond === 'sn' ? N('Sensorineural deafness: if these hair cells (or the cochlear nerve) are damaged, the wave arrives but nothing is sent on. Air and bone conduction both fall, often worst for high notes.', 'bad') : null; } },
      { h: 'Ca²⁺ in, glutamate out', p: 'Depolarisation opens voltage-gated Ca²⁺ channels at the base of the cell. Ca²⁺ enters and glutamate is released onto the cochlear nerve fibre.', go: ['s8'], lit: ['ca', 'glu'], fx: { c: EA_FX.slice(0, 7) } },
      { h: 'The cochlear nerve fires', p: 'Action potentials run along the cochlear nerve (VIII). Inner hair cells send the signal; outer hair cells change length (shorter when depolarised) and make sounds louder and clearer.', go: ['s9'], lit: ['cn', 'ohc'], fx: { c: EA_FX },
        note: function (m) { return m.eff == null ? null : m.eff > 0 ? N('At ' + m.db + ' dB this tone is heard: louder sounds make each fibre fire faster and bring in more fibres.') : N('At ' + m.db + ' dB this tone is too quiet at this pitch: the hair cells barely bend, so the nerve stays at rest.', 'bad'); } }
    ],
    more: [['audpath', 'Follow it to the auditory cortex']] };
  GUIDES.audpath = { map: 'aud', kick: 'THE AUDITORY PATHWAY · FOLLOW THE TRACT', title: 'From the cochlea to the auditory cortex', segs: {
      a1: ['M40 252 C80 258 120 256 166 252', 'in'], a2L: ['M166 252 C168 238 169 226 170 214', 'mid'], a2R: ['M166 252 C184 242 198 228 210 214', 'mid'],
      a3L: ['M170 214 C158 192 158 170 172 150', 'mid'], a3R: ['M210 214 C222 192 222 170 208 150', 'mid'],
      a4L: ['M172 150 C166 132 158 114 150 100', 'mid'], a4R: ['M208 150 C214 132 222 114 230 100', 'mid'],
      a5L: ['M150 100 C130 84 104 68 80 60', 'mid'], a5R: ['M230 100 C250 84 276 68 300 60', 'mid'] },
    steps: [
      { h: 'Signals leave the cochlea', p: 'The inner hair cells drive the fibres of the cochlear nerve (VIII), which carries the signal into the brainstem.', lit: ['earL'] },
      { h: 'The cochlear nuclei', p: 'The cochlear nerve enters the brainstem and relays in the cochlear nuclei, where the pons meets the medulla.', go: ['a1'], lit: ['nerve', 'cnuc'] },
      { h: 'Superior olivary nuclei of both sides', p: 'From here fibres reach the superior olivary nuclei of both sides, so from this point each ear is heard on both sides. Here the two ears are first compared.', go: ['a2L', 'a2R'], lit: ['soc'] },
      { h: 'Up the lateral lemniscus', p: 'The fibres climb in the lateral lemniscus to the inferior colliculi of the midbrain.', go: ['a3L', 'a3R'], lit: ['ll', 'ic'] },
      { h: 'The medial geniculate body', p: 'Next relay: the medial geniculate body of the thalamus. With the cortex it works out where a sound comes from, from the time lag and the difference in intensity between the two ears.', go: ['a4L', 'a4R'], lit: ['mgb'] },
      { h: 'The auditory cortex', p: 'The auditory radiation ends in the primary auditory cortex (area 41) of the temporal lobe, where the sound is heard. Both sides get input from both ears, so damage to one side does not make one ear deaf.', go: ['a5L', 'a5R'], lit: ['ac41'] }
    ],
    more: [['sound', 'From the eardrum to the nerve']] };
  var WALKS = {
    vision: [['photo', 'When light falls on the retina', 'rhodopsin → cGMP → Na⁺ → the ganglion cells'], ['seeing', 'From the retina to the visual cortex', 'optic nerve, chiasma, tract, LGB, radiation'],
      ['light', 'The light reflex', 'to the midbrain and back to both pupils'], ['near', 'The near reflex', 'the 3 Cs: convergence, constriction, curvature']],
    hearing: [['sound', 'When sound reaches the ear', 'drum → ossicles → fluids → hair cells → nerve'], ['audpath', 'From the cochlea to the auditory cortex', 'cochlear nuclei, olive, lemniscus, colliculus, MGB']]
  };
  function walksHtml(list) { return '<div class="sl-walks" aria-label="Follow it step by step">' + list.map(function (w) { return '<button type="button" class="sl-walk" data-guide="' + w[0] + '"><b>' + w[1] + ' ›</b><small>' + w[2] + '</small></button>'; }).join('') + '</div>'; }

  function eyeDrugs(host) {
    var st = { drug: 'none', cond: 'healthy', flash: 0, blink: 0, look: 0 }, timers = [], W = null;
    var groups = [];
    DRUGS.forEach(function (d) { if (groups.indexOf(d.grp) < 0) groups.push(d.grp); });
    host.innerHTML = head('PHARMACOLOGY / THE EYE', 'Eye drugs', 'Put a drug in the eye. See what happens to the pupil, the reflexes, focusing and the pressure, which receptor it acts on, and whether it treats or worsens glaucoma.') +
      '<div class="sl-drugs" role="group" aria-label="Choose a drug">' + groups.map(function (g) {
        return '<div class="sl-dgroup"><span class="sl-flabel">' + g + '</span><div>' + DRUGS.filter(function (d) { return d.grp === g; }).map(function (d) {
          return '<button type="button" data-drug="' + d.id + '" aria-pressed="' + (d.id === st.drug) + '">' + d.name + '</button>';
        }).join('') + '</div></div>';
      }).join('') + '</div>' +
      '<div class="ux-labgrid sl-eyegrid"><div class="ux-scope"><span class="ux-kicker">LIVE MODEL · FRONT VIEW AND ANTERIOR SEGMENT</span><div class="sl-two"><svg class="sl-svg sl-front" viewBox="0 0 240 240" role="img" aria-label="The eye from the front"></svg><svg class="sl-svg sl-cross" viewBox="0 0 380 280" role="img" aria-label="Cross-section: iris, ciliary body, lens and the drainage angle"></svg></div>' +
      '<div class="sl-legend" aria-label="What the arrows show: tap one to follow it">' + [['aq', 'Aqueous: made by the ciliary epithelium, flows through the pupil'], ['tr', 'Out through the trabeculum into Schlemm’s canal (90%)'], ['uv', 'Out by the uveoscleral route (10%)']].map(function (r) {
        return '<button type="button" class="' + r[0] + '" data-guide="' + r[0] + '"><svg viewBox="0 0 30 10" aria-hidden="true"><path d="M1 5H23" stroke-dasharray="4 3"/><path d="M22 1.5 L29 5 L22 8.5z"/></svg>' + r[1] + '<i aria-hidden="true">›</i></button>';
      }).join('') + '</div>' + GUIDE_HTML + '<div class="sl-tests"><button type="button" class="btn ghost" data-test="light">💡 Shine a light</button><button type="button" class="btn ghost" data-test="cornea">☝ Touch the cornea</button><button type="button" class="btn ghost" data-test="near">📖 Look at something near</button></div>' +
      '<p class="sl-testmsg" aria-live="polite"></p><div class="ux-readouts sl-ro"></div></div>' +
      '<div class="ux-controls">' + seg('cond', 'The eye', [['healthy', 'Healthy'], ['open', 'Open-angle glaucoma'], ['closed', 'Closed-angle glaucoma']], 'healthy') + '<div class="sl-card"></div></div></div>' +
      '<h3 class="sl-h">The reflexes at a glance</h3><div class="sl-table"></div>' +
      '<h3 class="sl-h">Treating glaucoma</h3><div class="sl-plan"></div>';
    var front = host.querySelector('.sl-front'), cross = host.querySelector('.sl-cross');
    W = walker(host, function () { return model(); }, function (r) { if (r) cross.setAttribute('data-route', r); else cross.removeAttribute('data-route'); });
    function drug() { return byId(st.drug); }
    function model(id) {   // id: another drug in the same eye (the "what if" compares with no drug)
      var d = byId(id || st.drug), c = CONDS[st.cond], closed = st.cond === 'closed';
      var T = c.T * (closed && d.Tc != null ? d.Tc : (d.T || 1)), U = d.U || 1, P = d.P || 1, osm = d.osm || 1;
      var iop = Math.min(70, osm * (8 + 12 * P / (T * 0.9 + U * 0.1)));   // an acute attack reads up to about 70 mm Hg
      return { d: d, cond: st.cond, T: T, U: U, P: P, iop: iop, light: d.light == null ? 1 : d.light, cornea: d.cornea == null ? 1 : d.cornea, acc: d.acc || 'normal', pupil: d.pupil || 4 };
    }
    function drawFront(m) {
      var pup = m.pupil;
      if (st.flash && m.light) pup = Math.max(1, pup * 0.55);
      if (st.look && m.acc === 'normal') pup = Math.max(1.2, pup - 0.8);   // the near response constricts the pupil too
      var pr = pup * 4.4, iris = m.d.pig ? '#5b3a22' : '#6f8fb3', red = m.d.blanch ? 0.05 : 0.18 + (m.d.hyper || 0) * 0.6;
      var h = '<rect width="240" height="240" fill="#0d1422"/><ellipse cx="120" cy="120" rx="108" ry="70" fill="#f4efe8"/>';
      for (var i = 0; i < 7; i++) { var y = 82 + i * 12, side = i % 2 ? 1 : -1; h += '<path d="M' + (120 + side * 104) + ' ' + y + ' Q' + (120 + side * 78) + ' ' + (y + 6) + ' ' + (120 + side * 62) + ' ' + (y - 4) + '" stroke="#d9534f" stroke-opacity="' + red.toFixed(2) + '" stroke-width="1.6" fill="none"/>'; }
      h += '<circle cx="120" cy="120" r="52" fill="' + iris + '"/><circle cx="120" cy="120" r="52" fill="none" stroke="#00000055" stroke-width="3"/>';
      for (var k = 0; k < 24; k++) { var a = k * Math.PI / 12; h += '<path d="M' + (120 + Math.cos(a) * (pr + 3)).toFixed(1) + ' ' + (120 + Math.sin(a) * (pr + 3)).toFixed(1) + ' L' + (120 + Math.cos(a) * 49).toFixed(1) + ' ' + (120 + Math.sin(a) * 49).toFixed(1) + '" stroke="#ffffff22" stroke-width="1.4"/>'; }
      h += '<circle cx="120" cy="120" r="' + pr.toFixed(1) + '" fill="#06070b" class="sl-pupil"/><circle cx="104" cy="104" r="7" fill="#fff" opacity=".75"/>';
      if (st.flash) h += '<circle cx="120" cy="120" r="80" fill="#fff6c8" opacity=".22"/>';
      var lid = st.blink && m.cornea ? 70 : 0;
      h += '<path d="M8 120 Q120 ' + (40 + lid * 1.15) + ' 232 120 L232 0 L8 0Z" fill="#c99a83"/><path d="M8 120 Q120 ' + (200 - lid * 1.15) + ' 232 120 L232 240 L8 240Z" fill="#c99a83"/>' +
        '<path d="M8 120 Q120 ' + (40 + lid * 1.15) + ' 232 120" fill="none" stroke="#3b2518" stroke-width="3"/>';
      h += '<text x="120" y="230" text-anchor="middle" class="sl-t">Pupil ' + pup.toFixed(1) + ' mm</text>';
      front.innerHTML = h;
    }
    function drawCross(m) {
      var closed = st.cond === 'closed', angleShut = closed && m.T < 0.5, cy = 140, pr = clamp(m.pupil * 5.5, 8, 46), tg = m.d.tgt;
      var accOn = m.acc === 'near' || (st.look && m.acc === 'normal'), lrx = accOn ? 34 : 24;
      var flowP = m.P, flowT = Math.min(2.2, m.T), flowU = Math.min(3, m.U * 0.5);
      var h = '<defs>' + [['aq', '#79e1ce'], ['tr', '#6fa8ff'], ['uv', '#ffcf4a']].map(function (m) {
          return '<marker id="sl-ah-' + m[0] + '" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="9" markerHeight="9" markerUnits="userSpaceOnUse" orient="auto"><path d="M0 1 L9 5 L0 9z" fill="' + m[1] + '"/></marker>';
        }).join('') + '</defs><rect width="380" height="280" fill="#0d1422"/>' +
        // sclera and cornea
        '<path d="M150 22 L380 12 M150 258 L380 268" stroke="#e8e3da" stroke-width="10" fill="none"/><path d="M152 22 Q36 140 152 258" class="sl-corneax"/>';
      // ciliary body (muscle + epithelium) top and bottom, the iris, the angle
      [-1, 1].forEach(function (s) {
        var yb = cy + s * 112, yi = cy + s * 96, ip = cy + s * pr, root = angleShut ? 154 : 166;
        h += '<path d="M176 ' + (cy + s * 120) + ' L250 ' + (cy + s * 118) + ' L218 ' + (cy + s * 78) + ' Z" class="sl-cb' + (accOn ? ' on' : '') + (tg.indexOf('cm') >= 0 ? ' hit' : '') + '"/>' +
          '<path d="M200 ' + (cy + s * 92) + ' q8 ' + (-s * 6) + ' 16 0 q8 ' + (s * 6) + ' 16 0" class="sl-epi' + (tg.indexOf('epi') >= 0 ? ' hit' : '') + '"/>' +
          '<path d="M' + root + ' ' + yi + ' L166 ' + ip + '" class="sl-irisx"/>' +
          '<path d="M166 ' + (ip + s * 14) + ' L166 ' + ip + '" class="sl-sph' + (tg.indexOf('sph') >= 0 ? ' hit' : '') + '"/>' +
          '<path d="M' + (root + 1) + ' ' + (yi - s * 4) + ' L166 ' + (ip + s * 20) + '" class="sl-dil' + (tg.indexOf('dil') >= 0 ? ' hit' : '') + '"/>' +
          '<rect x="150" y="' + (cy + s * 104 - 5) + '" width="10" height="10" rx="2" class="sl-trab' + (angleShut ? ' shut' : '') + '"/><ellipse cx="156" cy="' + (cy + s * 117) + '" rx="6" ry="3.5" class="sl-schlemm"/>';
      });
      // the lens
      h += '<ellipse cx="206" cy="' + cy + '" rx="' + lrx + '" ry="64" class="sl-lens"/>';
      // aqueous: made by the ciliary epithelium, through the pupil, out at the angle (90%) or the uveoscleral way (10%)
      h += '<path d="M212 ' + (cy - 86) + ' C190 ' + (cy - 70) + ' 176 ' + (cy - 40) + ' 168 ' + (cy - 10) + ' C150 ' + (cy - 20) + ' 128 ' + (cy - 50) + ' 146 ' + (cy - 89) + '" class="sl-flow" marker-end="url(#sl-ah-aq)" style="--w:' + (1 + flowP * 3).toFixed(1) + ';--dur:' + clamp(2.4 / flowP, 0.8, 6).toFixed(2) + 's"/>' +
        '<path d="M150 ' + (cy - 104) + ' L154 ' + (cy - 118) + ' L240 ' + (cy - 132) + '" class="sl-flow trab" marker-end="url(#sl-ah-tr)" style="--w:' + (angleShut ? 0.6 : 1 + flowT * 2.2).toFixed(1) + ';--dur:' + clamp(2.4 / Math.max(0.2, flowT), 0.8, 8).toFixed(2) + 's"/>' +
        '<path d="M166 ' + (cy - 100) + ' C190 ' + (cy - 104) + ' 230 ' + (cy - 104) + ' 262 ' + (cy - 96) + '" class="sl-flow uveo' + (tg.indexOf('uveo') >= 0 ? ' hit' : '') + '" marker-end="url(#sl-ah-uv)" style="--w:' + (0.8 + flowU * 1.6).toFixed(1) + ';--dur:' + clamp(3 / Math.max(0.3, flowU), 0.8, 8).toFixed(2) + 's"/>';
      // labels
      // labels: each one opens a step-by-step walk (the cornea, iris and lens: the reflexes; the rest: the aqueous)
      h += tl(40, 26, 'Cornea', 'cornea') + tl(104, cy - 6, 'Anterior', 'aq', '', 'middle', 1) + tl(104, cy + 8, 'chamber', 'aq', '', 'middle') + tl(206, cy + 4, 'Lens', 'near', '', 'middle') +
        tl(262, cy + 112, 'Ciliary body', 'aq') + tl(268, cy - 86, 'uveoscleral 10%', 'uv', ' sl-small') + tl(252, cy - 112, 'Schlemm 90%', 'tr', ' sl-small') +
        tl(176, cy + 58, 'iris', 'light', ' sl-small') + (angleShut ? '<text x="40" y="270" class="sl-t sl-warn">Angle closed: aqueous cannot drain</text>' : '');
      if (tg.indexOf('cns') >= 0) h += '<g class="sl-badge"><rect x="10" y="236" width="160" height="30" rx="9"/><text x="22" y="256">Acts in the brain</text></g>';
      if (tg.indexOf('blood') >= 0) h += '<g class="sl-badge"><rect x="10" y="236" width="196" height="30" rx="9"/><text x="22" y="256">Acts from the blood (osmotic)</text></g>';
      cross.innerHTML = h;
    }
    function draw() {
      var m = model(), d = m.d, closed = st.cond === 'closed';
      drawFront(m); drawCross(m);
      Array.prototype.forEach.call(host.querySelectorAll('[data-drug]'), function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-drug') === st.drug); });
      var iop = m.iop, iopCls = iop <= 25 ? 'ok' : iop <= 35 ? 'mid' : 'bad';
      host.querySelector('.sl-ro').innerHTML = [   // the reflexes and the aqueous open their walk
        ['Pupil', (m.pupil < 3.5 ? 'Miosis' : m.pupil > 5 ? 'Mydriasis' : 'Normal') + ' · ' + m.pupil.toFixed(1) + ' mm'], ['Light reflex', m.light ? 'Present' : 'Absent', m.light ? 'ok' : 'bad', 'light'],
        ['Corneal reflex', m.cornea ? 'Present' : 'Absent', m.cornea ? 'ok' : 'bad', 'cornea'], ['Accommodation', { near: 'For near (spasm)', normal: 'Normal', cyclo: 'Cycloplegia (far)', weak: 'Weak cycloplegia' }[m.acc], m.acc === 'cyclo' ? 'bad' : '', 'near'],
        ['IOP', iop.toFixed(0) + ' mm Hg', iopCls], ['Aqueous', (m.P < 1 ? 'Less made' : 'Made normally') + (m.T > 1.05 ? ' · Schlemm ↑' : m.T < 0.95 * CONDS[st.cond].T ? ' · Schlemm ↓' : '') + (m.U > 1.05 ? ' · uveoscleral ↑' : ''), '', 'aq']].map(function (r) {
          return '<div class="' + (r[2] || '') + (r[3] ? ' sl-rlink' : '') + '"' + (r[3] ? ' data-guide="' + r[3] + '" role="button" tabindex="0" title="Follow it step by step"' : '') + '><small>' + r[0] + (r[3] ? ' <i aria-hidden="true">›</i>' : '') + '</small><strong>' + r[1] + '</strong></div>';
        }).join('');
      var verdict = closed ? d.ca : st.cond === 'open' ? d.oa : '';
      host.querySelector('.sl-card').innerHTML = '<span class="ux-kicker">' + esc(d.grp.toUpperCase()) + '</span><h3>' + esc(d.name) + '</h3><p class="sl-cls">' + esc(d.cls) + '</p>' +
        (st.cond !== 'healthy' && d.id !== 'none' ? '<p class="sl-fit ' + (verdict === 'ok' ? 'ok' : verdict === 'no' ? 'no' : 'na') + '">' + (verdict === 'ok' ? '✓ Used in ' : verdict === 'no' ? '✕ Contraindicated in ' : '– Not a treatment for ') + CONDS[st.cond].name.toLowerCase() + (verdict === 'no' && WHATIF[d.id] ? ' <button type="button" class="sl-fitwhy" data-whatif="1">What happens? ›</button>' : '') + '</p>' : '') +
        '<dl><dt>How it works</dt><dd>' + esc(d.mech) + '</dd>' + (d.use ? '<dt>Uses</dt><dd>' + esc(d.use) + '</dd>' : '') + (d.side ? '<dt>Side effects</dt><dd>' + esc(d.side) + '</dd>' : '') + (d.contra ? '<dt>Contraindications</dt><dd>' + esc(d.contra) + '</dd>' : '') + '</dl>' + (WHATIF[d.id] ? '<button type="button" class="sl-whatif" data-whatif="1"><span>⚠ What if it is used anyway?</span><b aria-hidden="true">›</b></button>' : '') +
        (d.hook ? '<p class="sl-hook">' + esc(d.hook) + '</p>' : '') + (d.trap ? '<p class="sl-trap">⚠ ' + esc(d.trap) + '</p>' : '') +
        '<p class="ux-modelnote">IOP normal: 15–25 mm Hg (your book). Values are a teaching model.</p>';
      host.querySelector('.sl-table').innerHTML = '<table><thead><tr><th>Drug</th><th>Pupil</th><th>Light reflex</th><th>Corneal reflex</th><th>Accommodation</th></tr></thead><tbody>' +
        [['Parasympathomimetics', 'Miosis', 'Present', 'Present', 'For near vision', ['pilo', 'physo', 'echo']], ['Sympathomimetics (active)', 'Mydriasis', 'Present', 'Present', 'Normal', ['phen']], ['Cocaine (active)', 'Mydriasis', 'Present', 'Absent', 'Normal', ['coca']], ['Parasympatholytics (passive)', 'Mydriasis', 'Absent', 'Present', 'Cycloplegia (far)', ['atro', 'tropi']]].map(function (r) {
          return '<tr' + (r[5].indexOf(st.drug) >= 0 ? ' class="on"' : '') + '><td>' + r.slice(0, 5).join('</td><td>') + '</td></tr>';
        }).join('') + '</tbody></table><p class="sl-hook">Light reflex lost = passive. Corneal reflex lost = cocaine.</p>';
      var plan = function (title, ids, note) { return '<div class="sl-planc' + (st.cond === title[0] ? ' on' : '') + '"><b>' + title[1] + '</b><ol>' + ids.map(function (x) { var dd = DRUGS.filter(function (q) { return q.id === x[0]; })[0]; return '<li' + (x[0] === st.drug ? ' class="on"' : '') + '><button type="button" data-drug="' + x[0] + '">' + (dd ? dd.name : x[0]) + '</button> ' + x[1] + '</li>'; }).join('') + '</ol><p>' + note + '</p></div>'; };
      host.querySelector('.sl-plan').innerHTML = plan(['closed', 'Closed angle: lower the IOP, then iridectomy'], [['mann', 'osmotic: rapid, marked fall'], ['pilo', 'drug of choice, ≤2%'], ['acet', 'orally'], ['brimo', 'α2 agonist'], ['timo', 'recently, with pilocarpine']], 'Other agents are not used: their onset is too slow. Irreversible anticholinesterases and all mydriatics are contraindicated.') +
        plan(['open', 'Open angle: drops for long-term control'], [['timo', 'reduce formation'], ['brimo', 'less secretion, more uveoscleral outflow'], ['latano', 'the most potent'], ['pilo', 'miotics'], ['epi', 'more outflow'], ['acet', 'topical dorzolamide, brinzolamide']], 'Passive mydriatics and steroid drops raise the pressure.');
      if (W && W.G.id) { var gg = GUIDES[W.G.id]; if (gg.what && (st.drug !== W.G.drug || (gg.cond && st.cond !== gg.cond))) W.close(); else W.refresh(); }
    }

    function whatIf() {   // the drug where it is contraindicated: set the eye to match, then walk through it
      var d = drug(), id = WHATIF[d.id]; if (!id) return;
      if (id === 'wi-angle' && has(d, 'cm') && st.cond === 'open') id = 'wi-open';
      var g = GUIDES[id], switched = false;
      if (g.cond && st.cond !== g.cond) {
        st.cond = g.cond; switched = true;
        Array.prototype.forEach.call(host.querySelectorAll('[data-seg="cond"]'), function (x) { x.setAttribute('aria-pressed', x.getAttribute('data-v') === st.cond); });
      }
      W.close(); draw();
      W.open(id, { from: Math.round(model('none').iop), to: Math.round(model().iop), switched: switched }); W.G.drug = st.drug;
    }
    function test(which) {
      var m = model(), msg = host.querySelector('.sl-testmsg'), t = '';
      if (which === 'light') { st.flash = 1; t = m.light ? (m.pupil < 3 ? 'The pupil constricts a little more: the light reflex is present.' : 'The pupil constricts: the light reflex is present.') : 'No change: the constrictor pupillae is paralysed (passive mydriasis), so the light reflex is absent.'; }
      if (which === 'cornea') { st.blink = 1; t = m.cornea ? 'Blink: the corneal reflex is present.' : 'No blink: the cornea is numb (cocaine is a local anaesthetic), so the corneal reflex is absent.'; }
      if (which === 'near') { st.look = 1; t = { normal: 'The ciliary muscle contracts, the lens rounds up and the pupil constricts: near focus works.', near: 'Already focused for near: the ciliary muscle is in spasm, so distant things blur.', cyclo: 'It cannot: cycloplegia. The ciliary muscle is paralysed, so focus stays fixed for far.', weak: 'Focusing is weak: a mild cycloplegia.' }[m.acc]; }
      msg.innerHTML = esc(t) + ' <button type="button" class="sl-follow" data-guide="' + which + '">Follow it to the brain ›</button>';
      draw();
      timers.push(setTimeout(function () { st.flash = 0; st.blink = 0; st.look = 0; if (host.isConnected) draw(); }, which === 'cornea' ? 450 : 1600));
    }
    host.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target : null; if (!t) return;
      var b = t.closest('[data-drug]'); if (b) { st.drug = b.getAttribute('data-drug'); host.querySelector('.sl-testmsg').textContent = ''; draw(); return; }
      var x = t.closest('[data-test]'); if (x) { test(x.getAttribute('data-test')); return; }
      if (t.closest('[data-whatif]')) { whatIf(); return; }
    });
    bind(host, st, draw);
    draw();
    return function () { timers.forEach(clearTimeout); W.stop(); };
  }

  window.SenseLabs = { list: [
    { n: 'How vision works', g: 'PHYSIOLOGY', mount: vision },
    { n: 'How hearing works', g: 'PHYSIOLOGY', mount: hearing },
    { n: 'Eye drugs', g: 'PHARMACOLOGY', mount: eyeDrugs }
  ] };
})();
