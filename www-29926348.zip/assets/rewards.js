/* SS Study rewards: XP, levels, ranks, coins, badges and a cosmetic-only shop. Free, local-first, no server.

   Everything here is pure logic (no screens): app.js calls it from the one place each activity finishes, then saves.
   The state lives in the app's saved progress (store.rw), like ticks and Q bank stars: on this device, and on the
   devices it is linked to (Link devices, assets/sync.js). Clearing the app's data on an unlinked device resets it.
   It is NOT cheat-proof: anything a page computes and saves on the device can be edited by its owner. Rewards are
   for fun and motivation only; they never unlock or change any study content. */
(function () {
  'use strict';

  /* ---------- settings: every threshold, reward and price is here ---------- */
  var CFG = {
    // Coins (v2.20, the creator's wish: "not easily got, nor hardly got"): a good session (a lecture and three Q bank
    // levels at ~85%) earns about 470, half a typical 900-coin item; the 2500-4000 coin items take about a week of
    // steady study. A perfect score has its own tier. XP is unchanged, so levels and ranks stay where they are.
    LECTURE: { xp: 50, coins: 80 },                 // first time every card of a lecture is ticked
    QB_TIERS: [                                     // a Q bank level, by its score; below 50%: nothing
      { min: 100, xp: 110, coins: 250 },
      { min: 95, xp: 110, coins: 180 },
      { min: 85, xp: 85, coins: 130 },
      { min: 70, xp: 60, coins: 80 },
      { min: 50, xp: 35, coins: 35 }
    ],
    QB_MIN_QUESTIONS: 5,                            // a level with fewer questions pays nothing
    QB_BANK_SIZE: 30,                               // 3 levels x 10 questions: a bank pays only while it still brings new questions
    EXAM_PASS_PCT: 70,                              // the app's own pass mark (Q bank levels pass at 7 of 10)
    EXAM_TIERS: [                                   // the first passing attempt in an exam's reward slot
      { min: 100, xp: 250, coins: 700 },
      { min: 90, xp: 250, coins: 450 },
      { min: 80, xp: 180, coins: 300 },
      { min: 0, xp: 120, coins: 200 }
    ],
    EXAM_MIN_ANSWERED: 0.5,                         // a mostly blank exam is not a real attempt
    EXAM_SLOT: 'day',                               // mock exams are drawn afresh each time: one reward slot per exam type per day
    BONUS_CAP: { xp: 40, coins: 60 },               // beating your own best later: at most this much extra per assessment, in total
    UPDATE_GIFT: 500,                               // coins, once per app version: opened by the first lecture, Q bank level or mock exam finished in it
    LOG_KEEP: 40,
    // Medals: for show on every attempt (retrying for gold counts); they never pay XP or coins, so they can't be farmed
    QB_MEDALS: [{ min: 100, m: 'gold' }, { min: 90, m: 'silver' }, { min: 70, m: 'bronze' }],
    EXAM_MEDALS: [{ min: 100, m: 'diamond' }, { min: 85, m: 'gold' }, { min: 70, m: 'silver' }, { min: 50, m: 'bronze' }]
  };
  var MEDAL = { diamond: { icon: '💎', name: 'Diamond' }, gold: { icon: '🥇', name: 'Gold' }, silver: { icon: '🥈', name: 'Silver' }, bronze: { icon: '🥉', name: 'Bronze' } };

  var RANKS = [   // fictional game ranks, earned by level only (never bought); not real qualifications
    { from: 1, name: 'Medical Novice', icon: '🌱' },
    { from: 6, name: 'Medical Apprentice', icon: '📗' },
    { from: 11, name: 'Medical Scholar', icon: '🎓' },
    { from: 21, name: 'Medical Expert', icon: '🔬' },
    { from: 36, name: 'Medical Master', icon: '🏅' },
    { from: 51, name: 'Medical Legend', icon: '🌟' }
  ];

  var BADGES = [   // awarded once each, automatically; they give no XP or coins
    { id: 'badge_first_lecture', name: 'First Steps', icon: '👣', desc: 'Complete one lecture.' },
    { id: 'badge_bookworm', name: 'Bookworm', icon: '🐛', desc: 'Complete 10 different lectures.' },
    { id: 'badge_first_qbank', name: 'Quiz Starter', icon: '🎯', desc: 'Score at least 50% on a Q bank level.' },
    { id: 'badge_sharpshooter', name: 'Sharpshooter', icon: '🏹', desc: 'Score at least 90% on 5 different Q bank levels.' },
    { id: 'badge_perfect_quiz', name: 'Perfectionist', icon: '💯', desc: 'Score 100% on a Q bank level.' },
    { id: 'badge_first_exam_pass', name: 'First Victory', icon: '🏆', desc: 'Pass a mock exam.' },
    { id: 'badge_exam_conqueror', name: 'Exam Conqueror', icon: '⚔️', desc: 'Pass 5 different mock exams (each exam type counts once a day).' },
    { id: 'badge_comeback', name: 'Comeback', icon: '🔁', desc: 'Fail a mock exam, then pass that same exam later.' }
  ];

  /* The shop: cosmetic only. Prices are coins, never real money.
     kind: title | frame | deco | theme | avatar | banner (profile theme) | fx (profile effect) | cardfx (Focus-mode card animation). */
  var SHOP = [
    { id: 'title_night_owl', kind: 'title', name: 'The Night Owl 🌙', price: 200, desc: 'For late-night revision sessions.' },
    { id: 'title_brainiac', kind: 'title', name: 'Brainiac 🧠', price: 350, desc: 'A title for big thinkers.' },
    { id: 'title_dedicated', kind: 'title', name: 'The Dedicated 📚', price: 500, desc: 'Shows you keep showing up.' },
    { id: 'title_quiz_slayer', kind: 'title', name: 'Quiz Slayer ⚔️', price: 750, desc: 'For Q bank warriors.' },
    { id: 'title_prodigy', kind: 'title', name: 'The Prodigy ✨', price: 1000, desc: 'A shiny title.' },
    { id: 'title_walking_encyclopedia', kind: 'title', name: 'Walking Encyclopedia 📖', price: 1250, desc: 'Knows a bit of everything.' },
    { id: 'title_dragon_scholar', kind: 'title', name: 'Dragon Scholar 🐉', price: 1500, desc: 'A fierce title.' },
    { id: 'title_chosen_one', kind: 'title', name: 'The Chosen One 👑', price: 2500, desc: 'A rare title.' },
    { id: 'title_beyond_genius', kind: 'title', name: 'Beyond Genius 🌌', price: 4000, desc: 'The top title in the shop.' },
    { id: 'frame_galaxy', kind: 'frame', name: 'Galaxy frame', price: 500, desc: 'A swirling galaxy ring around your avatar.' },
    { id: 'frame_blossom', kind: 'frame', name: 'Blossom', price: 700, desc: 'A soft ring of cherry-blossom pinks that slowly turns.' },
    { id: 'frame_gold', kind: 'frame', name: 'Golden ring', price: 800, desc: 'Polished gold with a shine that travels round the ring.' },
    { id: 'frame_neon', kind: 'frame', name: 'Neon chase', price: 900, desc: 'Cyan and magenta light chasing each other, with a neon glow.' },
    { id: 'frame_crystal', kind: 'frame', name: 'Crystal', price: 1100, desc: 'Cut ice-blue facets that glint as they turn.' },
    { id: 'frame_inferno', kind: 'frame', name: 'Inferno', price: 1300, desc: 'A ring of living fire that flickers and glows.' },
    { id: 'deco_crown', kind: 'deco', name: 'Royal crown', price: 750, desc: 'A jewelled gold crown with pearls, a velvet cap and a shine that sweeps across it.' },
    { id: 'deco_cap', kind: 'deco', name: 'Scholar\u2019s cap', price: 800, desc: 'A graduation cap with a gold cord and a tassel that swings.' },
    { id: 'deco_halo', kind: 'deco', name: 'Halo', price: 900, desc: 'A golden halo floating smoothly up and down, with light running round it.' },
    { id: 'deco_stetho', kind: 'deco', name: 'Stethoscope 🩺', price: 1000, desc: 'A stethoscope round your neck; the chest piece swings gently.' },
    { id: 'deco_orbit', kind: 'deco', name: 'Orbiting stars', price: 1100, desc: 'Two stars with trails on tilted orbits, passing behind you and in front.' },
    { id: 'deco_dna', kind: 'deco', name: 'DNA helix 🧬', price: 1300, desc: 'A double helix turning beside your avatar.' },
    { id: 'deco_wings', kind: 'deco', name: 'Phoenix wings', price: 1600, desc: 'Feathered wings of fire behind you, beating slowly, with rising embers.' },
    { id: 'theme_nebula', kind: 'theme', name: 'Nebula theme', price: 1000, desc: 'Deep space for the whole app: drifting nebula colours and twinkling stars.' },
    { id: 'theme_night', kind: 'theme', name: 'Night theme', price: 800, desc: 'Calm midnight blues, easy on the eyes late at night.' },
    { id: 'theme_ocean', kind: 'theme', name: 'Ocean theme', price: 900, desc: 'Deep sea teals and blues, with slow waves of light.' },
    { id: 'theme_sakura', kind: 'theme', name: 'Sakura theme', price: 900, desc: 'Soft cherry-blossom pinks with drifting petals.' },
    { id: 'theme_rainbow', kind: 'theme', name: 'Rainbow theme', price: 1200, desc: 'Moving rainbow bars and accents all over the app.' },
    { id: 'theme_emerald', kind: 'theme', name: 'Emerald forest', price: 1200, desc: 'Deep forest greens, light rays through the trees and floating specks.' },
    { id: 'theme_aurora', kind: 'theme', name: 'Aurora theme', price: 1500, desc: 'Northern lights that ripple slowly across a polar night.' },
    { id: 'theme_synth', kind: 'theme', name: 'Synthwave theme', price: 1500, desc: 'Neon pink and cyan with a glowing horizon and a moving grid.' },
    { id: 'theme_gold', kind: 'theme', name: 'Royal gold', price: 1800, desc: 'Black and gold, with a gold shimmer sweeping the top bar.' },
    { id: 'theme_blackhole', kind: 'theme', name: 'Black hole', price: 2500, desc: 'A theme with its own story: a black hole drifts in the middle of the app, swallows every star around it, flares, and the stars come back.' },
    // the glitch family (the creator's idea): three themes with moving layers, and Overdrive with its own story like the Black hole
    { id: 'theme_glitch', kind: 'theme', name: 'Glitch theme', price: 1500, desc: 'Scanlines crawling down the screen, an old-TV roll bar, and tears flashing cyan and magenta across the app.' },
    { id: 'theme_error', kind: 'theme', name: 'Error theme', price: 1500, desc: 'System failure red: a moving hazard stripe under the top bar, error windows drifting behind, a scrolling error log, a red scan line and warning flashes.' },
    { id: 'theme_overload', kind: 'theme', name: 'Overload theme', price: 1800, desc: 'Every meter in the red: a bank of LED meters slamming to the top, electric arcs, sparks flying up and rising heat.' },
    { id: 'theme_overdrive', kind: 'theme', name: 'Overdrive ⚡', price: 3000, desc: 'A theme with its own story: a reactor core charges segment by segment, boosts until the screen tears, bursts into OVERDRIVE with a flash and a shockwave, cools down and charges again.' },
    { id: 'frame_glitch', kind: 'frame', name: 'Glitch ring', price: 1200, desc: 'A segmented ring split into magenta and cyan, with pieces tearing off, pixels flickering and scanlines over your picture.' },
    { id: 'deco_error', kind: 'deco', name: 'Error popup', price: 1400, desc: 'A little system error window that keeps popping up beside you, glitching, with pixel debris around it.' },
    { id: 'intro_glitch', kind: 'intro', name: 'System glitch', price: 1400, desc: 'Static and a terminal boot log, a crash, then the logo glitches in split into cyan and magenta and steadies: system restored.' },
    { id: 'tiles_glitch', kind: 'tiles', name: 'Glitch tabs', price: 1100, desc: 'Dark tiles split into magenta and cyan, with scanlines and a tear that flickers across them now and then.' },
    // glitch extras and 404 (the creator asked for "the rest of the things"; not in any bundle until the creator says so)
    { id: 'banner_nosignal', kind: 'banner', name: 'No signal 📺', price: 1000, desc: 'TV static, a colour-bar test card that glitches, a blinking NO SIGNAL plate and a roll bar passing over.' },
    { id: 'fx_datarain', kind: 'fx', name: 'Data rain', price: 900, desc: 'Columns of 0s and 1s raining down in cyan and magenta, glitching as they fall.' },
    { id: 'cardfx_glitchout', kind: 'cardfx', name: 'Glitch out 📺', price: 1000, desc: 'The card tears into cyan and magenta, jitters and switches off like an old TV; the next one switches on.' },
    { id: 'frame_overload', kind: 'frame', name: 'Overload ring', price: 1300, desc: 'A hot metal ring crackling with electric arcs that run round it, sparks jumping off.' },
    { id: 'deco_404', kind: 'deco', name: '404 sign', price: 1100, desc: 'A pixel 404 NOT FOUND sign hovering beside you, split into cyan and magenta, with pixels breaking off.' },
    { id: 'title_matrix', kind: 'title', name: 'Glitch in the Matrix 🕶️', price: 900, desc: 'For the ones who saw it twice.' },
    { id: 'title_404', kind: 'title', name: '404: Sleep Not Found 💤', price: 600, desc: 'For the all-nighters.' },
    { id: 'title_overclocked', kind: 'title', name: 'Overclocked ⚡', price: 800, desc: 'Running faster than the specs allow.' },
    // the Error set (not in any bundle until the creator says so)
    { id: 'banner_crash', kind: 'banner', name: 'System crash 🚨', price: 1100, desc: 'A dark red alert screen: error windows cascading in one after another, a spinning red beacon and a moving hazard stripe.' },
    { id: 'fx_popups', kind: 'fx', name: 'Error popups', price: 900, desc: 'Little error windows popping up all over your profile, glitching and closing again.' },
    { id: 'cardfx_crash', kind: 'cardfx', name: 'Crash 💥', price: 1000, desc: 'The card shakes, flashes FATAL ERROR and falls off the screen; the next one reboots in with a loading bar.' },
    { id: 'frame_warning', kind: 'frame', name: 'Warning ring', price: 1200, desc: 'A turning hazard-striped ring with two red beacons circling it, flashing, and warning signs blinking around it.' },
    { id: 'tiles_error', kind: 'tiles', name: 'Error tabs', price: 1100, desc: 'Red alert tiles with a hazard-striped edge, warning-yellow badges and a status light blinking on each.' },
    { id: 'cards_error', kind: 'cards', name: 'Error dialog card', price: 1200, desc: 'Every card is an error window: a red title bar with a warning sign and a close box. Done cards turn green: RESOLVED.' },
    { id: 'intro_crash', kind: 'intro', name: 'Crash & reboot', price: 1300, desc: 'Error windows cascade across the screen, FATAL ERROR, black, a reboot bar fills, and the logo comes back.' },
    { id: 'title_fatal', kind: 'title', name: 'Fatal Error 💀', price: 700, desc: 'When the brain stops responding.' },
    { id: 'title_kernel', kind: 'title', name: 'Kernel Panic 🚨', price: 1000, desc: 'Exam week mode.' },
    // the Lunar eclipse set (not in any bundle until the creator says so)
    { id: 'theme_lunar', kind: 'theme', name: 'Lunar eclipse 🌕', price: 2800, desc: 'A theme with its own story: the full moon slides into Earth\u2019s shadow and turns blood red while the sky darkens and the faint stars come out, then the moon comes back. Its light shimmers on a lake below.' },
    { id: 'banner_lunar', kind: 'banner', name: 'Eclipse night 🌘', price: 1200, desc: 'A starry night over a pine ridge: the full moon slips into Earth\u2019s shadow, turns blood red and comes back.' },
    { id: 'fx_moons', kind: 'fx', name: 'Moon phases', price: 900, desc: 'Little moons, silver and blood red, floating up around your profile as they wane and wax.' },
    { id: 'cardfx_eclipse', kind: 'cardfx', name: 'Eclipse 🌑', price: 1000, desc: 'Earth\u2019s shadow sweeps over the card with a copper-red edge and it fades into the dark; then the shadow slides off the next one.' },
    { id: 'frame_bloodmoon', kind: 'frame', name: 'Blood moon ring', price: 1300, desc: 'A ring of cratered moon rock; a copper shadow sweeps round it while a little moon orbits and turns blood red.' },
    { id: 'deco_crescent', kind: 'deco', name: 'Crescent moon 🌙', price: 1200, desc: 'A cratered crescent moon above your avatar with two little stars swinging from it; now and then it turns blood red.' },
    { id: 'tiles_lunar', kind: 'tiles', name: 'Moonlit tabs', price: 1100, desc: 'Night-sky tiles with stars, a crescent in the corner, full-moon badges and moonlight gliding across.' },
    { id: 'cards_lunar', kind: 'cards', name: 'Moonlit card', price: 1200, desc: 'A starry header with a moon in its corner; tick a card and the moon turns blood red: TOTALITY.' },
    { id: 'intro_lunar', kind: 'intro', name: 'Blood moon rising', price: 1400, desc: 'The full moon rises into a starry sky, Earth\u2019s shadow sweeps across it and it turns blood red as the logo writes itself in moonlight.' },
    { id: 'title_moonchild', kind: 'title', name: 'Moonchild 🌙', price: 800, desc: 'For the ones who study by moonlight.' },
    { id: 'title_bloodmoon', kind: 'title', name: 'Blood Moon 🌕', price: 1000, desc: 'Rare, red and unforgettable.' },
    // the Solar eclipse set (not in any bundle until the creator says so)
    { id: 'theme_solar', kind: 'theme', name: 'Solar eclipse ☀️', price: 3000, desc: 'A theme with its own story: the moon slides across the sun, the sky darkens, Baily\u2019s beads flash and the diamond ring bursts; at totality the white corona and pink prominences appear, the stars and Venus come out and a sunset glows all round the horizon. Then the sun comes back.' },
    { id: 'banner_solar', kind: 'banner', name: 'Totality ☀️', price: 1200, desc: 'Mountains under a solar eclipse: the moon covers the sun, the corona shines out, stars appear and the horizon glows; then the sun returns.' },
    { id: 'fx_suns', kind: 'fx', name: 'Little suns', price: 900, desc: 'Tiny golden suns with turning rays drifting up around your profile, and now and then an eclipsed one.' },
    { id: 'cardfx_diamond', kind: 'cardfx', name: 'Diamond ring 💍', price: 1100, desc: 'The moon slides over the card, its edge glows white and the diamond ring flashes as the card goes dark; the moon slides off the next one.' },
    { id: 'frame_corona', kind: 'frame', name: 'Corona ring', price: 1400, desc: 'Your avatar as the eclipsed sun: a glowing white edge, corona streamers turning slowly, pink prominences, and a diamond ring flashing round it.' },
    { id: 'deco_glasses', kind: 'deco', name: 'Eclipse glasses 🕶️', price: 1100, desc: 'Golden eclipse glasses with dark lenses; the sun in them goes from a crescent to a ring of light.' },
    { id: 'tiles_solar', kind: 'tiles', name: 'Solar tabs', price: 1100, desc: 'Warm dark tiles with golden light, sun badges, a little eclipse in the corner and a golden sheen gliding across.' },
    { id: 'cards_solar', kind: 'cards', name: 'Corona card', price: 1200, desc: 'A golden header with a shining sun; tick a card and the sun is eclipsed into a ring of white light: ECLIPSED.' },
    { id: 'intro_solar', kind: 'intro', name: 'Diamond ring', price: 1400, desc: 'The moon slides over the sun, Baily\u2019s beads flash, the diamond ring bursts and the corona opens as the logo writes itself in light.' },
    { id: 'title_chaser', kind: 'title', name: 'Eclipse Chaser 🌑', price: 900, desc: 'For the ones who travel for totality.' },
    { id: 'title_sunchild', kind: 'title', name: 'Sun Child ☀️', price: 800, desc: 'Bright, warm and always on.' },
    // the Terminal set and more 404 and space looks (not in any bundle until the creator says so)
    { id: 'theme_terminal', kind: 'theme', name: 'Terminal 💻', price: 1600, desc: 'A green phosphor screen: scanlines, a refresh bar rolling down, a system log and a hex dump scrolling behind the app, and a blinking prompt.' },
    { id: 'tiles_terminal', kind: 'tiles', name: 'Terminal tabs', price: 1000, desc: 'Black CRT tiles with green glowing edges, a > prompt and a blinking cursor on every title, and block-character progress bars.' },
    { id: 'cards_terminal', kind: 'cards', name: 'Terminal card', price: 1100, desc: 'Every card is a terminal window: $ cat before the title, green phosphor text and scanlines. Done cards print [ OK ].' },
    { id: 'banner_lost', kind: 'banner', name: 'Lost in space 🧑‍🚀', price: 1100, desc: 'Error 404 in deep space: a little astronaut drifting away on a broken tether past a ringed planet and a giant pixel 404.' },
    { id: 'frame_saturn', kind: 'frame', name: 'Planet ring 🪐', price: 1300, desc: 'A banded planetary ring tilted round your avatar, passing behind you and in front, rocking gently, with twinkling dust.' },
    { id: 'deco_astronaut', kind: 'deco', name: 'Little astronaut 🧑‍🚀', price: 1300, desc: 'A tiny astronaut floating beside you on a tether, waving and slowly turning.' },
    { id: 'fx_planets', kind: 'fx', name: 'Tiny planets 🪐', price: 900, desc: 'Little ringed planets in orange, blue and violet drifting up around your profile.' },
    { id: 'cardfx_supernova', kind: 'cardfx', name: 'Supernova 💥', price: 1100, desc: 'The card collapses into a white-hot star and explodes in a ring of light; the next one forms out of the glow.' },
    { id: 'title_root', kind: 'title', name: 'Root Access 🔓', price: 900, desc: 'sudo study --all' },
    { id: 'title_hello', kind: 'title', name: 'Hello, World! 👋', price: 500, desc: 'Your first line of code.' },
    { id: 'title_stardust', kind: 'title', name: 'Made of Stardust ✨', price: 700, desc: 'Literally.' },
    // new additions to the old collections (2026-11-23; they join those collections' bundles, as the creator asked)
    { id: 'fx_corrupt', kind: 'fx', name: 'Corrupted avatar 📺', price: 1200, desc: 'Corrupted pixel blocks and torn scanlines flicker all over your profile, split into cyan and magenta.' },
    { id: 'intro_bsod', kind: 'intro', name: 'Blue screen of death', price: 1500, desc: 'A blue crash screen powers on, BRAIN_OVERFLOW, the counter runs to 100%, the screen switches off like an old monitor and the logo writes itself.' },
    { id: 'fx_epulse', kind: 'fx', name: 'Electric pulse ⚡', price: 1100, desc: 'Rings of electricity pulse out across your profile while little lightning bolts crackle.' },
    { id: 'deco_lunardust', kind: 'deco', name: 'Lunar dust 🌙', price: 900, desc: 'A ring of glittering moon dust and tiny moon rocks orbiting you on a tilted path, behind you and in front.' },
    { id: 'fx_flare', kind: 'fx', name: 'Solar flare ☀️', price: 1200, desc: 'Arcs of fire loop up and burst all over your profile, with sparks flying off them.' },
    { id: 'fx_shimmer', kind: 'fx', name: 'Golden shimmer ✨', price: 900, desc: 'Gold sparkles twinkle, gold flakes drift down and a band of golden light sweeps across.' },
    { id: 'tiles_cosmic', kind: 'tiles', name: 'Cosmic dust tabs', price: 1200, desc: 'Nebula tiles with star dust drifting across them, planet badges and glowing stardust progress bars.' },
    { id: 'intro_cmd', kind: 'intro', name: 'Command prompt 💻', price: 1300, desc: 'A terminal types out your study code, the system crashes, WELCOME TO, and a green cursor writes the logo.' },
    { id: 'fx_npulse', kind: 'fx', name: 'Neon pulse', price: 800, desc: 'Neon rings and bars in pink, cyan and violet flicker on and pulse to the beat.' },
    { id: 'frame_prism', kind: 'frame', name: 'Prism ring 🌈', price: 1200, desc: 'A ring of cut crystal facets turning slowly; a beam of white light goes in and splits into a rainbow.' },
    { id: 'intro_blossom', kind: 'intro', name: 'Falling blossom 🌸', price: 1000, desc: 'Cherry branches sway at the top of a soft pink sky as petals fall across the screen and the logo writes itself in deep pink.' },
    { id: 'intro_rebirth', kind: 'intro', name: 'Rebirth 🔥', price: 1600, desc: 'Embers glow in a pile of ash, fire bursts up, a phoenix rises and spreads its wings in a flash of light, and the logo writes itself in gold.' },
    { id: 'frame_ecg', kind: 'frame', name: 'ECG pulse 🩺', price: 1200, desc: 'A heart monitor ring: a green heartbeat trace runs round you, with a little heart beating along with it.' },
    // the Blood Moon / Vampire collection
    { id: 'theme_crimson', kind: 'theme', name: 'Crimson night 🩸', price: 1800, desc: 'A blood moon over a gothic castle: bats flit across the sky, dark clouds drift past the moon and red mist rolls along the ground.' },
    { id: 'banner_castle', kind: 'banner', name: 'Vampire\u2019s castle 🏰', price: 1200, desc: 'A gothic castle on a hill under a blood moon, its windows flickering with candlelight, bats circling and mist creeping in.' },
    { id: 'fx_bats', kind: 'fx', name: 'Bat swarm 🦇', price: 900, desc: 'Bats with red eyes fluttering across your profile.' },
    { id: 'frame_thorn', kind: 'frame', name: 'Thorned blood ring', price: 1400, desc: 'A glossy crimson ring wound with thorny vines and a red rose; drops of blood gather and drip from it.' },
    { id: 'deco_fangs', kind: 'deco', name: 'Vampire fangs 🧛', price: 1100, desc: 'A tall black cape collar with a red satin lining behind you, and sharp fangs with a drop of blood.' },
    { id: 'intro_bloodmist', kind: 'intro', name: 'Blood mist', price: 1500, desc: 'Red mist rolls in, a blood moon rises, a swarm of bats bursts out of it, blood drips down and the logo writes itself in crimson.' },
    { id: 'title_nightborn', kind: 'title', name: 'Nightborn 🦇', price: 900, desc: 'Studies best after midnight.' },
    { id: 'title_immortal', kind: 'title', name: 'The Immortal 🩸', price: 1500, desc: 'Never stops, never sleeps.' },
    // the Cybernetic / AI collection
    { id: 'theme_cyber', kind: 'theme', name: 'Cybernetic 🤖', price: 1700, desc: 'A glowing circuit board behind the app: data packets race along the traces, nodes pulse, a holographic AI core turns in the middle and a scan line sweeps down.' },
    { id: 'banner_neural', kind: 'banner', name: 'Neural network', price: 1200, desc: 'Layers of glowing nodes wired together; waves of signals light up the network from left to right.' },
    { id: 'fx_binary', kind: 'fx', name: 'Binary rain', price: 900, desc: 'Streams of teal 0s and 1s falling down your profile, each with a bright leading digit.' },
    { id: 'frame_circuit', kind: 'frame', name: 'Circuit ring', price: 1300, desc: 'A circuit-board ring with gold traces, solder pads and tiny chips; pulses of light run round it.' },
    { id: 'deco_holo', kind: 'deco', name: 'Hologram projection', price: 1400, desc: 'A little projector beside you beams up a flickering holographic globe that turns, with scanlines running through it.' },
    { id: 'intro_sysinit', kind: 'intro', name: 'System initialization', price: 1500, desc: 'A hex grid lights up, the rings of a HUD lock into place, an AI eye opens, the neural core runs to 100% and goes ONLINE.' },
    { id: 'title_ai', kind: 'title', name: 'Artificial Intelligence 🤖', price: 1200, desc: 'Learns faster than the dataset.' },
    { id: 'title_singularity', kind: 'title', name: 'The Singularity 🧠', price: 2000, desc: 'Beyond the point of no return.' },
    // the Celestial / Angelic collection
    { id: 'theme_heaven', kind: 'theme', name: 'Heavenly realm 🪽', price: 2000, desc: 'A light theme above the clouds: banks of sunlit clouds drift by, rays of golden light fall from above and specks of light float up.' },
    { id: 'banner_clouds', kind: 'banner', name: 'Above the clouds ☁️', price: 1300, desc: 'A sea of sunlit clouds rolling past under a golden sun, with rays of light and white doves.' },
    { id: 'fx_feathers', kind: 'fx', name: 'Falling feathers', price: 800, desc: 'Soft white feathers drifting and swaying down your profile.' },
    { id: 'frame_halo', kind: 'frame', name: 'Divine halo', price: 1500, desc: 'A ring of polished gold with a halo of light; golden rays turn slowly behind it and a ring of light pulses outward.' },
    { id: 'deco_angelwings', kind: 'deco', name: 'Angel wings', price: 1600, desc: 'Large feathered white wings behind you, beating slowly in a soft glow, with sparkles of light.' },
    { id: 'intro_ascend', kind: 'intro', name: 'Ascension', price: 1700, desc: 'A column of light falls through the clouds, they part, golden rays burst out, angel wings unfold and feathers drift down as the logo writes itself in gold.' },
    { id: 'title_seraphim', kind: 'title', name: 'Seraphim 🪽', price: 1500, desc: 'Highest of the high.' },
    { id: 'title_divine', kind: 'title', name: 'Divine Being ✨', price: 2000, desc: 'Not of this world.' },
    // The Void collection
    { id: 'theme_abyss', kind: 'theme', name: 'Abyss 🕳️', price: 2200, desc: 'A violet whirlpool of nothing turns behind the app; specks of light spiral into the dark core, and now and then two eyes open in the deep.' },
    { id: 'banner_horizon', kind: 'banner', name: 'Event horizon', price: 1400, desc: 'The edge of a black hole fills the sky: a glowing ring of light round the dark, an accretion disc swirling and matter streaming in.' },
    { id: 'fx_voidp', kind: 'fx', name: 'Void particles', price: 1000, desc: 'Dark specks rimmed in violet and pink drift up, swell and collapse into nothing.' },
    { id: 'frame_singularity', kind: 'frame', name: 'Singularity ring', price: 1600, desc: 'A ring of swirling dark matter turning both ways at once, a thin lensed ring of light and particles racing round it.' },
    { id: 'deco_eye', kind: 'deco', name: 'Floating eye 👁️', price: 1300, desc: 'A violet eye with a slit pupil floating beside you in a dark aura; it looks around and blinks, its wisps trailing below.' },
    { id: 'intro_collapse', kind: 'intro', name: 'Reality collapse', price: 1800, desc: 'The screen cracks from one point and shatters into flying glass, the void tears open behind it, and a tiny black hole writes the logo.' },
    { id: 'title_unknown', kind: 'title', name: 'The Unknown 👁️', price: 1400, desc: 'No one knows how you do it.' },
    { id: 'title_beyond', kind: 'title', name: 'Beyond Existence 🌌', price: 2500, desc: 'Further than far.' },
    // the Dreamcore / Pastel collection
    { id: 'theme_dream', kind: 'theme', name: 'Dreamland 🍬', price: 1200, desc: 'A pastel dream: candy-coloured clouds drift past a soft rainbow while little hearts and stars float up and sparkle.' },
    { id: 'banner_candy', kind: 'banner', name: 'Cotton candy sky', price: 900, desc: 'A pink-and-blue sky of cotton candy clouds, a pastel rainbow, twinkles and a tiny shooting star.' },
    { id: 'fx_hearts', kind: 'fx', name: 'Floating hearts 💗', price: 600, desc: 'Pastel hearts in pink, lilac and peach floating up and swaying.' },
    { id: 'frame_pastelstar', kind: 'frame', name: 'Pastel star ring', price: 900, desc: 'A soft rainbow ring of pastel colours turning slowly, with little stars twinkling round it.' },
    { id: 'deco_plushie', kind: 'deco', name: 'Tiny plushie 🧸', price: 800, desc: 'A tiny stitched teddy bear with a bow and a heart patch, sitting by you and waving.' },
    { id: 'intro_dreamy', kind: 'intro', name: 'Dreamy fade', price: 1000, desc: 'A sleepy moon over the clouds, a rainbow rises, bubbles drift up, night melts into a pastel morning, and a little heart writes the logo.' },
    { id: 'title_daydreamer', kind: 'title', name: 'Daydreamer ☁️', price: 600, desc: 'Head in the clouds, notes in hand.' },
    { id: 'title_sweetdreams', kind: 'title', name: 'Sweet Dreams 💗', price: 800, desc: 'Studied well, sleep well.' },
    // the Arcane Scholar collection
    { id: 'theme_library', kind: 'theme', name: 'Enchanted library 📜', price: 1700, desc: 'Towering shelves of old books on either side, candles floating and flickering, glowing runes drifting and magic dust in the air.' },
    { id: 'banner_manuscript', kind: 'banner', name: 'Ancient manuscript', price: 1100, desc: 'An old parchment page with an illuminated letter, lines of ink script, a quill still writing and a red wax seal.' },
    { id: 'fx_runes', kind: 'fx', name: 'Floating runes', price: 900, desc: 'Glowing golden and teal runes floating up round your profile, turning slowly as they fade.' },
    { id: 'frame_arcane', kind: 'frame', name: 'Arcane circle', price: 1300, desc: 'A glowing magic circle round you: two rings of runes turning opposite ways, sigil points and sparks of magic.' },
    { id: 'deco_spellbook', kind: 'deco', name: 'Spellbook 📖', price: 1200, desc: 'An open spellbook floating beside you, its pages glowing and turning by themselves as runes rise out of it.' },
    { id: 'intro_spell', kind: 'intro', name: 'Spellcasting 🔮', price: 1500, desc: 'A magic circle draws itself in the dark, its runes light up one by one, power gathers in the middle and bursts out as the logo writes itself in gold.' },
    { id: 'title_archmage', kind: 'title', name: 'The Archmage 🔮', price: 1500, desc: 'Master of every spell in the syllabus.' },
    { id: 'title_keeper', kind: 'title', name: 'Keeper of Knowledge 📖', price: 1300, desc: 'Guards every page.' },
    // tab styles, card styles and card animations for the six new collections
    { id: 'tiles_crimson', kind: 'tiles', name: 'Crimson tabs 🩸', price: 1100, desc: 'Dark wine tiles with blood dripping from the top edge, a bat in the corner, blood-moon badges and glossy blood-red bars.' },
    { id: 'cards_crimson', kind: 'cards', name: 'Gothic card 🦇', price: 1200, desc: 'A black-and-crimson card with a double gothic border, a serif title and a bat in the corner; done cards are SEALED.' },
    { id: 'cardfx_bats', kind: 'cardfx', name: 'Into the night 🦇', price: 1100, desc: 'The card sinks into a blood-red mist and a swarm of bats bursts out of it; the next one fades in out of the mist.' },
    { id: 'tiles_cyber', kind: 'tiles', name: 'Circuit tabs 🤖', price: 1100, desc: 'Angular HUD tiles with cut corners, circuit traces, corner brackets, a scan beam sweeping across and hexagon badges.' },
    { id: 'cards_cyber', kind: 'cards', name: 'HUD card', price: 1200, desc: 'A holographic HUD panel with cut corners, a grid and a live status light; done cards are VERIFIED.' },
    { id: 'cardfx_digitize', kind: 'cardfx', name: 'Upload ⬆️', price: 1100, desc: 'The card turns into a grid of data, a scan line runs down it and it collapses into a line that uploads away; the next one downloads in.' },
    { id: 'tiles_heaven', kind: 'tiles', name: 'Cloud tabs 🪽', price: 1100, desc: 'Soft white tiles with golden light, little clouds, halo badges and a golden glow gliding across.' },
    { id: 'cards_heaven', kind: 'cards', name: 'Celestial card', price: 1200, desc: 'An ivory card with a fine gold border, a sky-coloured header and a glowing halo; done cards are BLESSED.' },
    { id: 'cardfx_ascend', kind: 'cardfx', name: 'Ascend ✨', price: 1100, desc: 'A column of light falls on the card, it glows gold and rises up into it; the next one floats down.' },
    { id: 'tiles_void', kind: 'tiles', name: 'Void tabs 🕳️', price: 1200, desc: 'Black tiles with a violet whirlpool turning in the corner, black-hole badges and violet-to-pink bars.' },
    { id: 'cards_void', kind: 'cards', name: 'Void card', price: 1300, desc: 'A deep violet card scattered with stars and a tiny whirlpool spinning in the header; done cards are ABSORBED.' },
    { id: 'cardfx_eventh', kind: 'cardfx', name: 'Into the void 🕳️', price: 1200, desc: 'The card is stretched and pulled into a point as a ring of light flashes, then the next one comes out of it.' },
    { id: 'tiles_dream', kind: 'tiles', name: 'Pastel tabs 🍬', price: 900, desc: 'Bubbly pastel tiles with a candy-stripe edge, a little heart, candy badges and striped bars.' },
    { id: 'cards_dream', kind: 'cards', name: 'Candy card', price: 1000, desc: 'A pastel card with a wavy candy header and a bobbing heart; done cards are stamped SWEET!' },
    { id: 'cardfx_bubble', kind: 'cardfx', name: 'Bubble pop 🫧', price: 900, desc: 'The card is caught in a shiny bubble that floats up and pops into sparkles; the next one bounces in.' },
    { id: 'tiles_arcane', kind: 'tiles', name: 'Grimoire tabs 📜', price: 1100, desc: 'Leather-bound tiles with gold tooled borders, gold corner guards, a glowing rune, gold medallions and wax-seal numbers.' },
    { id: 'cards_arcane', kind: 'cards', name: 'Parchment card', price: 1200, desc: 'An old parchment page with burnt edges, a red illuminated first letter and a rune; done cards get a red wax seal.' },
    { id: 'cardfx_spell', kind: 'cardfx', name: 'Vanish spell 🔮', price: 1100, desc: 'A magic circle appears over the card, spins and the card vanishes into it in a flash of gold; the next one appears out of the light.' },
    { id: 'cards_glitch', kind: 'cards', name: 'Glitch card', price: 1200, desc: 'A terminal card with scanlines and a split-colour title; a tear flickers across it, and done cards are stamped PATCHED.' },
    // profile themes: the backdrop behind your name and picture
    { id: 'banner_sunset', kind: 'banner', name: 'Sunset', price: 400, desc: 'A warm evening sky behind your profile.' },
    { id: 'banner_ocean', kind: 'banner', name: 'Ocean', price: 400, desc: 'Rolling blue waves behind your profile.' },
    { id: 'banner_night', kind: 'banner', name: 'Night sky', price: 500, desc: 'Stars and a moon behind your profile.' },
    { id: 'banner_aurora', kind: 'banner', name: 'Aurora', price: 700, desc: 'Northern lights that slowly move.' },
    { id: 'banner_rainbow', kind: 'banner', name: 'Rainbow', price: 800, desc: 'A rainbow that keeps flowing.' },
    { id: 'banner_alpine', kind: 'banner', name: 'Alpine dusk', price: 900, desc: 'Layered mountains under a glowing dusk sky.' },
    { id: 'banner_blossom', kind: 'banner', name: 'Cherry blossom', price: 900, desc: 'Petals drifting across a soft pink sky.' },
    { id: 'banner_galaxy', kind: 'banner', name: 'Galaxy', price: 1000, desc: 'A spiral galaxy turning slowly among the stars.' },
    { id: 'banner_synth', kind: 'banner', name: 'Synthwave', price: 1200, desc: 'A striped retro sun over a neon grid that keeps moving.' },
    // profile effects: animated, over your profile
    { id: 'fx_sparkles', kind: 'fx', name: 'Sparkles ✨', price: 400, desc: 'Little stars twinkle around you.' },
    { id: 'fx_snow', kind: 'fx', name: 'Snow ❄️', price: 500, desc: 'Gentle snowflakes drift down.' },
    { id: 'fx_rain', kind: 'fx', name: 'Rain 🌧️', price: 500, desc: 'A soft rain falls on your profile.' },
    { id: 'fx_fireflies', kind: 'fx', name: 'Fireflies', price: 600, desc: 'Glowing fireflies float about.' },
    { id: 'fx_lightning', kind: 'fx', name: 'Lightning ⚡', price: 900, desc: 'Rain with flashes of lightning.' },
    { id: 'fx_bubbles', kind: 'fx', name: 'Bubbles', price: 600, desc: 'Glassy bubbles rising and wobbling.' },
    { id: 'fx_petals', kind: 'fx', name: 'Petals 🌸', price: 600, desc: 'Blossom petals tumbling down.' },
    { id: 'fx_embers', kind: 'fx', name: 'Embers', price: 700, desc: 'Glowing embers drifting up and fading.' },
    { id: 'fx_meteors', kind: 'fx', name: 'Meteor shower ☄️', price: 1000, desc: 'Shooting stars streaking across your profile.' },
    // card animations: how a card arrives in Focus mode and leaves when you tap "Got it, next"
    { id: 'cardfx_fade', kind: 'cardfx', name: 'Fade', price: 300, desc: 'Cards fade softly out and in.' },
    { id: 'cardfx_zoom', kind: 'cardfx', name: 'Zoom', price: 400, desc: 'Cards zoom away and the next one pops in.' },
    { id: 'cardfx_flip', kind: 'cardfx', name: 'Flip', price: 500, desc: 'Cards flip over like a page.' },
    { id: 'cardfx_rocket', kind: 'cardfx', name: 'Rocket 🚀', price: 700, desc: 'Done cards blast off upwards.' },
    { id: 'cardfx_race', kind: 'cardfx', name: 'Race car 🏎️', price: 900, desc: 'Done cards back up, tilt and race off with speed lines; the next one drifts in.' },
    { id: 'cardfx_fold', kind: 'cardfx', name: 'Fold', price: 700, desc: 'Cards fold away like paper; the next one unfolds.' },
    { id: 'cardfx_swoosh', kind: 'cardfx', name: 'Swoosh', price: 800, desc: 'Cards squash, then fling away; the next one drops in with a bounce.' },
    { id: 'cardfx_pageturn', kind: 'cardfx', name: 'Page turn 📖', price: 900, desc: 'Cards turn like a real book page, with shading.' },
    { id: 'cardfx_portal', kind: 'cardfx', name: 'Portal 🌀', price: 1000, desc: 'Cards spin away into a swirl; the next one spins out of it.' },
    // free defaults, so every profile looks complete
    { id: 'avatar_doctor', kind: 'avatar', name: 'Doctor', icon: '🧑‍⚕️', price: 0, free: true },
    { id: 'avatar_brain', kind: 'avatar', name: 'Brain', icon: '🧠', price: 0, free: true },
    { id: 'avatar_eye', kind: 'avatar', name: 'Eye', icon: '👁️', price: 0, free: true },
    { id: 'avatar_ear', kind: 'avatar', name: 'Ear', icon: '👂', price: 0, free: true },
    { id: 'avatar_owl', kind: 'avatar', name: 'Owl', icon: '🦉', price: 0, free: true },
    { id: 'avatar_cat', kind: 'avatar', name: 'Cat', icon: '🐱', price: 0, free: true },
    { id: 'avatar_star', kind: 'avatar', name: 'Star', icon: '⭐', price: 0, free: true },
    { id: 'frame_plain', kind: 'frame', name: 'Plain frame', price: 0, free: true, desc: 'A simple ring.' },
    { id: 'deco_none', kind: 'deco', name: 'No decoration', price: 0, free: true },
    { id: 'theme_default', kind: 'theme', name: 'Standard theme', price: 0, free: true, desc: 'The usual colours.' },
    { id: 'banner_none', kind: 'banner', name: 'Plain', price: 0, free: true },
    { id: 'fx_none', kind: 'fx', name: 'No effect', price: 0, free: true },
    { id: 'cardfx_none', kind: 'cardfx', name: 'Classic', price: 0, free: true, desc: 'Cards change straight away.' },
    { id: 'title_none', kind: 'title', name: 'No title', price: 0, free: true },
    { id: 'intro_pen', kind: 'intro', name: 'Pen writing', price: 0, free: true, desc: 'A pen writes SPECIAL SENSES, then SS STUDY.' },
    { id: 'tiles_default', kind: 'tiles', name: 'Standard tabs', price: 0, free: true, desc: 'The usual tiles.' },
    { id: 'intro_ecg', kind: 'intro', name: 'Heartbeat 💓', price: 800, desc: 'A heart monitor sweeps across the screen, then SS STUDY beats into place.' },
    { id: 'intro_wave', kind: 'intro', name: 'Sound wave 🎧', price: 900, desc: 'An equaliser bounces to the beat, settles into a line and the logo rises out of it.' },
    { id: 'intro_neon', kind: 'intro', name: 'Neon sign', price: 1000, desc: 'Glass tubes on a brick wall flicker on one letter at a time.' },
    { id: 'intro_stars', kind: 'intro', name: 'Constellation ✨', price: 1100, desc: 'Stars appear and golden lines join them into the logo.' },
    { id: 'intro_eye', kind: 'intro', name: 'Eye opening 👁️', price: 1300, desc: 'An eye opens, looks around, its pupil narrows, and you fly in through it.' },
    { id: 'intro_warp', kind: 'intro', name: 'Warp speed 🚀', price: 1500, desc: 'Stars stream past at light speed, a flash, and the logo lands with a shockwave.' },
    { id: 'tiles_glass', kind: 'tiles', name: 'Glass', price: 600, desc: 'Clear glass tiles with a shine across them and glossy badges.' },
    { id: 'tiles_paper', kind: 'tiles', name: 'Notebook', price: 700, desc: 'Lined notebook paper with a margin, washi tape and stamped badges.' },
    { id: 'tiles_clay', kind: 'tiles', name: 'Soft 3D', price: 800, desc: 'Soft raised tiles that press in when you tap, with round glossy buttons.' },
    { id: 'tiles_neon', kind: 'tiles', name: 'Neon edge', price: 900, desc: 'Dark tiles outlined in each subject’s colour, glowing softly.' },
    { id: 'tiles_holo', kind: 'tiles', name: 'Holographic', price: 1100, desc: 'Rainbow foil edges and a shimmer that slides across every tile.' },
    { id: 'tiles_gold', kind: 'tiles', name: 'Gold leaf', price: 1200, desc: 'Black and gold, a double gold border and gilded corners.' },
    { id: 'cards_default', kind: 'cards', name: 'Standard cards', price: 0, free: true, desc: 'The usual cards.' },
    { id: 'cards_glass', kind: 'cards', name: 'Glass card', price: 700, desc: 'Clear glass with a shine, a soft edge light and a glossy Got it button.' },
    { id: 'cards_index', kind: 'cards', name: 'Index card', price: 800, desc: 'A real study index card: red header lines, a folded corner and a LEARNED stamp when you tick it.' },
    { id: 'cards_clip', kind: 'cards', name: 'Clipboard 🩺', price: 900, desc: 'A patient chart on a wooden clipboard with a metal clip; ticked cards get a REVIEWED stamp.' },
    { id: 'cards_neon', kind: 'cards', name: 'Neon card', price: 1000, desc: 'Dark cards outlined in the subject’s colour; they glow green when you tick them.' },
    { id: 'cards_holo', kind: 'cards', name: 'Holo foil', price: 1200, desc: 'Rainbow foil edges, a shimmer across the header and a foil seal when done.' },
    { id: 'cards_gold', kind: 'cards', name: 'Gold leaf card', price: 1400, desc: 'Black lacquer, gilded corners, gold key words and a gold seal when done.' }
  ];
  var DEFAULTS = { avatar: 'avatar_doctor', frame: 'frame_plain', deco: 'deco_none', theme: 'theme_default', title: 'title_none',
    banner: 'banner_none', fx: 'fx_none', cardfx: 'cardfx_none', intro: 'intro_pen', tiles: 'tiles_default', cards: 'cards_default' };

  /* Bundles: a set of items for BUNDLE_OFF less than buying the ones you don't own yet one by one (owned ones are never
     charged again). New items are added to a bundle only when the creator says so. */
  var BUNDLE_OFF = .25;
  var BUNDLES = [
    { id: 'bundle_glitch', name: 'Glitch bundle', icon: '⚡', desc: 'The whole glitch collection with the Error set: the Glitch, Error, Overload and Overdrive themes, the No signal and System crash profile themes, Corrupted avatar, Electric pulse, Data rain and Error popups, the Glitch ring, Overload ring and Warning ring, the Error popup and the 404 sign, the System glitch, Blue screen of death and Crash & reboot openings, Glitch and Error tabs, the Glitch and Error dialog cards, the Glitch out and Crash card animations, and the titles Glitch in the Matrix, 404: Sleep Not Found, Overclocked, Fatal Error and Kernel Panic.',
      items: ['theme_glitch', 'theme_error', 'theme_overload', 'theme_overdrive', 'frame_glitch', 'deco_error', 'intro_glitch', 'tiles_glitch', 'cards_glitch', 'fx_corrupt', 'fx_epulse', 'intro_bsod', 'banner_nosignal', 'fx_datarain', 'cardfx_glitchout', 'frame_overload', 'deco_404', 'title_matrix', 'title_404', 'title_overclocked', 'banner_crash', 'fx_popups', 'cardfx_crash', 'frame_warning', 'tiles_error', 'cards_error', 'intro_crash', 'title_fatal', 'title_kernel'] },
    { id: 'bundle_space', name: 'Deep space bundle', icon: '🌌', desc: 'Everything from deep space: the Nebula and Black hole themes, the Galaxy and Lost in space profile themes, Meteor shower and Tiny planets, the Galaxy frame and the Planet ring, Orbiting stars and the Little astronaut, the Constellation and Warp speed openings, Cosmic dust tabs, the Supernova and Rocket card animations, and the title Made of Stardust.',
      items: ['theme_nebula', 'theme_blackhole', 'frame_galaxy', 'deco_orbit', 'banner_galaxy', 'fx_meteors', 'intro_stars', 'intro_warp', 'tiles_cosmic', 'banner_lost', 'fx_planets', 'frame_saturn', 'deco_astronaut', 'cardfx_supernova', 'cardfx_rocket', 'title_stardust'] },
    { id: 'bundle_neon', name: 'Neon nights bundle', icon: '🌆', desc: 'Neon everything: the Synthwave theme and profile theme, the Neon chase frame, the Neon sign opening, Neon edge tabs, the Neon card and Neon pulse.',
      items: ['theme_synth', 'banner_synth', 'frame_neon', 'intro_neon', 'tiles_neon', 'cards_neon', 'fx_npulse'] },
    { id: 'bundle_gold', name: 'Royal gold bundle', icon: '👑', desc: 'Black and gold: the Royal gold theme, the Golden ring, the Royal crown, Gold leaf tabs, the Gold leaf card and Golden shimmer.',
      items: ['theme_gold', 'frame_gold', 'deco_crown', 'tiles_gold', 'cards_gold', 'fx_shimmer'] },
    { id: 'bundle_holo', name: 'Holographic bundle', icon: '🌈', desc: 'Rainbow foil: the Rainbow theme and profile theme, Holographic tabs, the Holo foil card and the Prism ring.',
      items: ['theme_rainbow', 'banner_rainbow', 'tiles_holo', 'cards_holo', 'frame_prism'] },
    { id: 'bundle_blossom', name: 'Cherry blossom bundle', icon: '🌸', desc: 'Spring: the Sakura theme, the Blossom frame, the Cherry blossom profile theme, falling Petals and the Falling blossom opening.',
      items: ['theme_sakura', 'frame_blossom', 'banner_blossom', 'fx_petals', 'intro_blossom'] },
    { id: 'bundle_phoenix', name: 'Phoenix fire bundle', icon: '🔥', desc: 'Fire: the Inferno frame, Phoenix wings, rising Embers and the Rebirth opening.',
      items: ['frame_inferno', 'deco_wings', 'fx_embers', 'intro_rebirth'] },
    // the creator asked for these (2026-11-24): a bundle for every set, and each loose item that fits a set goes in its bundle
    { id: 'bundle_lunar', name: 'Lunar eclipse bundle', icon: '🌕', desc: 'The whole Lunar eclipse set: the Lunar eclipse theme, the Eclipse night profile theme, Moon phases, the Blood moon ring, the Crescent moon and Lunar dust, the Blood moon rising opening, Moonlit tabs, the Moonlit card, the Eclipse card animation and the titles Moonchild and Blood Moon.',
      items: ['theme_lunar', 'banner_lunar', 'fx_moons', 'frame_bloodmoon', 'deco_crescent', 'deco_lunardust', 'intro_lunar', 'tiles_lunar', 'cards_lunar', 'cardfx_eclipse', 'title_moonchild', 'title_bloodmoon'] },
    { id: 'bundle_solar', name: 'Solar eclipse bundle', icon: '☀️', desc: 'The whole Solar eclipse set: the Solar eclipse theme, the Totality profile theme, Little suns and Solar flare, the Corona ring, Eclipse glasses, the Diamond ring opening, Solar tabs, the Corona card, the Diamond ring card animation and the titles Eclipse Chaser and Sun Child.',
      items: ['theme_solar', 'banner_solar', 'fx_suns', 'fx_flare', 'frame_corona', 'deco_glasses', 'intro_solar', 'tiles_solar', 'cards_solar', 'cardfx_diamond', 'title_chaser', 'title_sunchild'] },
    { id: 'bundle_terminal', name: 'Terminal bundle', icon: '💻', desc: 'For hackers: the Terminal theme, the Command prompt opening, Terminal tabs, the Terminal card and the titles Root Access and Hello, World!',
      items: ['theme_terminal', 'intro_cmd', 'tiles_terminal', 'cards_terminal', 'title_root', 'title_hello'] },
    { id: 'bundle_medical', name: 'Medical bundle', icon: '🩺', desc: 'For future doctors: the ECG pulse frame, the Stethoscope and the DNA helix, the Heartbeat, Eye opening and Sound wave openings, and the Clipboard card.',
      items: ['frame_ecg', 'deco_stetho', 'deco_dna', 'intro_ecg', 'intro_eye', 'intro_wave', 'cards_clip'] },
    // the creator asked for these six as bundles (2026-11-23), titles included
    { id: 'bundle_vampire', name: 'Blood Moon bundle', icon: '🩸', desc: 'The vampire collection: the Crimson night theme, the Vampire’s castle profile theme, the Bat swarm, the Thorned blood ring, Vampire fangs, the Blood mist opening, Crimson tabs, the Gothic card, the Into the night card animation and the titles Nightborn and The Immortal.',
      items: ['theme_crimson', 'banner_castle', 'fx_bats', 'frame_thorn', 'deco_fangs', 'intro_bloodmist', 'tiles_crimson', 'cards_crimson', 'cardfx_bats', 'title_nightborn', 'title_immortal'] },
    { id: 'bundle_cyber', name: 'Cybernetic bundle', icon: '🤖', desc: 'The AI collection: the Cybernetic theme, the Neural network profile theme, Binary rain, the Circuit ring, the Hologram projection, the System initialization opening, Circuit tabs, the HUD card, the Upload card animation and the titles Artificial Intelligence and The Singularity.',
      items: ['theme_cyber', 'banner_neural', 'fx_binary', 'frame_circuit', 'deco_holo', 'intro_sysinit', 'tiles_cyber', 'cards_cyber', 'cardfx_digitize', 'title_ai', 'title_singularity'] },
    { id: 'bundle_celestial', name: 'Celestial bundle', icon: '🪽', desc: 'The angelic collection: the Heavenly realm theme, the Above the clouds profile theme, Falling feathers, the Divine halo, Angel wings, the Halo, the Ascension opening, Cloud tabs, the Celestial card, the Ascend card animation and the titles Seraphim and Divine Being.',
      items: ['theme_heaven', 'banner_clouds', 'fx_feathers', 'frame_halo', 'deco_angelwings', 'deco_halo', 'intro_ascend', 'tiles_heaven', 'cards_heaven', 'cardfx_ascend', 'title_seraphim', 'title_divine'] },
    { id: 'bundle_void', name: 'The Void bundle', icon: '🕳️', desc: 'Everything from the void: the Abyss theme, the Event horizon profile theme, Void particles, the Singularity ring, the Floating eye, the Reality collapse opening, Void tabs, the Void card, the Into the void and Portal card animations and the titles The Unknown and Beyond Existence.',
      items: ['theme_abyss', 'banner_horizon', 'fx_voidp', 'frame_singularity', 'deco_eye', 'intro_collapse', 'tiles_void', 'cards_void', 'cardfx_eventh', 'cardfx_portal', 'title_unknown', 'title_beyond'] },
    { id: 'bundle_dream', name: 'Dreamcore bundle', icon: '🍬', desc: 'Pastel dreams: the Dreamland theme, the Cotton candy sky profile theme, Floating hearts, Bubbles, the Pastel star ring, the Tiny plushie, the Dreamy fade opening, Pastel tabs, the Candy card, the Bubble pop card animation and the titles Daydreamer and Sweet Dreams.',
      items: ['theme_dream', 'banner_candy', 'fx_hearts', 'fx_bubbles', 'frame_pastelstar', 'deco_plushie', 'intro_dreamy', 'tiles_dream', 'cards_dream', 'cardfx_bubble', 'title_daydreamer', 'title_sweetdreams'] },
    { id: 'bundle_arcane', name: 'Arcane Scholar bundle', icon: '📜', desc: 'The magic collection: the Enchanted library theme, the Ancient manuscript profile theme, Floating runes, the Arcane circle, the Spellbook, the Scholar’s cap, the Spellcasting opening, Grimoire tabs, the Parchment card, the Vanish spell and Page turn card animations and the titles The Archmage and Keeper of Knowledge.',
      items: ['theme_library', 'banner_manuscript', 'fx_runes', 'frame_arcane', 'deco_spellbook', 'deco_cap', 'intro_spell', 'tiles_arcane', 'cards_arcane', 'cardfx_spell', 'cardfx_pageturn', 'title_archmage', 'title_keeper'] }
  ];

  /* ---------- levels: lifetime XP only (coins never count) ---------- */
  var isInt = Number.isSafeInteger || function (n) { return typeof n === 'number' && isFinite(n) && Math.floor(n) === n && Math.abs(n) <= 9007199254740991; };
  function xpToNextLevel(level) {
    if (!isInt(level) || level < 1) throw new RangeError('Invalid level');
    return 100 + 25 * (level - 1);
  }
  function totalXpForLevel(level) {
    if (!isInt(level) || level < 1) throw new RangeError('Invalid level');
    return 100 * (level - 1) + (25 * (level - 1) * (level - 2)) / 2;
  }
  function getLevelFromXp(totalXp) {
    if (!isInt(totalXp) || totalXp < 0) throw new RangeError('Invalid XP');
    var low = 1, high = 2, mid;   // the highest level whose lifetime threshold is <= totalXp
    while (totalXpForLevel(high) <= totalXp) high *= 2;
    while (low + 1 < high) {
      mid = Math.floor((low + high) / 2);
      if (totalXpForLevel(mid) <= totalXp) low = mid; else high = mid;
    }
    return low;
  }
  function getLevelProgress(totalXp) {
    var level = getLevelFromXp(totalXp), earned = totalXp - totalXpForLevel(level), need = xpToNextLevel(level);
    return { level: level, earnedWithinLevel: earned, requiredWithinLevel: need, fraction: earned / need };
  }
  function rankFor(level) {
    var r = RANKS[0];
    for (var i = 0; i < RANKS.length; i++) if (level >= RANKS[i].from) r = RANKS[i];
    return r;
  }

  /* ---------- the saved state (store.rw) ---------- */
  function fresh() {
    return { v: 1, xp: 0, coins: 0, claims: {}, best: {}, bonus: {}, fails: {}, passes: {}, badges: {}, owned: {}, eq: {}, days: [], log: [],
      medals: { diamond: 0, gold: 0, silver: 0, bronze: 0 } };
  }
  function ensure(rw) {   // fills in anything missing, never overwrites what is there
    var f = fresh(), k;
    if (!rw || typeof rw !== 'object') return f;
    for (k in f) if (rw[k] == null || typeof rw[k] !== typeof f[k] || Array.isArray(f[k]) !== Array.isArray(rw[k])) rw[k] = f[k];
    if (!isInt(rw.xp) || rw.xp < 0) rw.xp = 0;
    if (!isInt(rw.coins) || rw.coins < 0) rw.coins = 0;
    return rw;
  }
  function item(id) { for (var i = 0; i < SHOP.length; i++) if (SHOP[i].id === id) return SHOP[i]; return null; }
  function equipped(rw, kind) {   // what is worn, falling back to the free default if the saved one is not valid
    var id = rw.eq[kind], it = id && item(id);
    return it && it.kind === kind && (it.free || rw.owned[id]) ? it : item(DEFAULTS[kind]);
  }

  /* ---------- paying out (one place for every reward) ---------- */
  function grant(rw, xp, coins, what, now) {
    var before = getLevelFromXp(rw.xp);
    rw.xp += xp; rw.coins += coins;
    var after = getLevelFromXp(rw.xp);
    rw.log.unshift({ at: now, what: what, xp: xp, coins: coins });
    if (rw.log.length > CFG.LOG_KEEP) rw.log.length = CFG.LOG_KEEP;
    return { xp: xp, coins: coins, levelBefore: before, levelAfter: after,
      rankBefore: rankFor(before).name, rankAfter: rankFor(after).name };
  }
  function result(rw, base, reason, extra) {   // what the screens show: earned, why, new totals, progress, new badges
    var out = { xp: 0, coins: 0, reason: reason || '', badges: [] }, k;
    for (k in base || {}) out[k] = base[k];
    for (k in extra || {}) out[k] = extra[k];
    out.totalXp = rw.xp; out.totalCoins = rw.coins;
    out.progress = getLevelProgress(rw.xp);
    out.rank = rankFor(out.progress.level).name;
    if (out.levelBefore == null) { out.levelBefore = out.levelAfter = out.progress.level; }
    return out;
  }
  function badge(rw, id, now, list) { if (!rw.badges[id]) { rw.badges[id] = now; list.push(id); } }
  function count(obj, prefix, test) { var n = 0; for (var k in obj) if (k.indexOf(prefix) === 0 && (!test || test(obj[k]))) n++; return n; }
  function tier(tiers, pct) { for (var i = 0; i < tiers.length; i++) if (pct >= tiers[i].min) return tiers[i]; return null; }
  function bonusLeft(rw, id) { var b = rw.bonus[id] || { xp: 0, coins: 0 }; return { xp: Math.max(0, CFG.BONUS_CAP.xp - b.xp), coins: Math.max(0, CFG.BONUS_CAP.coins - b.coins) }; }
  function payBonus(rw, id, fromTier, toTier, now, what) {   // the extra for beating your own best: the tier difference, capped in total
    var left = bonusLeft(rw, id), xp = Math.min(left.xp, Math.max(0, toTier.xp - fromTier.xp)), coins = Math.min(left.coins, Math.max(0, toTier.coins - fromTier.coins));
    if (!xp && !coins) return null;
    var b = rw.bonus[id] || (rw.bonus[id] = { xp: 0, coins: 0 });
    b.xp += xp; b.coins += coins;
    return grant(rw, xp, coins, what, now);
  }
  function dayOf(now) { var d = new Date(now); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }

  /* A lecture: every card ticked. Pays once per lecture, ever (unticking and ticking again pays nothing). */
  function claimLecture(rw, lid, title, now) {
    var id = 'lec:' + lid, got = [];
    if (rw.claims[id]) return result(rw, null, 'already');
    rw.claims[id] = { at: now };
    var g = grant(rw, CFG.LECTURE.xp, CFG.LECTURE.coins, 'Lecture: ' + title, now);
    badge(rw, 'badge_first_lecture', now, got);
    if (count(rw.claims, 'lec:') >= 10) badge(rw, 'badge_bookworm', now, got);
    return result(rw, g, 'lecture', { badges: got });
  }

  /* A Q bank level: {mode, sid, bank, lv, got, n, paidBanks, name}. Its stable id is the subject + bank + level (never
     a random session id). Pays the first time it reaches 50%; after that, only beating your own best pays a small
     capped bonus. Banks past paidBanks (once a subject's questions have all come round) pay nothing. */
  function claimQBank(rw, q, now) {
    var pct = Math.round(q.got / q.n * 100), id = 'qb:' + q.mode + ':' + q.sid + ':' + q.bank + ':' + q.lv, got = [], g = null;
    if (!(q.n >= CFG.QB_MIN_QUESTIONS)) return result(rw, null, 'too-few', { pct: pct });
    if (q.bank >= (q.paidBanks || 1)) return result(rw, null, 'old-bank', { pct: pct });
    var best = rw.best[id], t = tier(CFG.QB_TIERS, pct), what = 'Q bank: ' + (q.name || q.sid) + ', bank ' + (q.bank + 1) + ' level ' + q.lv;
    var reason;
    if (!rw.claims[id]) {
      if (!t) reason = 'below';
      else { rw.claims[id] = { at: now, pct: pct }; g = grant(rw, t.xp, t.coins, what, now); reason = 'first'; }
    } else if (best != null && pct > best && t) {
      g = payBonus(rw, id, tier(CFG.QB_TIERS, best) || { xp: 0, coins: 0 }, t, now, what + ' (new best)');
      reason = g ? 'bonus' : 'capped';
    } else reason = best != null && pct <= best ? 'not-better' : 'already';
    if (best == null || pct > best) rw.best[id] = pct;
    if (pct >= 50) badge(rw, 'badge_first_qbank', now, got);
    if (pct === 100) badge(rw, 'badge_perfect_quiz', now, got);
    if (count(rw.best, 'qb:', function (p) { return p >= 90; }) >= 5) badge(rw, 'badge_sharpshooter', now, got);
    return result(rw, g, reason, { badges: got, pct: pct, best: rw.best[id] });
  }

  /* A mock exam: {type ('ebe' | 'ospe-written' | 'ospe-mix'), got, n, answered, name}. Exams are drawn afresh every
     time, so the stable id is the exam type + the day: the first pass of the day pays by score, a later better pass
     that day only a capped bonus. Failing (below EXAM_PASS_PCT) pays nothing; a mostly blank paper doesn't count. */
  function claimExam(rw, x, now) {
    var pct = Math.round(x.got / x.n * 100), slot = CFG.EXAM_SLOT === 'day' ? dayOf(now) : 'once', id = 'exam:' + x.type + ':' + slot, got = [], g = null, reason;
    if (!(x.n > 0) || x.answered < x.n * CFG.EXAM_MIN_ANSWERED) return result(rw, null, 'blank', { pct: pct, pass: false });
    var pass = pct >= CFG.EXAM_PASS_PCT, what = (x.name || x.type) + ' mock exam';
    if (!pass) {
      var f = rw.fails[x.type] || (rw.fails[x.type] = { n: 0 });
      f.n++; f.at = now;
      return result(rw, null, 'below-pass', { pct: pct, pass: false, passMark: CFG.EXAM_PASS_PCT });
    }
    var t = tier(CFG.EXAM_TIERS, pct), best = rw.best[id];
    if (!rw.claims[id]) { rw.claims[id] = { at: now, pct: pct }; g = grant(rw, t.xp, t.coins, what, now); reason = 'first'; }
    else if (best != null && pct > best) { g = payBonus(rw, id, tier(CFG.EXAM_TIERS, best), t, now, what + ' (new best)'); reason = g ? 'bonus' : 'capped'; }
    else reason = 'not-better';
    if (best == null || pct > best) rw.best[id] = pct;
    rw.passes[id] = rw.best[id];
    badge(rw, 'badge_first_exam_pass', now, got);
    if (count(rw.passes, 'exam:') >= 5) badge(rw, 'badge_exam_conqueror', now, got);
    if (rw.fails[x.type] && rw.fails[x.type].n > 0 && rw.fails[x.type].at < now) badge(rw, 'badge_comeback', now, got);
    return result(rw, g, reason, { badges: got, pct: pct, pass: true, best: rw.best[id] });
  }

  /* The update gift: once per app version (claim 'gift:<version>'), coins only. app.js opens it with the first
     lecture, Q bank level or mock exam finished in that version, so it rewards updating and starts a study session. */
  function claimGift(rw, version, now) {
    var id = 'gift:' + version;
    if (!version || !CFG.UPDATE_GIFT || rw.claims[id]) return 0;
    rw.claims[id] = { at: now };
    grant(rw, 0, CFG.UPDATE_GIFT, 'Update gift (v' + version + ')', now);
    return CFG.UPDATE_GIFT;
  }

  /* Once (claim 'coins:v2'): rewards earned under the first coin rates (v2.17-2.19) are raised to today's, so nobody
     loses out for starting early. Each lecture, Q bank level and exam is counted at the score of its first pay
     (bonuses aside). app.js runs it when the app starts, before anything new can be claimed. */
  var OLD_COINS = { lec: 20, qb: [[95, 60], [85, 40], [70, 25], [50, 12]], exam: [[90, 130], [80, 85], [0, 50]] };
  function oldTier(list, pct) { for (var i = 0; i < list.length; i++) if (pct >= list[i][0]) return list[i][1]; return 0; }
  function topUp(rw, now) {
    if (rw.claims['coins:v2']) return null;
    var add = 0, k, c, t;
    for (k in rw.claims) {
      c = rw.claims[k] || {};
      if (k.indexOf('lec:') === 0) add += CFG.LECTURE.coins - OLD_COINS.lec;
      else if (k.indexOf('qb:') === 0 && c.pct != null) { t = tier(CFG.QB_TIERS, c.pct); add += Math.max(0, (t ? t.coins : 0) - oldTier(OLD_COINS.qb, c.pct)); }
      else if (k.indexOf('exam:') === 0 && c.pct != null) { t = tier(CFG.EXAM_TIERS, c.pct); add += Math.max(0, (t ? t.coins : 0) - oldTier(OLD_COINS.exam, c.pct)); }
    }
    rw.claims['coins:v2'] = { at: now, coins: add };
    return add > 0 ? grant(rw, 0, add, 'Coins raised to the new rates', now) : null;
  }

  /* A medal for this attempt (kind: 'qb' | 'exam'), counted on the trophy shelf; '' below the lowest medal. */
  function medal(rw, kind, pct) {
    var t = tier(kind === 'exam' ? CFG.EXAM_MEDALS : CFG.QB_MEDALS, pct), m = t ? t.m : '';
    if (m) { if (!isInt(rw.medals[m])) rw.medals[m] = 0; rw.medals[m]++; }
    return m;
  }

  /* An optional study streak: days in a row with any study (a card ticked, a level or an exam finished). No rewards. */
  function touchDay(rw, now) {
    var d = Math.floor((now - new Date(now).getTimezoneOffset() * 60000) / 864e5);
    if (rw.days[0] === d) return;
    rw.days.unshift(d);
    if (rw.days.length > 400) rw.days.length = 400;
  }
  function streak(rw, now) {
    var today = Math.floor((now - new Date(now).getTimezoneOffset() * 60000) / 864e5), n = 0, want = rw.days[0] === today ? today : today - 1;
    for (var i = 0; i < rw.days.length; i++) { if (rw.days[i] === want) { n++; want--; } else if (rw.days[i] < want) break; }
    return n;
  }

  /* ---------- the shop: cosmetic only ---------- */
  function buy(rw, id, now) {
    var it = item(id);
    if (!it || it.free) return { ok: false, reason: 'not-for-sale' };
    if (rw.owned[id]) return { ok: false, reason: 'owned' };
    if (!(rw.coins >= it.price)) return { ok: false, reason: 'coins', need: it.price - rw.coins };
    rw.coins -= it.price;
    rw.owned[id] = now;
    rw.log.unshift({ at: now, what: 'Bought ' + it.name, xp: 0, coins: -it.price });
    if (rw.log.length > CFG.LOG_KEEP) rw.log.length = CFG.LOG_KEEP;
    return { ok: true, coins: rw.coins };
  }
  function bundle(id) { for (var i = 0; i < BUNDLES.length; i++) if (BUNDLES[i].id === id) return BUNDLES[i]; return null; }
  function bundlePrice(rw, id) {   // {full: the items you don't own yet, price: that less BUNDLE_OFF (to the nearest 50), save, left: their ids}
    var b = bundle(id), full = 0, left = [];
    (b ? b.items : []).forEach(function (i) { var it = item(i); if (it && !it.free && !rw.owned[i]) { full += it.price; left.push(i); } });
    var price = Math.round(full * (1 - BUNDLE_OFF) / 50) * 50;
    return { full: full, price: price, save: full - price, left: left };
  }
  function buyBundle(rw, id, now) {
    var b = bundle(id);
    if (!b) return { ok: false, reason: 'unknown' };
    var p = bundlePrice(rw, id);
    if (!p.left.length) return { ok: false, reason: 'owned' };
    if (!(rw.coins >= p.price)) return { ok: false, reason: 'coins', need: p.price - rw.coins };
    rw.coins -= p.price;
    p.left.forEach(function (i) { rw.owned[i] = now; });
    rw.log.unshift({ at: now, what: 'Bought the ' + b.name + ' (' + p.left.length + ' items)', xp: 0, coins: -p.price });
    if (rw.log.length > CFG.LOG_KEEP) rw.log.length = CFG.LOG_KEEP;
    return { ok: true, coins: rw.coins, items: p.left };
  }
  function equip(rw, id) {
    var it = item(id);
    if (!it) return { ok: false, reason: 'unknown' };
    if (!it.free && !rw.owned[id]) return { ok: false, reason: 'not-owned' };
    rw.eq[it.kind] = id;
    return { ok: true };
  }
  function unequip(rw, kind) { if (DEFAULTS[kind]) rw.eq[kind] = DEFAULTS[kind]; return { ok: !!DEFAULTS[kind] }; }

  window.RW = {
    CFG: CFG, RANKS: RANKS, BADGES: BADGES, SHOP: SHOP, DEFAULTS: DEFAULTS, MEDAL: MEDAL, medal: medal,
    xpToNextLevel: xpToNextLevel, totalXpForLevel: totalXpForLevel, getLevelFromXp: getLevelFromXp, getLevelProgress: getLevelProgress, rankFor: rankFor,
    fresh: fresh, ensure: ensure, item: item, equipped: equipped,
    claimLecture: claimLecture, claimQBank: claimQBank, claimExam: claimExam, claimGift: claimGift, topUp: topUp, touchDay: touchDay, streak: streak,
    buy: buy, equip: equip, unequip: unequip, BUNDLES: BUNDLES, BUNDLE_OFF: BUNDLE_OFF, bundle: bundle, bundlePrice: bundlePrice, buyBundle: buyBundle
  };
})();
