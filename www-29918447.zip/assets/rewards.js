/* SS Study rewards: XP, levels, ranks, coins, badges and a cosmetic-only shop. Free, local-first, no server.

   Everything here is pure logic (no screens): app.js calls it from the one place each activity finishes, then saves.
   The state lives in the app's saved progress (store.rw), on this device only, like ticks and Q bank stars:
   clearing the app's data resets it, and there is no cross-device sync (the app has no accounts).
   It is NOT cheat-proof: anything a page computes and saves on the device can be edited by its owner. Rewards are
   for fun and motivation only; they never unlock or change any study content. */
(function () {
  'use strict';

  /* ---------- settings: every threshold, reward and price is here ---------- */
  var CFG = {
    LECTURE: { xp: 50, coins: 20 },                 // first time every card of a lecture is ticked
    QB_TIERS: [                                     // a Q bank level, by its score; below 50%: nothing
      { min: 95, xp: 110, coins: 60 },
      { min: 85, xp: 85, coins: 40 },
      { min: 70, xp: 60, coins: 25 },
      { min: 50, xp: 35, coins: 12 }
    ],
    QB_MIN_QUESTIONS: 5,                            // a level with fewer questions pays nothing
    QB_BANK_SIZE: 30,                               // 3 levels x 10 questions: a bank pays only while it still brings new questions
    EXAM_PASS_PCT: 70,                              // the app's own pass mark (Q bank levels pass at 7 of 10)
    EXAM_TIERS: [                                   // the first passing attempt in an exam's reward slot
      { min: 90, xp: 250, coins: 130 },
      { min: 80, xp: 180, coins: 85 },
      { min: 0, xp: 120, coins: 50 }
    ],
    EXAM_MIN_ANSWERED: 0.5,                         // a mostly blank exam is not a real attempt
    EXAM_SLOT: 'day',                               // mock exams are drawn afresh each time: one reward slot per exam type per day
    BONUS_CAP: { xp: 40, coins: 20 },               // beating your own best later: at most this much extra per assessment, in total
    LOG_KEEP: 40,
    // Medals: for show on every attempt (retrying for gold counts); they never pay XP or coins, so they can't be farmed
    QB_MEDALS: [{ min: 100, m: 'gold' }, { min: 90, m: 'silver' }, { min: 70, m: 'bronze' }],
    EXAM_MEDALS: [{ min: 100, m: 'diamond' }, { min: 85, m: 'gold' }, { min: 70, m: 'silver' }, { min: 50, m: 'bronze' }]
  };
  var MEDAL = { diamond: { icon: '💎', name: 'Diamond' }, gold: { icon: '🥇', name: 'Gold' }, silver: { icon: '🥈', name: 'Silver' }, bronze: { icon: '🥉', name: 'Bronze' } };

  var RANKS = [   // fictional game ranks, earned by level only (never bought); not real qualifications
    { from: 1, name: 'Medical Novice', icon: '🌱' },
    { from: 6, name: 'Medical Apprentice', icon: '📗' },
    { from: 11, name: 'Medical Scholar', icon: '🎓' },
    { from: 21, name: 'Medical Expert', icon: '🔬' },
    { from: 36, name: 'Medical Master', icon: '🏅' },
    { from: 51, name: 'Medical Legend', icon: '🌟' }
  ];

  var BADGES = [   // awarded once each, automatically; they give no XP or coins
    { id: 'badge_first_lecture', name: 'First Steps', icon: '👣', desc: 'Complete one lecture.' },
    { id: 'badge_bookworm', name: 'Bookworm', icon: '🐛', desc: 'Complete 10 different lectures.' },
    { id: 'badge_first_qbank', name: 'Quiz Starter', icon: '🎯', desc: 'Score at least 50% on a Q bank level.' },
    { id: 'badge_sharpshooter', name: 'Sharpshooter', icon: '🏹', desc: 'Score at least 90% on 5 different Q bank levels.' },
    { id: 'badge_perfect_quiz', name: 'Perfectionist', icon: '💯', desc: 'Score 100% on a Q bank level.' },
    { id: 'badge_first_exam_pass', name: 'First Victory', icon: '🏆', desc: 'Pass a mock exam.' },
    { id: 'badge_exam_conqueror', name: 'Exam Conqueror', icon: '⚔️', desc: 'Pass 5 different mock exams (each exam type counts once a day).' },
    { id: 'badge_comeback', name: 'Comeback', icon: '🔁', desc: 'Fail a mock exam, then pass that same exam later.' }
  ];

  /* The shop: cosmetic only. Prices are coins, never real money.
     kind: title | frame | deco | theme | avatar | banner (profile theme) | fx (profile effect) | cardfx (Focus-mode card animation). */
  var SHOP = [
    { id: 'title_night_owl', kind: 'title', name: 'The Night Owl 🌙', price: 200, desc: 'For late-night revision sessions.' },
    { id: 'title_brainiac', kind: 'title', name: 'Brainiac 🧠', price: 350, desc: 'A title for big thinkers.' },
    { id: 'title_dedicated', kind: 'title', name: 'The Dedicated 📚', price: 500, desc: 'Shows you keep showing up.' },
    { id: 'title_quiz_slayer', kind: 'title', name: 'Quiz Slayer ⚔️', price: 750, desc: 'For Q bank warriors.' },
    { id: 'title_prodigy', kind: 'title', name: 'The Prodigy ✨', price: 1000, desc: 'A shiny title.' },
    { id: 'title_walking_encyclopedia', kind: 'title', name: 'Walking Encyclopedia 📖', price: 1250, desc: 'Knows a bit of everything.' },
    { id: 'title_dragon_scholar', kind: 'title', name: 'Dragon Scholar 🐉', price: 1500, desc: 'A fierce title.' },
    { id: 'title_chosen_one', kind: 'title', name: 'The Chosen One 👑', price: 2500, desc: 'A rare title.' },
    { id: 'title_beyond_genius', kind: 'title', name: 'Beyond Genius 🌌', price: 4000, desc: 'The top title in the shop.' },
    { id: 'frame_galaxy', kind: 'frame', name: 'Galaxy frame', price: 500, desc: 'A swirling galaxy ring around your avatar.' },
    { id: 'frame_blossom', kind: 'frame', name: 'Blossom', price: 700, desc: 'A soft ring of cherry-blossom pinks that slowly turns.' },
    { id: 'frame_gold', kind: 'frame', name: 'Golden ring', price: 800, desc: 'Polished gold with a shine that travels round the ring.' },
    { id: 'frame_neon', kind: 'frame', name: 'Neon chase', price: 900, desc: 'Cyan and magenta light chasing each other, with a neon glow.' },
    { id: 'frame_crystal', kind: 'frame', name: 'Crystal', price: 1100, desc: 'Cut ice-blue facets that glint as they turn.' },
    { id: 'frame_inferno', kind: 'frame', name: 'Inferno', price: 1300, desc: 'A ring of living fire that flickers and glows.' },
    { id: 'deco_crown', kind: 'deco', name: 'Royal crown', price: 750, desc: 'A jewelled gold crown with pearls, a velvet cap and a shine that sweeps across it.' },
    { id: 'deco_cap', kind: 'deco', name: 'Scholar\u2019s cap', price: 800, desc: 'A graduation cap with a gold cord and a tassel that swings.' },
    { id: 'deco_halo', kind: 'deco', name: 'Halo', price: 900, desc: 'A golden halo floating smoothly up and down, with light running round it.' },
    { id: 'deco_stetho', kind: 'deco', name: 'Stethoscope 🩺', price: 1000, desc: 'A stethoscope round your neck; the chest piece swings gently.' },
    { id: 'deco_orbit', kind: 'deco', name: 'Orbiting stars', price: 1100, desc: 'Two stars with trails on tilted orbits, passing behind you and in front.' },
    { id: 'deco_dna', kind: 'deco', name: 'DNA helix 🧬', price: 1300, desc: 'A double helix turning beside your avatar.' },
    { id: 'deco_wings', kind: 'deco', name: 'Phoenix wings', price: 1600, desc: 'Feathered wings of fire behind you, beating slowly, with rising embers.' },
    { id: 'theme_nebula', kind: 'theme', name: 'Nebula theme', price: 1000, desc: 'Deep space for the whole app: drifting nebula colours and twinkling stars.' },
    { id: 'theme_night', kind: 'theme', name: 'Night theme', price: 800, desc: 'Calm midnight blues, easy on the eyes late at night.' },
    { id: 'theme_ocean', kind: 'theme', name: 'Ocean theme', price: 900, desc: 'Deep sea teals and blues, with slow waves of light.' },
    { id: 'theme_sakura', kind: 'theme', name: 'Sakura theme', price: 900, desc: 'Soft cherry-blossom pinks with drifting petals.' },
    { id: 'theme_rainbow', kind: 'theme', name: 'Rainbow theme', price: 1200, desc: 'Moving rainbow bars and accents all over the app.' },
    { id: 'theme_emerald', kind: 'theme', name: 'Emerald forest', price: 1200, desc: 'Deep forest greens, light rays through the trees and floating specks.' },
    { id: 'theme_aurora', kind: 'theme', name: 'Aurora theme', price: 1500, desc: 'Northern lights that ripple slowly across a polar night.' },
    { id: 'theme_synth', kind: 'theme', name: 'Synthwave theme', price: 1500, desc: 'Neon pink and cyan with a glowing horizon and a moving grid.' },
    { id: 'theme_gold', kind: 'theme', name: 'Royal gold', price: 1800, desc: 'Black and gold, with a gold shimmer sweeping the top bar.' },
    { id: 'theme_blackhole', kind: 'theme', name: 'Black hole', price: 2500, desc: 'The only theme with its own story: a black hole drifts in the middle of the app, swallows every star around it, flares, and the stars come back.' },
    // profile themes: the backdrop behind your name and picture
    { id: 'banner_sunset', kind: 'banner', name: 'Sunset', price: 400, desc: 'A warm evening sky behind your profile.' },
    { id: 'banner_ocean', kind: 'banner', name: 'Ocean', price: 400, desc: 'Rolling blue waves behind your profile.' },
    { id: 'banner_night', kind: 'banner', name: 'Night sky', price: 500, desc: 'Stars and a moon behind your profile.' },
    { id: 'banner_aurora', kind: 'banner', name: 'Aurora', price: 700, desc: 'Northern lights that slowly move.' },
    { id: 'banner_rainbow', kind: 'banner', name: 'Rainbow', price: 800, desc: 'A rainbow that keeps flowing.' },
    { id: 'banner_alpine', kind: 'banner', name: 'Alpine dusk', price: 900, desc: 'Layered mountains under a glowing dusk sky.' },
    { id: 'banner_blossom', kind: 'banner', name: 'Cherry blossom', price: 900, desc: 'Petals drifting across a soft pink sky.' },
    { id: 'banner_galaxy', kind: 'banner', name: 'Galaxy', price: 1000, desc: 'A spiral galaxy turning slowly among the stars.' },
    { id: 'banner_synth', kind: 'banner', name: 'Synthwave', price: 1200, desc: 'A striped retro sun over a neon grid that keeps moving.' },
    // profile effects: animated, over your profile
    { id: 'fx_sparkles', kind: 'fx', name: 'Sparkles ✨', price: 400, desc: 'Little stars twinkle around you.' },
    { id: 'fx_snow', kind: 'fx', name: 'Snow ❄️', price: 500, desc: 'Gentle snowflakes drift down.' },
    { id: 'fx_rain', kind: 'fx', name: 'Rain 🌧️', price: 500, desc: 'A soft rain falls on your profile.' },
    { id: 'fx_fireflies', kind: 'fx', name: 'Fireflies', price: 600, desc: 'Glowing fireflies float about.' },
    { id: 'fx_lightning', kind: 'fx', name: 'Lightning ⚡', price: 900, desc: 'Rain with flashes of lightning.' },
    { id: 'fx_bubbles', kind: 'fx', name: 'Bubbles', price: 600, desc: 'Glassy bubbles rising and wobbling.' },
    { id: 'fx_petals', kind: 'fx', name: 'Petals 🌸', price: 600, desc: 'Blossom petals tumbling down.' },
    { id: 'fx_embers', kind: 'fx', name: 'Embers', price: 700, desc: 'Glowing embers drifting up and fading.' },
    { id: 'fx_meteors', kind: 'fx', name: 'Meteor shower ☄️', price: 1000, desc: 'Shooting stars streaking across your profile.' },
    // card animations: how a card arrives in Focus mode and leaves when you tap "Got it, next"
    { id: 'cardfx_fade', kind: 'cardfx', name: 'Fade', price: 300, desc: 'Cards fade softly out and in.' },
    { id: 'cardfx_zoom', kind: 'cardfx', name: 'Zoom', price: 400, desc: 'Cards zoom away and the next one pops in.' },
    { id: 'cardfx_flip', kind: 'cardfx', name: 'Flip', price: 500, desc: 'Cards flip over like a page.' },
    { id: 'cardfx_rocket', kind: 'cardfx', name: 'Rocket 🚀', price: 700, desc: 'Done cards blast off upwards.' },
    { id: 'cardfx_race', kind: 'cardfx', name: 'Race car 🏎️', price: 900, desc: 'Done cards back up, tilt and race off with speed lines; the next one drifts in.' },
    { id: 'cardfx_fold', kind: 'cardfx', name: 'Fold', price: 700, desc: 'Cards fold away like paper; the next one unfolds.' },
    { id: 'cardfx_swoosh', kind: 'cardfx', name: 'Swoosh', price: 800, desc: 'Cards squash, then fling away; the next one drops in with a bounce.' },
    { id: 'cardfx_pageturn', kind: 'cardfx', name: 'Page turn 📖', price: 900, desc: 'Cards turn like a real book page, with shading.' },
    { id: 'cardfx_portal', kind: 'cardfx', name: 'Portal 🌀', price: 1000, desc: 'Cards spin away into a swirl; the next one spins out of it.' },
    // free defaults, so every profile looks complete
    { id: 'avatar_doctor', kind: 'avatar', name: 'Doctor', icon: '🧑‍⚕️', price: 0, free: true },
    { id: 'avatar_brain', kind: 'avatar', name: 'Brain', icon: '🧠', price: 0, free: true },
    { id: 'avatar_eye', kind: 'avatar', name: 'Eye', icon: '👁️', price: 0, free: true },
    { id: 'avatar_ear', kind: 'avatar', name: 'Ear', icon: '👂', price: 0, free: true },
    { id: 'avatar_owl', kind: 'avatar', name: 'Owl', icon: '🦉', price: 0, free: true },
    { id: 'avatar_cat', kind: 'avatar', name: 'Cat', icon: '🐱', price: 0, free: true },
    { id: 'avatar_star', kind: 'avatar', name: 'Star', icon: '⭐', price: 0, free: true },
    { id: 'frame_plain', kind: 'frame', name: 'Plain frame', price: 0, free: true, desc: 'A simple ring.' },
    { id: 'deco_none', kind: 'deco', name: 'No decoration', price: 0, free: true },
    { id: 'theme_default', kind: 'theme', name: 'Standard theme', price: 0, free: true, desc: 'The usual colours.' },
    { id: 'banner_none', kind: 'banner', name: 'Plain', price: 0, free: true },
    { id: 'fx_none', kind: 'fx', name: 'No effect', price: 0, free: true },
    { id: 'cardfx_none', kind: 'cardfx', name: 'Classic', price: 0, free: true, desc: 'Cards change straight away.' },
    { id: 'title_none', kind: 'title', name: 'No title', price: 0, free: true },
    { id: 'intro_pen', kind: 'intro', name: 'Pen writing', price: 0, free: true, desc: 'A pen writes SPECIAL SENSES, then SS STUDY.' },
    { id: 'tiles_default', kind: 'tiles', name: 'Standard tabs', price: 0, free: true, desc: 'The usual tiles.' },
    { id: 'intro_ecg', kind: 'intro', name: 'Heartbeat 💓', price: 800, desc: 'A heart monitor sweeps across the screen, then SS STUDY beats into place.' },
    { id: 'intro_wave', kind: 'intro', name: 'Sound wave 🎧', price: 900, desc: 'An equaliser bounces to the beat, settles into a line and the logo rises out of it.' },
    { id: 'intro_neon', kind: 'intro', name: 'Neon sign', price: 1000, desc: 'Glass tubes on a brick wall flicker on one letter at a time.' },
    { id: 'intro_stars', kind: 'intro', name: 'Constellation ✨', price: 1100, desc: 'Stars appear and golden lines join them into the logo.' },
    { id: 'intro_eye', kind: 'intro', name: 'Eye opening 👁️', price: 1300, desc: 'An eye opens, looks around, its pupil narrows, and you fly in through it.' },
    { id: 'intro_warp', kind: 'intro', name: 'Warp speed 🚀', price: 1500, desc: 'Stars stream past at light speed, a flash, and the logo lands with a shockwave.' },
    { id: 'tiles_glass', kind: 'tiles', name: 'Glass', price: 600, desc: 'Clear glass tiles with a shine across them and glossy badges.' },
    { id: 'tiles_paper', kind: 'tiles', name: 'Notebook', price: 700, desc: 'Lined notebook paper with a margin, washi tape and stamped badges.' },
    { id: 'tiles_clay', kind: 'tiles', name: 'Soft 3D', price: 800, desc: 'Soft raised tiles that press in when you tap, with round glossy buttons.' },
    { id: 'tiles_neon', kind: 'tiles', name: 'Neon edge', price: 900, desc: 'Dark tiles outlined in each subject’s colour, glowing softly.' },
    { id: 'tiles_holo', kind: 'tiles', name: 'Holographic', price: 1100, desc: 'Rainbow foil edges and a shimmer that slides across every tile.' },
    { id: 'tiles_gold', kind: 'tiles', name: 'Gold leaf', price: 1200, desc: 'Black and gold, a double gold border and gilded corners.' },
    { id: 'cards_default', kind: 'cards', name: 'Standard cards', price: 0, free: true, desc: 'The usual cards.' },
    { id: 'cards_glass', kind: 'cards', name: 'Glass card', price: 700, desc: 'Clear glass with a shine, a soft edge light and a glossy Got it button.' },
    { id: 'cards_index', kind: 'cards', name: 'Index card', price: 800, desc: 'A real study index card: red header lines, a folded corner and a LEARNED stamp when you tick it.' },
    { id: 'cards_clip', kind: 'cards', name: 'Clipboard 🩺', price: 900, desc: 'A patient chart on a wooden clipboard with a metal clip; ticked cards get a REVIEWED stamp.' },
    { id: 'cards_neon', kind: 'cards', name: 'Neon card', price: 1000, desc: 'Dark cards outlined in the subject’s colour; they glow green when you tick them.' },
    { id: 'cards_holo', kind: 'cards', name: 'Holo foil', price: 1200, desc: 'Rainbow foil edges, a shimmer across the header and a foil seal when done.' },
    { id: 'cards_gold', kind: 'cards', name: 'Gold leaf card', price: 1400, desc: 'Black lacquer, gilded corners, gold key words and a gold seal when done.' }
  ];
  var DEFAULTS = { avatar: 'avatar_doctor', frame: 'frame_plain', deco: 'deco_none', theme: 'theme_default', title: 'title_none',
    banner: 'banner_none', fx: 'fx_none', cardfx: 'cardfx_none', intro: 'intro_pen', tiles: 'tiles_default', cards: 'cards_default' };

  /* ---------- levels: lifetime XP only (coins never count) ---------- */
  var isInt = Number.isSafeInteger || function (n) { return typeof n === 'number' && isFinite(n) && Math.floor(n) === n && Math.abs(n) <= 9007199254740991; };
  function xpToNextLevel(level) {
    if (!isInt(level) || level < 1) throw new RangeError('Invalid level');
    return 100 + 25 * (level - 1);
  }
  function totalXpForLevel(level) {
    if (!isInt(level) || level < 1) throw new RangeError('Invalid level');
    return 100 * (level - 1) + (25 * (level - 1) * (level - 2)) / 2;
  }
  function getLevelFromXp(totalXp) {
    if (!isInt(totalXp) || totalXp < 0) throw new RangeError('Invalid XP');
    var low = 1, high = 2, mid;   // the highest level whose lifetime threshold is <= totalXp
    while (totalXpForLevel(high) <= totalXp) high *= 2;
    while (low + 1 < high) {
      mid = Math.floor((low + high) / 2);
      if (totalXpForLevel(mid) <= totalXp) low = mid; else high = mid;
    }
    return low;
  }
  function getLevelProgress(totalXp) {
    var level = getLevelFromXp(totalXp), earned = totalXp - totalXpForLevel(level), need = xpToNextLevel(level);
    return { level: level, earnedWithinLevel: earned, requiredWithinLevel: need, fraction: earned / need };
  }
  function rankFor(level) {
    var r = RANKS[0];
    for (var i = 0; i < RANKS.length; i++) if (level >= RANKS[i].from) r = RANKS[i];
    return r;
  }

  /* ---------- the saved state (store.rw) ---------- */
  function fresh() {
    return { v: 1, xp: 0, coins: 0, claims: {}, best: {}, bonus: {}, fails: {}, passes: {}, badges: {}, owned: {}, eq: {}, days: [], log: [],
      medals: { diamond: 0, gold: 0, silver: 0, bronze: 0 } };
  }
  function ensure(rw) {   // fills in anything missing, never overwrites what is there
    var f = fresh(), k;
    if (!rw || typeof rw !== 'object') return f;
    for (k in f) if (rw[k] == null || typeof rw[k] !== typeof f[k] || Array.isArray(f[k]) !== Array.isArray(rw[k])) rw[k] = f[k];
    if (!isInt(rw.xp) || rw.xp < 0) rw.xp = 0;
    if (!isInt(rw.coins) || rw.coins < 0) rw.coins = 0;
    return rw;
  }
  function item(id) { for (var i = 0; i < SHOP.length; i++) if (SHOP[i].id === id) return SHOP[i]; return null; }
  function equipped(rw, kind) {   // what is worn, falling back to the free default if the saved one is not valid
    var id = rw.eq[kind], it = id && item(id);
    return it && it.kind === kind && (it.free || rw.owned[id]) ? it : item(DEFAULTS[kind]);
  }

  /* ---------- paying out (one place for every reward) ---------- */
  function grant(rw, xp, coins, what, now) {
    var before = getLevelFromXp(rw.xp);
    rw.xp += xp; rw.coins += coins;
    var after = getLevelFromXp(rw.xp);
    rw.log.unshift({ at: now, what: what, xp: xp, coins: coins });
    if (rw.log.length > CFG.LOG_KEEP) rw.log.length = CFG.LOG_KEEP;
    return { xp: xp, coins: coins, levelBefore: before, levelAfter: after,
      rankBefore: rankFor(before).name, rankAfter: rankFor(after).name };
  }
  function result(rw, base, reason, extra) {   // what the screens show: earned, why, new totals, progress, new badges
    var out = { xp: 0, coins: 0, reason: reason || '', badges: [] }, k;
    for (k in base || {}) out[k] = base[k];
    for (k in extra || {}) out[k] = extra[k];
    out.totalXp = rw.xp; out.totalCoins = rw.coins;
    out.progress = getLevelProgress(rw.xp);
    out.rank = rankFor(out.progress.level).name;
    if (out.levelBefore == null) { out.levelBefore = out.levelAfter = out.progress.level; }
    return out;
  }
  function badge(rw, id, now, list) { if (!rw.badges[id]) { rw.badges[id] = now; list.push(id); } }
  function count(obj, prefix, test) { var n = 0; for (var k in obj) if (k.indexOf(prefix) === 0 && (!test || test(obj[k]))) n++; return n; }
  function tier(tiers, pct) { for (var i = 0; i < tiers.length; i++) if (pct >= tiers[i].min) return tiers[i]; return null; }
  function bonusLeft(rw, id) { var b = rw.bonus[id] || { xp: 0, coins: 0 }; return { xp: Math.max(0, CFG.BONUS_CAP.xp - b.xp), coins: Math.max(0, CFG.BONUS_CAP.coins - b.coins) }; }
  function payBonus(rw, id, fromTier, toTier, now, what) {   // the extra for beating your own best: the tier difference, capped in total
    var left = bonusLeft(rw, id), xp = Math.min(left.xp, Math.max(0, toTier.xp - fromTier.xp)), coins = Math.min(left.coins, Math.max(0, toTier.coins - fromTier.coins));
    if (!xp && !coins) return null;
    var b = rw.bonus[id] || (rw.bonus[id] = { xp: 0, coins: 0 });
    b.xp += xp; b.coins += coins;
    return grant(rw, xp, coins, what, now);
  }
  function dayOf(now) { var d = new Date(now); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }

  /* A lecture: every card ticked. Pays once per lecture, ever (unticking and ticking again pays nothing). */
  function claimLecture(rw, lid, title, now) {
    var id = 'lec:' + lid, got = [];
    if (rw.claims[id]) return result(rw, null, 'already');
    rw.claims[id] = { at: now };
    var g = grant(rw, CFG.LECTURE.xp, CFG.LECTURE.coins, 'Lecture: ' + title, now);
    badge(rw, 'badge_first_lecture', now, got);
    if (count(rw.claims, 'lec:') >= 10) badge(rw, 'badge_bookworm', now, got);
    return result(rw, g, 'lecture', { badges: got });
  }

  /* A Q bank level: {mode, sid, bank, lv, got, n, paidBanks, name}. Its stable id is the subject + bank + level (never
     a random session id). Pays the first time it reaches 50%; after that, only beating your own best pays a small
     capped bonus. Banks past paidBanks (once a subject's questions have all come round) pay nothing. */
  function claimQBank(rw, q, now) {
    var pct = Math.round(q.got / q.n * 100), id = 'qb:' + q.mode + ':' + q.sid + ':' + q.bank + ':' + q.lv, got = [], g = null;
    if (!(q.n >= CFG.QB_MIN_QUESTIONS)) return result(rw, null, 'too-few', { pct: pct });
    if (q.bank >= (q.paidBanks || 1)) return result(rw, null, 'old-bank', { pct: pct });
    var best = rw.best[id], t = tier(CFG.QB_TIERS, pct), what = 'Q bank: ' + (q.name || q.sid) + ', bank ' + (q.bank + 1) + ' level ' + q.lv;
    var reason;
    if (!rw.claims[id]) {
      if (!t) reason = 'below';
      else { rw.claims[id] = { at: now, pct: pct }; g = grant(rw, t.xp, t.coins, what, now); reason = 'first'; }
    } else if (best != null && pct > best && t) {
      g = payBonus(rw, id, tier(CFG.QB_TIERS, best) || { xp: 0, coins: 0 }, t, now, what + ' (new best)');
      reason = g ? 'bonus' : 'capped';
    } else reason = best != null && pct <= best ? 'not-better' : 'already';
    if (best == null || pct > best) rw.best[id] = pct;
    if (pct >= 50) badge(rw, 'badge_first_qbank', now, got);
    if (pct === 100) badge(rw, 'badge_perfect_quiz', now, got);
    if (count(rw.best, 'qb:', function (p) { return p >= 90; }) >= 5) badge(rw, 'badge_sharpshooter', now, got);
    return result(rw, g, reason, { badges: got, pct: pct, best: rw.best[id] });
  }

  /* A mock exam: {type ('ebe' | 'ospe-written' | 'ospe-mix'), got, n, answered, name}. Exams are drawn afresh every
     time, so the stable id is the exam type + the day: the first pass of the day pays by score, a later better pass
     that day only a capped bonus. Failing (below EXAM_PASS_PCT) pays nothing; a mostly blank paper doesn't count. */
  function claimExam(rw, x, now) {
    var pct = Math.round(x.got / x.n * 100), slot = CFG.EXAM_SLOT === 'day' ? dayOf(now) : 'once', id = 'exam:' + x.type + ':' + slot, got = [], g = null, reason;
    if (!(x.n > 0) || x.answered < x.n * CFG.EXAM_MIN_ANSWERED) return result(rw, null, 'blank', { pct: pct, pass: false });
    var pass = pct >= CFG.EXAM_PASS_PCT, what = (x.name || x.type) + ' mock exam';
    if (!pass) {
      var f = rw.fails[x.type] || (rw.fails[x.type] = { n: 0 });
      f.n++; f.at = now;
      return result(rw, null, 'below-pass', { pct: pct, pass: false, passMark: CFG.EXAM_PASS_PCT });
    }
    var t = tier(CFG.EXAM_TIERS, pct), best = rw.best[id];
    if (!rw.claims[id]) { rw.claims[id] = { at: now, pct: pct }; g = grant(rw, t.xp, t.coins, what, now); reason = 'first'; }
    else if (best != null && pct > best) { g = payBonus(rw, id, tier(CFG.EXAM_TIERS, best), t, now, what + ' (new best)'); reason = g ? 'bonus' : 'capped'; }
    else reason = 'not-better';
    if (best == null || pct > best) rw.best[id] = pct;
    rw.passes[id] = rw.best[id];
    badge(rw, 'badge_first_exam_pass', now, got);
    if (count(rw.passes, 'exam:') >= 5) badge(rw, 'badge_exam_conqueror', now, got);
    if (rw.fails[x.type] && rw.fails[x.type].n > 0 && rw.fails[x.type].at < now) badge(rw, 'badge_comeback', now, got);
    return result(rw, g, reason, { badges: got, pct: pct, pass: true, best: rw.best[id] });
  }

  /* A medal for this attempt (kind: 'qb' | 'exam'), counted on the trophy shelf; '' below the lowest medal. */
  function medal(rw, kind, pct) {
    var t = tier(kind === 'exam' ? CFG.EXAM_MEDALS : CFG.QB_MEDALS, pct), m = t ? t.m : '';
    if (m) { if (!isInt(rw.medals[m])) rw.medals[m] = 0; rw.medals[m]++; }
    return m;
  }

  /* An optional study streak: days in a row with any study (a card ticked, a level or an exam finished). No rewards. */
  function touchDay(rw, now) {
    var d = Math.floor((now - new Date(now).getTimezoneOffset() * 60000) / 864e5);
    if (rw.days[0] === d) return;
    rw.days.unshift(d);
    if (rw.days.length > 400) rw.days.length = 400;
  }
  function streak(rw, now) {
    var today = Math.floor((now - new Date(now).getTimezoneOffset() * 60000) / 864e5), n = 0, want = rw.days[0] === today ? today : today - 1;
    for (var i = 0; i < rw.days.length; i++) { if (rw.days[i] === want) { n++; want--; } else if (rw.days[i] < want) break; }
    return n;
  }

  /* ---------- the shop: cosmetic only ---------- */
  function buy(rw, id, now) {
    var it = item(id);
    if (!it || it.free) return { ok: false, reason: 'not-for-sale' };
    if (rw.owned[id]) return { ok: false, reason: 'owned' };
    if (!(rw.coins >= it.price)) return { ok: false, reason: 'coins', need: it.price - rw.coins };
    rw.coins -= it.price;
    rw.owned[id] = now;
    rw.log.unshift({ at: now, what: 'Bought ' + it.name, xp: 0, coins: -it.price });
    if (rw.log.length > CFG.LOG_KEEP) rw.log.length = CFG.LOG_KEEP;
    return { ok: true, coins: rw.coins };
  }
  function equip(rw, id) {
    var it = item(id);
    if (!it) return { ok: false, reason: 'unknown' };
    if (!it.free && !rw.owned[id]) return { ok: false, reason: 'not-owned' };
    rw.eq[it.kind] = id;
    return { ok: true };
  }
  function unequip(rw, kind) { if (DEFAULTS[kind]) rw.eq[kind] = DEFAULTS[kind]; return { ok: !!DEFAULTS[kind] }; }

  window.RW = {
    CFG: CFG, RANKS: RANKS, BADGES: BADGES, SHOP: SHOP, DEFAULTS: DEFAULTS, MEDAL: MEDAL, medal: medal,
    xpToNextLevel: xpToNextLevel, totalXpForLevel: totalXpForLevel, getLevelFromXp: getLevelFromXp, getLevelProgress: getLevelProgress, rankFor: rankFor,
    fresh: fresh, ensure: ensure, item: item, equipped: equipped,
    claimLecture: claimLecture, claimQBank: claimQBank, claimExam: claimExam, touchDay: touchDay, streak: streak,
    buy: buy, equip: equip, unequip: unequip
  };
})();
