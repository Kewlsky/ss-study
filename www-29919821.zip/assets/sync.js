/* SS Study · Link devices: the rules for merging two devices' progress (pure functions, no network, tested in
   tools/rewards-test.html). app.js does the talking to the database and the screen.

   How it works: every linked device publishes its own copy (a "pack") under the group's space, and reads everyone's.
   A device never writes another device's part, so two devices can't overwrite each other; every device merges all
   the packs the same way, so they end up the same:
   - ticked cards: for each card, the newest tick or untick wins (old ticks with no time count as ticked);
   - rewards claimed, shop items owned, badges, streak days, score history: added together (union);
   - best scores and bonus paid so far: the higher one;
   - XP, coins and medals: each device keeps a count of what it earned (or spent) itself, "own"; the total is the sum
     of every device's own count, so nothing is counted twice;
   - what you wear, your name and your photo: the newest change wins. */
(function () {
  'use strict';
  var K = ['xp', 'c', 'md', 'mg', 'ms', 'mb'];   // XP, coins, diamond, gold, silver, bronze medals
  var ABC = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';   // no I, L, O, 0 or 1: nothing to mix up when typing a code

  function counters(r) {
    var m = (r && r.medals) || {};
    return { xp: +r.xp || 0, c: +r.coins || 0, md: +m.diamond || 0, mg: +m.gold || 0, ms: +m.silver || 0, mb: +m.bronze || 0 };
  }
  function add(a, b, k) { var o = {}; K.forEach(function (x) { o[x] = (+(a || {})[x] || 0) + k * (+(b || {})[x] || 0); }); return o; }
  function higher(a, b) {   // deep merge keeping the higher number: best scores, bonus paid, Q bank levels
    if (typeof a === 'number' || typeof b === 'number') return Math.max(+a || 0, +b || 0);
    if (Array.isArray(a) || Array.isArray(b)) {
      var x = Array.isArray(a) ? a : [], y = Array.isArray(b) ? b : [], out = [], i;
      for (i = 0; i < Math.max(x.length, y.length); i++) out[i] = x[i] == null ? y[i] : y[i] == null ? x[i] : higher(x[i], y[i]);
      return out;
    }
    if (a && typeof a === 'object' && b && typeof b === 'object') {
      var o = {}, k;
      for (k in a) o[k] = a[k];
      for (k in b) o[k] = k in o ? higher(o[k], b[k]) : b[k];
      return o;
    }
    return a == null ? b : a;
  }
  function union(a, b) { var o = {}, k; for (k in b || {}) o[k] = b[k]; for (k in a || {}) o[k] = a[k]; return o; }   // this device's value wins when both have one
  function list(a, b, key) {
    var seen = {}, out = [];
    (a || []).concat(b || []).forEach(function (x) { if (x == null) return; var k = key(x); if (!seen[k]) { seen[k] = 1; out.push(x); } });
    return out;
  }
  function canon(v) {   // JSON with the keys in a fixed order: the same data always gives the same text (so devices don't keep re-sending it)
    if (Array.isArray(v)) return '[' + v.map(function (x) { return x === undefined ? 'null' : canon(x); }).join(',') + ']';
    if (v && typeof v === 'object') return '{' + Object.keys(v).sort().filter(function (k) { return v[k] !== undefined; }).map(function (k) { return JSON.stringify(k) + ':' + canon(v[k]); }).join(',') + '}';
    return JSON.stringify(v === undefined ? null : v);
  }
  function takes(wt, mt, wv, mv) { wt = wt || 0; mt = mt || 0; return (wt > mt && (!!wv || wt > 1)) || (!mv && !!wv && mt <= 1); }
  function photoKey(r) { var p = r.photo || ''; return p.length + ':' + p.slice(-32) + (r.usePhoto === false ? ':off' : ':on'); }

  /* a code: 12 letters and digits, shown as K7QM-4XRT-P2WN */
  function makeCode(rand) { var s = '', i; for (i = 0; i < 12; i++) s += ABC[rand(i) % ABC.length]; return s; }
  function norm(s) {
    var c = String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), i;
    if (c.length !== 12) return '';
    for (i = 0; i < 12; i++) if (ABC.indexOf(c[i]) < 0) return '';
    return c;
  }
  function fmt(c) { return String(c || '').replace(/(.{4})(?=.)/g, '$1-'); }

  /* the sync state for a device that links now. maker: this device made the code (its looks win at first) */
  function start(r, maker, old) {
    var cur = counters(r);
    return { own: old ? add(old.own, add(cur, old.base, -1), 1) : cur, base: cur,
      eqT: maker ? 1 : 0, eqJ: JSON.stringify(r.eq || {}), nameT: maker ? 1 : 0, nameJ: r.name || '', photoT: maker ? 1 : 0, photoJ: photoKey(r) };
  }
  /* what this device did since the last sync: its earnings go into its own count, changed looks get the time */
  function stamp(S, r, now) {
    var cur = counters(r);
    S.own = add(S.own, add(cur, S.base, -1), 1); S.base = cur;
    var eq = JSON.stringify(r.eq || {});
    if (eq !== S.eqJ) { S.eqJ = eq; S.eqT = now; }
    if ((r.name || '') !== (S.nameJ || '')) { S.nameJ = r.name || ''; S.nameT = now; }
    var ph = photoKey(r);
    if (ph !== S.photoJ) { S.photoJ = ph; S.photoT = now; }
  }
  /* this device's pack: everything shared, nothing private (no creator data, no reminders, no exam in progress) */
  function pack(st, S) {
    var r = st.rw || {};
    return { v: 1, own: S.own, done: st.done || {}, doneT: st.doneT || {}, qbBest: (st.qb && st.qb.best) || {}, examLog: st.examLog || [], oexLog: st.oexLog || [],
      rw: { claims: r.claims, best: r.best, bonus: r.bonus, fails: r.fails, passes: r.passes, badges: r.badges, owned: r.owned, days: r.days, log: r.log,
        eq: r.eq, eqT: S.eqT || 0, name: r.name || '', nameT: S.nameT || 0, photo: r.photo || '', usePhoto: r.usePhoto !== false, photoT: S.photoT || 0 } };
  }
  /* merge the other devices' packs into this device's store. Returns true when anything here changed. */
  function merge(st, S, others, keepLog) {
    var r = st.rw, before = canon([st.done, r, st.qb && st.qb.best, st.examLog, st.oexLog]);
    var T = st.doneT || (st.doneT = {}), tot = add(S.own, null, 0);
    others.forEach(function (o) {
      if (!o || typeof o !== 'object') return;
      var od = o.done || {}, oT = o.doneT || {}, ids = {}, id;
      for (id in od) ids[id] = 1;
      for (id in oT) ids[id] = 1;
      for (id in ids) {
        var mine = T[id] || 0, theirs = oT[id] || 0;
        if (theirs > mine) { if (od[id]) st.done[id] = od[id]; else delete st.done[id]; T[id] = theirs; }
        else if (theirs === mine && !mine && od[id] && !st.done[id]) st.done[id] = od[id];
      }
      var w = o.rw || {};
      r.claims = union(r.claims, w.claims); r.owned = union(r.owned, w.owned); r.badges = union(r.badges, w.badges);
      r.best = higher(r.best, w.best); r.bonus = higher(r.bonus, w.bonus); r.fails = higher(r.fails, w.fails); r.passes = higher(r.passes, w.passes);
      r.days = list(r.days, w.days, String).sort(function (p, q) { return q - p; }).slice(0, 400);
      r.log = list(r.log, w.log, function (x) { return x.at + '|' + x.what; }).sort(function (p, q) { return q.at - p.at; }).slice(0, keepLog || 40);
      if (w.eq && takes(w.eqT, S.eqT, Object.keys(w.eq).length, Object.keys(r.eq || {}).length)) { r.eq = w.eq; S.eqT = w.eqT || 0; S.eqJ = JSON.stringify(r.eq); }   // default looks never wipe chosen ones
      // name and photo: the newest change wins, but an empty one only wins if it was really removed after linking
      // (times 0 and 1 are just "how it was when linked"), so linking never wipes a name or photo
      if (takes(w.nameT, S.nameT, w.name, r.name)) {
        if (w.name) r.name = w.name; else delete r.name;
        S.nameT = w.nameT || 0; S.nameJ = r.name || '';
      }
      if (takes(w.photoT, S.photoT, w.photo, r.photo)) {
        if (w.photo) { r.photo = w.photo; r.usePhoto = w.usePhoto !== false; } else { delete r.photo; delete r.usePhoto; }
        S.photoT = w.photoT || 0; S.photoJ = photoKey(r);
      }
      if (o.qbBest) { st.qb = st.qb || { best: {}, miss: {} }; st.qb.best = higher(st.qb.best, o.qbBest); }
      st.examLog = list(st.examLog, o.examLog, function (x) { return x.t; }).sort(function (p, q) { return p.t - q.t; }).slice(-20);
      st.oexLog = list(st.oexLog, o.oexLog, function (x) { return x.at; }).sort(function (p, q) { return p.at - q.at; }).slice(-20);
      tot = add(tot, o.own, 1);
    });
    r.xp = Math.max(0, Math.round(tot.xp)); r.coins = Math.max(0, Math.round(tot.c));
    r.medals = { diamond: Math.max(0, tot.md), gold: Math.max(0, tot.mg), silver: Math.max(0, tot.ms), bronze: Math.max(0, tot.mb) };
    S.base = counters(r);
    if (st.examLog && !st.examLog.length) delete st.examLog;
    if (st.oexLog && !st.oexLog.length) delete st.oexLog;
    return canon([st.done, r, st.qb && st.qb.best, st.examLog, st.oexLog]) !== before;
  }
  window.SY = { counters: counters, add: add, higher: higher, union: union, canon: canon, makeCode: makeCode, norm: norm, fmt: fmt, start: start, stamp: stamp, pack: pack, merge: merge, ABC: ABC };
})();
