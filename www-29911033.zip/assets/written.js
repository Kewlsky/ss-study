window.WCATALOG=[{"id": "anat", "name": "Anatomy", "lectures": []}, {"id": "physio", "name": "Physiology", "lectures": []}, {"id": "histo", "name": "Histology", "lectures": []}, {"id": "pharma", "name": "Pharmacology", "lectures": []}];
window.WTEST=[];
